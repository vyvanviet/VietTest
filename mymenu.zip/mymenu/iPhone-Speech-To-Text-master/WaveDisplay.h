//
//  WaveDisplay.h
//  SpeechToText
//
//  Created by Sam Bosley on 10/11/11.
//  Copyright (c) 2011 Astrid. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WaveDisplay : UIView

@property (retain) NSArray *dataPoints;

@end
