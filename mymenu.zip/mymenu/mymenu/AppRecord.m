#import "AppRecord.h"

@implementation AppRecord
@end

