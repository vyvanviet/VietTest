
#define kDefaultAnimationDuration   0.4

#define kDismissTextViewNotification @"kDismissTextViewNotification"

#define kHTTPScheme         @"http"
#define kAPIPath            @"54.225.97.109:3000"
#define kFullAPIPath        @"http://54.225.97.109:3000"

#define kEmailAddress       @"kEmailAddress"
#define kGuest              @"Guest"

#define kStatusKey          @"status"
#define kUpdateTopView      @"kUpdateTopView"
#define kUserLogout         @"kUserLogout"
#define kUserLogIn          @"kUserLogIn"
#define kBackToHomeNotification @"kBackToHomeNotification"
#define kItemSelected       @"kItemSelected"
#define kUpdateLocation     @"kUpdateLocation"

#define kFavoriteLocation   @"kFavoriteLocation"
#define kFavoriteItem       @"kFavoriteItem"

#define kLastSearchDate     @"kLastSearchDate"
#define kLastSearchResults  @"kLastSearchResults"

typedef NS_ENUM(NSInteger, UIScrollRegion ) {
    UIScrollRegionTop,
    UIScrollRegionMiddle,
    UIScrollRegionBottom
};