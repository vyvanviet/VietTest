//
//  FeedbackObject.h
//  mymenu
//
//  Created by Dang Duc Nam on 11/5/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FeedbackObject : NSObject
{
    NSString *avatarUrl;
    NSString *comment;
}
@property(nonatomic, retain)NSString *avatarUrl;
@property(nonatomic, retain)NSString *comment;

@end
