//
//  FeedbackObject.m
//  mymenu
//
//  Created by Dang Duc Nam on 11/5/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "FeedbackObject.h"

@implementation FeedbackObject

@synthesize avatarUrl;
@synthesize comment;

@end
