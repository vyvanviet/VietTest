//
//  LeftTabCell.h
//  Intelligent Menu
//
//  Created by RYAN VANALSTINE on 2/21/13.
//  Copyright (c) 2013 Agile Poet, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftTabCell : UITableViewCell
@property (nonatomic, assign) NSInteger indexPathRow;
@property (nonatomic, strong) NSArray *menuItems;
@property (nonatomic, assign) BOOL isRestaurantMenu;

+ (NSString *)reuseIdentifier;
@end
