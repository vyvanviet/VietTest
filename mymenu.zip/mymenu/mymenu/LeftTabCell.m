//
//  LeftTabCell.m
//  Intelligent Menu
//
//  Created by RYAN VANALSTINE on 2/21/13.
//  Copyright (c) 2013 Agile Poet, LLC. All rights reserved.
//

#import "LeftTabCell.h"
#import "UIView+FrameAdditions.h"

@interface LeftTabCell ()
@property (nonatomic, weak) IBOutlet UIImageView *iconImage;
@property (nonatomic, weak) IBOutlet UIImageView *topLine;
@property (nonatomic, weak) IBOutlet UIImageView *arrowImage;
@property (nonatomic, weak) IBOutlet UILabel *cellLabel;
@end

@implementation LeftTabCell
@synthesize iconImage;
@synthesize topLine;
@synthesize cellLabel;
@synthesize menuItems;
@synthesize indexPathRow;
@synthesize isRestaurantMenu;

+ (NSString *)reuseIdentifier {
    return NSStringFromClass(self);
}

#pragma mark Overrides
- (void)setIndexPathRow:(NSInteger)theIndexPathRow {
    indexPathRow = theIndexPathRow;
    //self.cellLabel.font = [UIFont RonniaBoldFontWithSize:20.];
    self.cellLabel.text = [self.menuItems objectAtIndex:self.indexPathRow];
    NSString *imageName = [self imageNameFromMenuItem:[self.menuItems objectAtIndex:self.indexPathRow]];
    self.iconImage.image = [UIImage imageNamed:imageName];
    
    if (self.indexPathRow == 0) {
        self.topLine.hidden = NO;
    }
    
    
}
- (void)setIsRestaurantMenu:(BOOL)aIsRestaurantMenu {
    isRestaurantMenu = aIsRestaurantMenu;
    self.arrowImage.hidden = YES;
    //[self.cellLabel setFrameXOffset:98.];
    [self.cellLabel setFrameXOffset:98.];
}

#pragma mark Private Methods
- (NSString *)imageNameFromMenuItem:(NSString *)menuItem {
    if ([menuItem isEqualToString:@"Home"]) {
        return @"icon_home.png";
    }
    
    if ([menuItem isEqualToString:@"MyFavorites"]) {
        return @"icon_favorites.png";
    }
    
    if ([menuItem isEqualToString:@"MySettings"]) {
        return @"icon_setting.png";
    }
    
    if ([menuItem isEqualToString:@"Reviews"]) {
        return @"icon_reviews.png";
    }
    
    if ([menuItem isEqualToString:@"MyPoints"]) {
        return @"icon_points.png";
    }
    
    if ([menuItem isEqualToString:@"MyNotifications"]) {
        return @"icon_notifications.png";
    }
    
    if ([menuItem isEqualToString:@"MyWallet"]) {
        return @"icon_wallet.png";
    }
    
    if ([menuItem isEqualToString:@"MyCalories"]) {
        return @"icon_calories.png";
    }
    
    if ([menuItem isEqualToString:@"MySearch"]) {
        return @"icon_search.png";
    }
    
    if ([menuItem isEqualToString:@"MyFriends"]) {
        return @"icon_friends.png";
    }
    
    if ([menuItem isEqualToString:@"My Tags"]) {
        return @"icon_tags.png";
    }
    
    if ([menuItem isEqualToString:@"My Ratings"]) {
        return @"icon_myratings.png";
    }
    
    if ([menuItem isEqualToString:@"My Server"]) {
        return @"icon_myservers.png";
    }
    
    if ([menuItem isEqualToString:@"Feedback"]) {
        return @"icon_notifications.png";
    }
    
    return @"";
}
@end
