
@interface NSString (EmailValidation)
-(BOOL) isValidEmailAddress;
@end
