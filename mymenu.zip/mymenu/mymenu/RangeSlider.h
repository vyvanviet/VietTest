//
//  RangeSlider.h
//  RangeSlider
//
//  Created by Charlie Mezak on 9/16/10.
//  Copyright 2010 Natural Guides, LLC. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol rangeslider_getdisplayprotocol   //define delegate protocol
- (NSString *) getMaxValue:(NSString *)value;  //define delegate method to be implemented within another class
- (NSString *) getMinValue:(NSString *)value;

@end //end protocol



@interface RangeSlider : UIControl {

	CGFloat min, max; //the min and max of the range	
	CGFloat minimumRangeLength; //the minimum allowed range size
	
	UIImageView *minSlider, *maxSlider, *backgroundImageView, *trackImageView, *inRangeTrackImageView; // the sliders representing the min and max, and a background view;
	UIView *trackingSlider; // a variable to keep track of which slider we are tracking (if either)
    UILabel *minValue;
    UILabel *maxValues;
    
}
@property (nonatomic, weak) id <rangeslider_getdisplayprotocol> delegate;
@property (nonatomic) CGFloat min, max, minimumRangeLength;
- (void)setMinThumbImage:(UIImage *)image;
- (void)setMaxThumbImage:(UIImage *)image;
- (void)setTrackImage:(UIImage *)image;
- (void)setInRangeTrackImage:(UIImage *)image;
@end
