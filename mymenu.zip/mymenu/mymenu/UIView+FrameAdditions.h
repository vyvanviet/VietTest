
@interface UIView (FrameAdditions)

-(void) setCenterXOffset: (CGFloat)xOffset;
-(void) setFrameXOffset: (CGFloat)xOffset;
-(void) setFrameYOffset: (CGFloat)yOffset;
-(void) setFrameWidth: (CGFloat)width;
-(void) setFrameHeight: (CGFloat)height;

@end
