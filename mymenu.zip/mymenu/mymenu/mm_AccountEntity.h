//
//  mm_AccountEntity.h
//  mymenu
//
//  Created by Dang Duc Nam on 10/29/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface mm_AccountEntity : NSObject

@property (nonatomic, strong) NSString *firstName;
@property (nonatomic, strong) NSString *lastName;
@property (nonatomic, strong) NSString *email;
@property (nonatomic, strong) NSString *username;
@property (nonatomic, strong) NSString *city;
@property (nonatomic, strong) NSString *state;
@property (nonatomic, strong) NSString *gender;
@property (nonatomic, strong) NSString *age;
@property (nonatomic, strong) NSString *password;
@property (nonatomic, strong) NSString *confirmPassword;
@property (nonatomic, strong) NSString *address;
@property (nonatomic, strong) NSString *zip;
@property (nonatomic, strong) NSString *status;
@property (nonatomic, strong) NSString *acces_token;
@property (nonatomic, strong) NSString *points;
@property (nonatomic, strong) NSString *avatar;
@property (nonatomic, strong) NSString *favourite;
@property (nonatomic, strong) NSString *DefaultSearchProfile;

@end
