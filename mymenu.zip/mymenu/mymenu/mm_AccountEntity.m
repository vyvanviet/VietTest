//
//  mm_AccountEntity.m
//  mymenu
//
//  Created by Dang Duc Nam on 10/29/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_AccountEntity.h"





@implementation mm_AccountEntity

@synthesize firstName;
@synthesize lastName;
@synthesize email;
@synthesize username;
@synthesize city;
@synthesize state;
@synthesize gender;
@synthesize age;
@synthesize password;
@synthesize confirmPassword;
@synthesize address;
@synthesize zip;
@synthesize status;
@synthesize acces_token;
@synthesize points;
@synthesize avatar;
@synthesize favourite;
@synthesize DefaultSearchProfile;

@end
