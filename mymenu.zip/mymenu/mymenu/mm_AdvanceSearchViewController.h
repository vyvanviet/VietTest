//
//  mm_AdvanceSearchViewController.h
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 11/2/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mm_AdvanceSearchViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>
{
    UITableView *tblProfile;
    IBOutlet UIButton *btnSave;
    IBOutlet UIButton *btnCreate;
}
@property (nonatomic,strong)UITableView *tblProfile;
@property (nonatomic,strong)IBOutlet UIButton *btnSave;
@property (nonatomic,strong)IBOutlet UIButton *btnCreate;
-(IBAction)MySearchclick:(id)sender;
-(IBAction)MyCreateProfileClick:(id)sender;
-(IBAction)MySaveProfileClick:(id)sender;
@end
