//
//  mm_AppDelegate.h
//  mymenu
//
//  Created by Le Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <FacebookSDK/FacebookSDK.h>
#import "mm_loginTwitterTask.h"

extern NSString *const FBSessionStateChangedNotification;
@interface mm_AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong, nonatomic) NSString *loggedInUserID;


@property (strong, nonatomic) FBSession *loggedInSession;

//- (BOOL)openSessionWithAllowLoginUI:(BOOL)allowLoginUI;
//- (void) closeSession;
@end
