//
//  mm_AppDelegate.m
//  mymenu
//
//  Created by Le Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_AppDelegate.h"
#import "string.h"
#import "FacebookSDK/FacebookSDK.h"
#import "mm_LoginViewController.h"


#import "mm_HomeViewController.h"

NSString *const FBSessionStateChangedNotification =
@"com.unitech.myMenu:FBSessionStateChangedNotification";
@implementation mm_AppDelegate
@synthesize loggedInUserID = _loggedInUserID;
@synthesize loggedInSession = _loggedInSession;




- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    //[GPPSignIn sharedInstance].clientID = googleplusapikey;
    // Read Google+ deep-link data.
    //[GPPDeepLink setDelegate:self];
    //[GPPDeepLink readDeepLinkAfterInstall];
    
    // Override point for customization after application launch.
    
    
    return YES;
}

- (BOOL)application:(UIApplication *)application
            openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication
         annotation:(id)annotation {
    NSString *userloginmode=[[NSUserDefaults standardUserDefaults]valueForKey:kUserLoginMode];
    /*if([userloginmode compare:@"google"]==NSOrderedSame){
        return [GPPURLHandler handleURL:url
                  sourceApplication:sourceApplication
                         annotation:annotation];
    }*/
    if([userloginmode compare:@"facebook"]==NSOrderedSame){
        return [FBAppCall handleOpenURL:url
                  sourceApplication:sourceApplication
                    fallbackHandler:^(FBAppCall *call) {
                      
                    }];
    }
    if([userloginmode compare:@"facebook_share"]==NSOrderedSame)
        return [FBAppCall handleOpenURL:url sourceApplication:sourceApplication];
    

}





- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}



- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // We need to properly handle activation of the application with regards to SSO
    // (e.g., returning from iOS 6.0 authorization dialog or from fast app switching).
    [FBAppCall handleDidBecomeActive];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // if the app is going away, we close the session object
    [FBSession.activeSession close];
}

#pragma mark - GPPDeepLinkDelegate

/*- (void)didReceiveDeepLink:(GPPDeepLink *)deepLink {
    // An example to handle the deep link data.
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Deep-link Data"
                          message:[deepLink deepLinkID]
                          delegate:nil
                          cancelButtonTitle:@"OK"
                          otherButtonTitles:nil];
    [alert show];
}*/

@end
