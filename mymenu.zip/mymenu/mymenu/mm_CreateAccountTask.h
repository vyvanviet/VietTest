//
//  mm_CreateAccountTask.h
//  mymenu
//
//  Created by Dang Duc Nam on 10/29/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_sycndata.h"
#import "mm_AccountEntity.h"
#import <Foundation/Foundation.h>
#import "mm_InfoUserSocial.h"

@protocol createAccountProtocol

- (void) createAccount_susscess:(mm_AccountEntity *)user accessToken:(NSString *)token;
- (void) createAccountSocial_susscess:(mm_InfoUserSocial *)user accessToken:(NSString *)token;
- (void) createAccount_unsusscess:(NSDictionary *) dict;
- (void) createAccountSocial_unsusscess:(NSString *) status;

@end

@interface mm_CreateAccountTask : mm_sycndata

@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <createAccountProtocol> delegate;
 
-(void)createAccount:(mm_AccountEntity *)newUser;
-(void)createAccountSocial:(mm_InfoUserSocial *)newUserSocial;

@end
