//
//  mm_CreateAccountViewController.h
//  mymenu
//
//  Created by Dang Duc Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mm_CreateAccountTask.h"
#import "mm_UpdateUserImageTask.h"
#import "mm_UpdateUserInfoTask.h"

@interface mm_CreateAccountViewController : UIViewController<UIPickerViewDataSource,UIPickerViewDelegate, createAccountProtocol, updateUserImageProtocol, updateUserInfoProtocol>
{
    IBOutlet UITextField *firstName;
    IBOutlet UITextField *lastName;
    IBOutlet UITextField *email;
    IBOutlet UITextField *username;
    IBOutlet UITextField *city;
    IBOutlet UITextField *state;
    IBOutlet UITextField *gender;
    IBOutlet UITextField *age;
    IBOutlet UITextField *password;
    IBOutlet UITextField *confirmPassword;
    IBOutlet UITextField *zipCode;
    IBOutlet UILabel *lblContent;
    IBOutlet UIButton *btnAdd;
    IBOutlet UIButton *btnSubmit;
    IBOutlet UIButton *btnCancel;
    IBOutlet UIScrollView *scrView;
    IBOutlet UIPickerView *pkGender;
    IBOutlet UIImageView *iconImage;
    IBOutlet UINavigationController *navicon;
    
    mm_CreateAccountTask *task;
    mm_UpdateUserInfoTask *taskUpdate;
    mm_UpdateUserImageTask *taskUpdateImage;
    
}
@property (nonatomic,strong) UIView *viewIndicator;
@property (strong, nonatomic)  IBOutlet UITextField *firstName;
@property (strong, nonatomic)  IBOutlet UINavigationController *navicon;
@property (strong, nonatomic)  IBOutlet UILabel *lblContent;
@property (strong, nonatomic)  IBOutlet UITextField *lastName;
@property (strong, nonatomic)  IBOutlet UITextField *email;
@property (strong, nonatomic)  IBOutlet UITextField *username;
@property (strong, nonatomic)  IBOutlet UITextField *city;
@property (strong, nonatomic)  IBOutlet UITextField *state;
@property (strong, nonatomic)  IBOutlet UITextField *gender;
@property (strong, nonatomic)  IBOutlet UITextField *age;
@property (strong, nonatomic)  IBOutlet UITextField *password;
@property (strong, nonatomic)  IBOutlet UITextField *confirmPassword;
@property (strong, nonatomic)  IBOutlet UITextField *zipCode;

@property (strong, nonatomic)  IBOutlet UIButton *btnAdd;

@property (strong, nonatomic)  IBOutlet UIButton *btnSubmit;
@property (strong, nonatomic)  IBOutlet UIButton *btnCancel;
@property (strong, nonatomic)  IBOutlet UIScrollView *scrView;
@property (strong, nonatomic)  IBOutlet UIPickerView *pkGender;
@property (strong, nonatomic)  IBOutlet UIImageView *iconImage;
@property(strong,nonatomic)NSString *temp;
@property(assign,nonatomic )NSRange rangeValue;
@property(strong,nonatomic)NSString *accessToken;

-(IBAction)btn_submit_click:(id)sender;
-(IBAction)btn_cancel_click:(id)sender;
-(IBAction)bar_back_click:(id)sender;
-(IBAction)bar_logo_click:(id)sender;

@end

