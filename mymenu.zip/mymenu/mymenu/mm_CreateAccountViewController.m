//
//  mm_CreateAccountViewController.m
//  mymenu
//
//  Created by Dang Duc Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_CreateAccountViewController.h"
#import "mm_CreateAccountTask.h"
#import "mm_UpdateUserInfoTask.h"
#import "mm_UpdateUserImageTask.h"
#import "mm_AccountEntity.h"
#import "PhotoPickerController.h"
#import "UIImage+Resize.h"
#import "NSString+EmailValidation.h"
#import "string.h"
#import "mm_InfoUserSocial.h"

typedef enum {
    statePickerTag = 0,
    genderPickerTag,
    
} PickerType;
bool isUpdate = false;

@interface mm_CreateAccountViewController () <UITextFieldDelegate, UIActionSheetDelegate, UIPickerViewDelegate, UIPickerViewDataSource, PhotoPickerDelegate>
{
    UITextField *activeField;
    CGPoint originalOffset;
}

    @property (nonatomic, strong) NSArray *genderArray;
    @property (nonatomic, strong) NSArray *stateArray;
    @property (nonatomic, strong) UIPickerView *pickerGender;
    @property (nonatomic, strong) UIPickerView *pickerState;
    @property (nonatomic, strong) UIImage *userIcon;

@end

@implementation mm_CreateAccountViewController

@synthesize firstName, lastName, email, username, city, state, gender, age, password, confirmPassword, btnAdd, btnCancel, btnSubmit, scrView, pkGender, iconImage, zipCode,temp,rangeValue,lblContent;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapGestureCaptured:)];
    [self.scrView addGestureRecognizer:singleTap];
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(keyboardWillShow:)
                                                 name: UIKeyboardWillShowNotification
                                               object: nil];
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(keyboardWillHide:)
                                                 name: UIKeyboardWillHideNotification
                                               object: nil];
    
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    isUpdate = [prefs boolForKey:kIsUpdateUser];
    temp = [prefs valueForKey:@"getFrom"];
    NSLog(@"getFrom =%@",temp);
    rangeValue = [temp rangeOfString:@"exists" options:NSCaseInsensitiveSearch];
    if (rangeValue.length > 0){        
        NSLog(@"string contains exists");
        [self bindUserInfo];
        self.iconImage.image = [UIImage imageNamed:@"noavatar.png"];     
    }
    else if(isUpdate){
        NSLog(@"Register user3");
        [self bindUserInfo];
    }else{
        NSLog(@"Register user1");
        self.userIcon = [UIImage imageNamed:@"noavatar.png"];
    }
}
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    isUpdate = [prefs boolForKey:kIsUpdateUser];
    temp = [prefs valueForKey:@"getFrom"];
    NSLog(@"getFrom =%@",temp);
    self.lblContent.textAlignment = NSTextAlignmentCenter;
    rangeValue = [temp rangeOfString:@"exists" options:NSCaseInsensitiveSearch];
    if (rangeValue.length > 0){        
        self.lblContent.text = @"Create User Account";  
    }
    else if(isUpdate){
        self.lblContent.text = @"Edit User Account";
    }else{
        self.lblContent.text = @"Create User Account";
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
}

-(void) showValidateDialogMessage:(NSString *)message{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Notice message"
                                                      message:message
                                                     delegate:self
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    [alert show];
}

-(IBAction)btn_submit_click:(id)sender{
    
    if (self.firstName.text.length == 0) {
        [self showValidateDialogMessage:@"First Name is required"];
        [self.firstName becomeFirstResponder];
        return;
    }else if (self.firstName.text.length > 30) {
        [self showValidateDialogMessage:@"First Name must be less than 30 characters"];
        [self.firstName becomeFirstResponder];
        return;
    }
    
    if (self.lastName.text.length == 0) {
        [self showValidateDialogMessage:@"Last Name is required"];
        [self.lastName becomeFirstResponder];
        return;
    }else if (self.lastName.text.length > 30) {
        [self showValidateDialogMessage:@"Last Name must be less than 30 characters"];
        [self.lastName becomeFirstResponder];
        return;
    }
       
    if (self.email.text.length == 0 )
    {
        [self showValidateDialogMessage:@"Email Address is required"];
        [self.email becomeFirstResponder];
        return;
    }else if(![self.email.text isValidEmailAddress]) {
        [self showValidateDialogMessage:@"Email Address is invalid"];
        [self.email becomeFirstResponder];
        return;
    }
    
    if (self.username.text.length == 0) {
        [self showValidateDialogMessage:@"Username is required"];
        [self.username becomeFirstResponder];
        return;
    }else if (self.username.text.length > 30 || self.username.text.length < 3) {
        [self showValidateDialogMessage:@"Username must be at least 3 characters and less than 30 characters"];
        [self.username becomeFirstResponder];
        return;
    }else{
        NSRange whiteSpaceRange = [username.text rangeOfCharacterFromSet:[NSCharacterSet whitespaceCharacterSet]];
        if (whiteSpaceRange.location != NSNotFound) {
            [self showValidateDialogMessage:@"Username not allow the input white space"];
            [self.username becomeFirstResponder];
            return;
        }
    }
    
    if (self.zipCode.text.length == 0 ) {
        [self showValidateDialogMessage:@"Zip code is required"];
        [self.zipCode becomeFirstResponder];
        return;
    }else if (self.zipCode.text.length < 5 )
    {
        [self showValidateDialogMessage:@"Zip code is invalid"];
        [self.zipCode becomeFirstResponder];
        return;
    }else if (self.zipCode.text.length > 5) {
        [self showValidateDialogMessage:@"Zipcode must be less than 5 digits"];
        [self.zipCode becomeFirstResponder];
        return;
    }
    
    if (self.password.text.length == 0) {
        [self showValidateDialogMessage:@"Password is required"];
        [self.password becomeFirstResponder];
        return;
    }else if (self.password.text.length > 50 || self.password.text.length < 5) {
        [self showValidateDialogMessage:@"Password must be at least 5 characters and less than 50 characters"];
        [self.password becomeFirstResponder];
        return;
    }
    
    if (self.confirmPassword.text.length == 0) {
        [self showValidateDialogMessage:@"Confirm Password is required"];
        [self.confirmPassword becomeFirstResponder];
        return;
    }
    
    if (![self.password.text isEqualToString:self.confirmPassword.text]) {
        [self showValidateDialogMessage:@"Your Password doesn't match confirmation."];
        [self.confirmPassword becomeFirstResponder];
        return;
    }
    rangeValue = [temp rangeOfString:@"exists" options:NSCaseInsensitiveSearch];
    mm_InfoUserSocial *userSocial=[[mm_InfoUserSocial alloc]init];
    mm_AccountEntity *newUser = [[mm_AccountEntity alloc]init];
    if (rangeValue.length > 0)
    {
        rangeValue = [temp rangeOfString:@"FB" options:NSCaseInsensitiveSearch];
      
    if (rangeValue.length > 0) {
            userSocial.provider=@"facebook";
        }
        else
        {
            rangeValue = [temp rangeOfString:@"Twitter" options:NSCaseInsensitiveSearch];
            if (rangeValue.length>0) {
                userSocial.provider=@"twitter";
            }
            else
            {
                rangeValue = [temp rangeOfString:@"Google" options:NSCaseInsensitiveSearch];
                if (rangeValue.length>0) {
                    userSocial.provider=@"google";
                }
            }
        }        
        userSocial.uid=[[UIDevice currentDevice] uniqueIdentifier];
        
        userSocial.email = self.email.text;
        userSocial.username = self.username.text;
        userSocial.password = self.password.text;
        userSocial.firstName = self.firstName.text;
        userSocial.lastName = self.lastName.text;
        userSocial.zip = self.zipCode.text;
        userSocial.address = @"02 Quang Trung";
        userSocial.city = @"";
        userSocial.state = @"";
        userSocial.gender = @"male";
    }
    else
    {
    newUser.email = self.email.text;
    newUser.username = self.username.text;
    newUser.password = self.password.text;
    newUser.firstName = self.firstName.text;
    newUser.lastName = self.lastName.text;
    newUser.zip = self.zipCode.text;
    newUser.address = @"02 Quang Trung";
    newUser.city = @"";
    newUser.state = @"";
    newUser.gender = @"male";
    }
    self.viewIndicator=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [self.viewIndicator setBackgroundColor: [UIColor clearColor]];
    UIActivityIndicatorView *activityView=[[UIActivityIndicatorView alloc]     initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    
    activityView.center=self.view.center;
    activityView.color = [UIColor grayColor];
    [activityView startAnimating];
    [self.viewIndicator addSubview:activityView];
    [self.view addSubview:self.viewIndicator];
    [self resignAllTextFields];
    if(isUpdate){
        taskUpdate = [[mm_UpdateUserInfoTask alloc]init];
        taskUpdate.delegate = self;
        [taskUpdate updateUserInfo:newUser];
    }else{
        rangeValue = [temp rangeOfString:@"exists" options:NSCaseInsensitiveSearch];
        if (rangeValue.length > 0){
            task=[[mm_CreateAccountTask alloc]init];
            task.delegate=self;
            [task createAccountSocial:userSocial];
            
        }
        else
        {
        task = [[mm_CreateAccountTask alloc]init];
        task.delegate = self;
        [task createAccount:newUser];
    }
}
}

//create account
- (void) createAccount_susscess:(mm_AccountEntity *)user accessToken:(NSString *)token{
    [self.viewIndicator removeFromSuperview];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:token forKey:kTokenkey];
    [defaults synchronize];
    [self saveUser:user];
    [self updateUserImage];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"getFrom"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    //[self performSegueWithIdentifier:@"registerGoToHome" sender:nil];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
        if([alertView.message isEqualToString:@"Created account successfully"]||[alertView.message isEqualToString:@"Edited account successfully"])
        {
            [self performSegueWithIdentifier:@"registerGoToHome" sender:nil];
        }
}

- (void) createAccountSocial_susscess:(mm_InfoUserSocial *)user accessToken:(NSString *)token{
    [self.viewIndicator removeFromSuperview];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:token forKey:kTokenkey];
    [defaults synchronize];
    [self saveUserSocial:user];
    [self updateUserImage];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"getFrom"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    //[self performSegueWithIdentifier:@"registerGoToHome" sender:nil];
}

- (void) createAccount_unsusscess:(NSDictionary *) dict{
    [self.viewIndicator removeFromSuperview];
    NSDictionary *error = [dict objectForKey:@"errors"];
    NSArray *emailErrArray = [error objectForKey:@"email"];
    NSArray *usernameErrArray = [error objectForKey:@"username"];
    NSArray *passErrArray = [error objectForKey:@"password"];
    
    NSString *errorStr = @"";
    NSString *emailError = @"";
    NSString *usernameError = @"";
    NSString *passwordError = @"";
    
    if(emailErrArray != NULL){
        emailError = [NSString stringWithFormat:@"Your email %@",[emailErrArray objectAtIndex:0]];
    }
    if(usernameErrArray != NULL){
        if(emailError==(id) [NSNull null] || [emailError length]==0 || [emailError isEqualToString:@""])
        {
            usernameError = [NSString stringWithFormat:@"Your username %@",[usernameErrArray objectAtIndex:0]];
        }else
        {
            usernameError = [NSString stringWithFormat:@". Your username %@",[usernameErrArray objectAtIndex:0]];
        }
    }
    if(passErrArray != NULL){
        if(emailError==(id) [NSNull null] || [emailError length]==0 || [emailError isEqualToString:@""] || usernameError ==(id) [NSNull null] || [usernameError length]==0 || [usernameError isEqualToString:@""])
        {
            passwordError = [NSString stringWithFormat:@"Your password %@",[passErrArray objectAtIndex:0]];
        }else
        {
            passwordError = [NSString stringWithFormat:@". Your password %@",[passErrArray objectAtIndex:0]];
        }
    }
    errorStr = [NSString stringWithFormat:@"%@%@%@.", emailError, usernameError, passwordError];
    
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Notice Message"
                                                      message:errorStr
                                                     delegate:self
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    [message show];
}
-(void) createAccountSocial_unsusscess:(NSString *)status
{
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"getFrom"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Notice message" message:@"Created account unsuccessfully"
                                                     delegate:self
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    [message show];
    
    [self.viewIndicator removeFromSuperview];
}

//update user info
-(void) updateUserInfo_success:(mm_AccountEntity *)userUpdate{
    [self.viewIndicator removeFromSuperview];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:false forKey:kIsUpdateUser];
    [defaults synchronize];
   
    [self saveUser:userUpdate];
    [self updateUserImage];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"getFrom"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    //[self performSegueWithIdentifier:@"registerGoToHome" sender:nil];
}
-(void) updateUserInfo_unsuccess:(NSDictionary *)dict{
    [self.viewIndicator removeFromSuperview];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"getFrom"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Notice message"
                                                      message:@"Edited account unsuccessfully"
                                                     delegate:self
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    [message show];
}

-(IBAction)btn_cancel_click:(id)sender{
    if([self.lblContent.text isEqualToString:@"Edit User Account"])
    {
        [self performSegueWithIdentifier:@"gotosettingfromcreate" sender:nil];
        //[self dismissViewControllerAnimated:YES completion:nil];
        //[self dismissModalViewControllerAnimated:YES co];
    }else
    {
        [self performSegueWithIdentifier:@"gotomainfromregister" sender:self.view];
    }
}

-(IBAction)bar_back_click:(id)sender{
    if([self.lblContent.text isEqualToString:@"Edit User Account"])
    {
        [self performSegueWithIdentifier:@"gotosettingfromcreate" sender:nil];
        //[self dismissViewControllerAnimated:YES completion:nil];
    }else
    {
        [self performSegueWithIdentifier:@"gotomainfromregister" sender:self];
    }
}
-(IBAction)bar_logo_click:(id)sender{
    [self backPrevScreen];
}

-(void) backPrevScreen{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    bool isMain = [prefs boolForKey:@"valueRegis"];
    if(isMain)
    {
        [self performSegueWithIdentifier:@"gotomainfromregister" sender:self];
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setBool:false forKey:@"valueRegis"];
        [defaults synchronize];
    }
    else
    {
        if(isUpdate){
            //[self dismissViewControllerAnimated:YES completion:nil];
            //[self performSegueWithIdentifier:@"gotoleftfromregister" sender:nil];
            [self performSegueWithIdentifier:@"gotosettingfromcreate" sender:self];
        }
        else {
            [self performSegueWithIdentifier:@"backToLoginForm" sender:self];
        }
    }
}
-(void) backPrevScreenCancel{
    NSUserDefaults *prefs = [NSUserDefaults standardUserDefaults];
    
    bool isMain = [prefs boolForKey:@"valueRegis"];
    if(isMain)
    {
        [self performSegueWithIdentifier:@"gotosettingfromcreate" sender:nil];
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        [defaults setBool:false forKey:@"valueRegis"];
        [defaults synchronize];
    }
    else
    {
        if(isUpdate){
            //[self dismissViewControllerAnimated:YES completion:nil];
            [self performSegueWithIdentifier:@"gotosettingfromcreate" sender:nil];
        }
        else {
            [self performSegueWithIdentifier:@"backToLoginForm" sender:nil];
        }
    }
}

//update image
-(void) updateUserImage{
    taskUpdateImage = [[mm_UpdateUserImageTask alloc]init];
    taskUpdateImage.delegate = self;
    [taskUpdateImage updateImage:self.userIcon];
}
- (void)textViewDidEndEditing:(UITextField *)textview {
    if(textview == confirmPassword)
    {
        [self resignAllTextFields];
    }
}
-(void) updateUserImage_success:(NSDictionary *)dict{
    [self.viewIndicator removeFromSuperview];
    NSLog(@"chay vo ham updateUserImage_susscess");
    NSString *avatarUrl = [dict objectForKey:@"avatar"];
    NSString *url = [NSString stringWithFormat:@"%@%@", domainmagrabbit, avatarUrl];
    NSLog(@"avatar url: %@", url);
    [self saveUserImage:url];
    NSString *stringMessage;
    if([self.lblContent.text isEqualToString:@"Edit User Account"])
    {
        stringMessage = @"Edited account successfully";
    }else
    {
        stringMessage = @"Created account successfully";
    }
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Notice message"
                                                    message:stringMessage
                                                   delegate:self
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
}

-(void) updateUserImage_unsuccess:(NSDictionary *)dict{
    [self.viewIndicator removeFromSuperview];
    NSString *stringMessage;
    if([self.lblContent.text isEqualToString:@"Edit User Account"])
    {
        stringMessage = @"Edited account unsuccessfully";
    }else
    {
        stringMessage = @"Created account unsuccessfully";
    }
        
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Notice message"
                                                    message:stringMessage
                                                   delegate:self
                                          cancelButtonTitle:@"OK"
                                          otherButtonTitles:nil];
    [alert show];
    NSLog(@"chay vo ham updateUserImage_unsuccess");
}

//bind user info to text fields
-(void)bindUserInfo{
    
    //bind field data
    self.lblContent.text = @"Edit Profile";
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    firstName.text = [defaults stringForKey:kFirstName];
    lastName.text = [defaults stringForKey:kLastName];
    zipCode.text = [defaults stringForKey:kzip];
    email.text = [defaults stringForKey:kEmail];
    username.text = [defaults stringForKey:kUserName];
    password.text = [defaults stringForKey:kPassword];
    confirmPassword.text = [defaults stringForKey:kPassword];
    
    //set image avatar
    NSString *avatarUrl = [defaults stringForKey:kavatar];
    UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:avatarUrl]]];
    self.iconImage.image = image;
    self.userIcon = image;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    NSLog(@"textFieldShouldReturn");
    if (textField == self.firstName) {
         [self.lastName becomeFirstResponder];
    } else if (textField == self.lastName) {
        [self.email becomeFirstResponder];
    }else if (textField == self.email) {
        [self.username becomeFirstResponder];
    } else if (textField == self.username) {
        [self.zipCode becomeFirstResponder];
    }else if (textField == self.zipCode) {
        [self.password becomeFirstResponder];
    } else if (textField == self.password) {
        [self.confirmPassword becomeFirstResponder];
    } else if(textField == self.confirmPassword)
    {
        [self resignAllTextFields];
    }
    return YES;
}
-(BOOL) shouldAutorotate {
    
    // Return YES for supported orientations
    return NO;
    
}
- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSUInteger newLength = [textField.text length] + [string length] - range.length;
    if (textField == self.firstName) {
        if([string isEqualToString:@" "])
        {
            return NO;
        }else
        {
            return (newLength > 30) ? NO : YES;
        }
    } else if (textField == self.lastName) {
        if([string isEqualToString:@" "])
        {
            return NO;
        }else
        {
            return (newLength > 30) ? NO : YES;
        }
    } else if (textField == self.username) {
        if([string isEqualToString:@" "])
        {
            return NO;
        }else
        {
        return (newLength > 30) ? NO : YES;
        }
    }else if (textField == self.zipCode) {
        return (newLength > 5) ? NO : YES;
    } else if (textField == self.password) {
        if([string isEqualToString:@" "])
        {
            return NO;
        }else
        {
        return (newLength > 50) ? NO : YES;
        }
    }else if (textField == self.confirmPassword) {
        if([string isEqualToString:@" "])
        {
            return NO;
        }else
        {
        return (newLength > 50) ? NO : YES;
        }
    }else if(textField == self.email)
    {
        if([string isEqualToString:@" "])
        {
            return NO;
        }else
        {
            return YES;
        }
    }
    else return YES;
}


#pragma mark -
#pragma mark PickerView DataSource

- (NSInteger)numberOfComponentsInPickerView:
(UIPickerView *)pickerView
{
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView
numberOfRowsInComponent:(NSInteger)component
{
    if(pickerView == self.pickerGender)
    {
        return self.genderArray.count;
    }
    else
    {
        NSLog(@"self.stateArray.count: %i", [self.stateArray count]);
        return self.stateArray.count;
        
    }
}

- (NSString *)pickerView:(UIPickerView *)pickerView
             titleForRow:(NSInteger)row
            forComponent:(NSInteger)component
{
    if(pickerView == self.pickerGender)
    {
        return [self.genderArray objectAtIndex:row];
    }
    else
    {
        return [self.stateArray objectAtIndex:row];
    }
}
#pragma mark -
#pragma mark PickerView Delegate
-(void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row
      inComponent:(NSInteger)component
{
    if(pickerView == self.pickerGender)
    {
        gender.text = [self.genderArray objectAtIndex:row];
        
    }
    else
    {
        state.text = [self.stateArray objectAtIndex:row];
        
    }
}

- (void)singleTapGestureCaptured:(UITapGestureRecognizer *)gesture {
    [self resignAllTextFields];
}

- (void)resignAllTextFields {
    NSLog(@"resign");
    [self.firstName resignFirstResponder];
    [self.lastName resignFirstResponder];
    [self.zipCode resignFirstResponder];
    [self.email resignFirstResponder];
    [self.username resignFirstResponder];
    [self.password resignFirstResponder];
    [self.confirmPassword resignFirstResponder];
}

- (IBAction)addIconButtonPressed:(id)sender {
    [self resignAllTextFields];
    
    [PhotoPickerController sharedController].delegate = self;
    [[PhotoPickerController sharedController] showPickerActionSheetWithNoPhotoOptionInView:self];
}

#pragma mark Photo Picker Delegates
- (void)setUserIconDateWithImage:(UIImage *)image {
    
    UIImage *resizedImage = [image thumbnailImage:114 transparentBorder:0 cornerRadius:0 interpolationQuality:1];
    self.userIcon = resizedImage;
    
    self.iconImage.image = image;
}
- (void)resetCurrentImage {
    self.userIcon = nil;
    self.iconImage.image = [UIImage imageNamed:@"noavatar.png"];
    
}
- (void)imageSelected:(UIImage *)image {
    [self setUserIconDateWithImage:image];
}

- (void)libraryImageSelected:(UIImage *)image {
    [self setUserIconDateWithImage:image];
}

#pragma mark - Notifications
- (void)keyboardWillShow: (NSNotification *) notification {
    NSDictionary* info = [notification userInfo];
    CGRect kbRect = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
	kbRect = [self.view convertRect:kbRect toView:nil];
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbRect.size.height, 0.0);
    self.scrView.contentInset = contentInsets;
    self.scrView.scrollIndicatorInsets = contentInsets;
    
    CGRect aRect = self.view.frame;
    CGFloat width = aRect.size.width;
    CGFloat height = aRect.size.height;
    CGRect frame = CGRectMake(aRect.origin.x, aRect.origin.y, height, width);
    aRect = frame;
    aRect.size.height -= kbRect.size.height;
    CGPoint fieldOrigin = [self.view convertPoint:activeField.frame.origin fromView:[activeField superview]];
    originalOffset = self.scrView.contentOffset;
    if (!CGRectContainsPoint(aRect, fieldOrigin) ) {
        CGRect fieldFrame = [self.scrView convertRect:activeField.frame fromView:[activeField superview]];
        [self.scrView scrollRectToVisible:fieldFrame animated:YES];
    }
}
- (void)keyboardWillHide: (NSNotification *) notification {
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    self.scrView.contentInset = contentInsets;
    self.scrView.scrollIndicatorInsets = contentInsets;
    [self.scrView setContentOffset:originalOffset animated:YES];
}

- (void)saveUser:(mm_AccountEntity *)user{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:user.firstName forKey:kFirstName];
    [defaults setObject:user.lastName forKey:kLastName];
    [defaults setObject:user.zip forKey:kzip];
    [defaults setObject:user.email forKey:kEmail];
    [defaults setObject:user.username forKey:kUserName];
    [defaults setObject:user.password forKey:kPassword];
    [defaults synchronize];
    NSLog(@"User saved");
}
- (void)saveUserSocial:(mm_InfoUserSocial *)user{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:user.firstName forKey:kFirstName];
    [defaults setObject:user.lastName forKey:kLastName];
    [defaults setObject:user.zip forKey:kzip];
    [defaults setObject:user.email forKey:kEmail];
    [defaults setObject:user.username forKey:kUserName];
    [defaults setObject:user.password forKey:kPassword];
    [defaults synchronize];
    NSLog(@"User saved %@", user.password);
}

- (void)saveUserImage:(NSString *)url{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:url forKey:kavatar];
    [defaults synchronize];
    NSLog(@"User saved");
}
@end
