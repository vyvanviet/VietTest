//
//  mm_CreateProfileViewController.h
//  mymenu
//
//  Created by Le Nam on 11/4/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RangeSlider.h"

@interface mm_CreateProfileViewController : UIViewController
{
   // IBOutlet RangeSlider *rsItemPrice;
    RangeSlider *rsItemPrice;
     RangeSlider *rsItemRating;
     RangeSlider *rsServerRating;
     RangeSlider *rsDistanceLocation;
     RangeSlider *rsPointsOffer;
     RangeSlider *rsRestaurantRating;
    IBOutlet UIButton *btnTypesSelect;
    IBOutlet UIButton *btnGenreSelect;
    IBOutlet UILabel *lblTypesSelect;
    IBOutlet UILabel *lblGenreSelect;
    
    IBOutlet UIButton *btnSave;
    IBOutlet UIButton *btnSearch;
    IBOutlet UIButton *btnCancel;
    IBOutlet UITextField *txfName;
    IBOutlet UIScrollView *sclView;
    
}
@property (nonatomic,strong)  RangeSlider *rsItemPrice;
@property (nonatomic,strong)  RangeSlider *rsItemRating;
@property (nonatomic,strong)  RangeSlider *rsServerRating;
@property (nonatomic,strong)  RangeSlider *rsDistanceLocation;
@property (nonatomic,strong)  RangeSlider *rsPointsOffer;
@property (nonatomic,strong)  RangeSlider *rsRestaurantRating;
@property (nonatomic,strong)   IBOutlet UITextField *txfName;
@property (nonatomic,strong) IBOutlet UIButton *btnTypesSelect;
@property (nonatomic,strong) IBOutlet UIButton *btnGenreSelect;
@property (nonatomic,strong) IBOutlet UILabel *lblTypesSelect;
@property (nonatomic,strong) IBOutlet UILabel *lblGenreSelect;

@property (nonatomic,strong) IBOutlet UIButton *btnSave;
@property (nonatomic,strong) IBOutlet UIButton *btnSearch;
@property (nonatomic,strong) IBOutlet UIButton *btnCancel;
@property (nonatomic,strong)     IBOutlet UIScrollView *sclView;

@end
