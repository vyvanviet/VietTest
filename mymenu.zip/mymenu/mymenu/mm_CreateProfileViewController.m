//
//  mm_CreateProfileViewController.m
//  mymenu
//
//  Created by Le Nam on 11/4/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_CreateProfileViewController.h"

@interface mm_CreateProfileViewController ()

@end

@implementation mm_CreateProfileViewController
@synthesize btnCancel,btnGenreSelect,btnSave,btnSearch,btnTypesSelect,sclView,lblGenreSelect,lblTypesSelect,rsDistanceLocation,rsItemPrice,rsItemRating,rsPointsOffer,rsRestaurantRating,rsServerRating,txfName;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
       
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
  rsItemPrice=  [[RangeSlider alloc] initWithFrame:CGRectMake(10, 60, 300, 34)];
     NSLog(@"%f-%f",rsItemPrice.frame.size.width,rsItemPrice.frame.size.height);
    rsItemPrice.minimumRangeLength = .03;
    
    rsItemRating=  [[RangeSlider alloc] initWithFrame:CGRectMake(10, 130, 300, 34)];
    NSLog(@"%f-%f",rsItemPrice.frame.size.width,rsItemPrice.frame.size.height);
    rsItemRating.minimumRangeLength = .03;
    rsServerRating=  [[RangeSlider alloc] initWithFrame:CGRectMake(10, 200, 300, 34)];
    NSLog(@"%f-%f",rsItemPrice.frame.size.width,rsItemPrice.frame.size.height);
    rsServerRating.minimumRangeLength = .03;
    rsDistanceLocation=  [[RangeSlider alloc] initWithFrame:CGRectMake(10, 270, 300, 34)];
    NSLog(@"%f-%f",rsItemPrice.frame.size.width,rsItemPrice.frame.size.height);
    rsDistanceLocation.minimumRangeLength = .03;
    rsPointsOffer=  [[RangeSlider alloc] initWithFrame:CGRectMake(10,340, 300, 34)];
    NSLog(@"%f-%f",rsItemPrice.frame.size.width,rsItemPrice.frame.size.height);
    rsPointsOffer.minimumRangeLength = .03;

    rsRestaurantRating=  [[RangeSlider alloc] initWithFrame:CGRectMake(10,420, 300, 34)];
    NSLog(@"%f-%f",rsItemPrice.frame.size.width,rsItemPrice.frame.size.height);
    rsRestaurantRating.minimumRangeLength = .03;
    [self.sclView addSubview:rsItemPrice];
    
    [self.sclView addSubview:rsItemRating];
    [self.sclView addSubview:rsServerRating];
    [self.sclView addSubview:rsDistanceLocation];
    [self.sclView addSubview:rsPointsOffer];
    
    [self.sclView addSubview:rsRestaurantRating];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
