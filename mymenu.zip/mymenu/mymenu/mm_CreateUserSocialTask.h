//
//  mm_CreateUserSocialTask.h
//  mymenu
//
//  Created by vo thanh hung on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "mm_sycndata.h"
#import "JSON.h"
#import "mm_AccountEntity.h"

@protocol registerSocialsusscessProtocol   //define delegate protocol
- (void) register_susscess:(NSString *) token;  //define delegate method to be implemented within another class
- (void) register_unsusscess;

@end //end protocol

@interface mm_CreateUserSocialTask : mm_sycndata
{
    
    NSString *postdata;
}
@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <registerSocialsusscessProtocol> delegate;
-(void)registerAcc:(NSString *)uid provider:(NSString *)pro email:(NSString *)_email info:(mm_AccountEntity *)info;
@end