//
//  mm_CreateUserSocialTask.m
//  mymenu
//
//  Created by vo thanh hung on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_CreateUserSocialTask.h"
#import "string.h"

@implementation mm_CreateUserSocialTask
@synthesize postdata;
@synthesize delegate;
- (NSString *)createJSONFromDictionary:(NSDictionary *)dictionary {
    NSError* error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:kNilOptions error:&error];
    if (!error) {
        NSString* jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return jsonString;
    } else {
        return nil;
    }
}



-(void)registerAcc:(NSString *)uid provider:(NSString *)pro email:(NSString *)_email info:(mm_AccountEntity *)info
{
    NSMutableDictionary *mutableDictionary = [NSMutableDictionary new];
    
    NSString *firstName = info.firstName;
    NSString *lastName = info.lastName;
    NSString *address = info.address;
    NSString *city = info.city;
    NSString *state = info.state;
    NSString *zip = info.zip;
    NSString *gender = info.gender;
    NSString *email1 = info.email;
    
    


   [mutableDictionary setObject:uid forKey:@"uid"];
   
    [mutableDictionary setObject:pro forKey:@"provider"];
    

    
    [mutableDictionary setObject:email1 forKey:@"email"];
    
    
    [mutableDictionary setObject:info.username forKey:@"username"];
    [mutableDictionary setObject:info.password forKey:@"password"];
    [mutableDictionary setObject:firstName forKey:@"firstName"];
    [mutableDictionary setObject:lastName forKey:@"lastName"];
    [mutableDictionary setObject:address forKey:@"address"];
    [mutableDictionary setObject:city forKey:@"city"];
    [mutableDictionary setObject:state forKey:@"state"];
    [mutableDictionary setObject:zip forKey:@"zip"];
    [mutableDictionary setObject:gender forKey:@"gender"];

    
    NSDictionary *userInfo = [NSDictionary dictionaryWithDictionary:mutableDictionary];
    postdata=[self createJSONFromDictionary:userInfo];
    NSLog(@"login postdata create= %@",postdata);
   [self request:registersocialurl];
}
-(void)request:(NSString *)url;
{
    //Declare NSData postData
	NSData *postData = [postdata dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
	
	//Declare NSString postLength and get length postData
	NSString *postLength = [NSString stringWithFormat:@"%d",[postData length]];
	
	//Declare NSMutableURLRequest request_url
    NSString *getVideoURL =url;
    
	NSMutableURLRequest *request_url = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",getVideoURL ]]                                         cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
                                                           timeoutInterval:1];
	//use method GET of request_url and set value of NSMutableURLRequest
	[request_url setHTTPMethod:@"POST"];
	[request_url setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request_url setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Current-Type"];
	[request_url setHTTPBody:postData];
    [request_url setTimeoutInterval:100];
	
	//init NSURLConnection connectionURL
	connectionURL = [[NSURLConnection alloc] initWithRequest:request_url delegate:self];
	if (connectionURL) {
        datacontent = [NSMutableData data] ;
	}
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [datacontent setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
    [datacontent appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    
	
	datacontent = nil;
    [self.delegate register_unsusscess];
    
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *cotentfromserver= [[NSString alloc]initWithData:datacontent encoding:NSUTF8StringEncoding];
    NSLog(@"cotentfromserver = %@",cotentfromserver);
    
    NSString *userid=[cotentfromserver
                      stringByReplacingOccurrencesOfString:@"[" withString:@""];
    
    userid=[userid
            stringByReplacingOccurrencesOfString:@"]" withString:@""];
    
    userid=[userid
            stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    
    NSString *returnData = [self parseData:cotentfromserver];
    
    NSLog(@"status = %@",returnData);
    
    //NSComparisonResult res1 = [cotentfromserver compare:[NSString stringWithFormat:@"%@",@"ln:0"]];
     if ([returnData isEqualToString:@"failed"]) {
        
        [self.delegate register_unsusscess];
        
        
    }else {
        
        [self.delegate register_susscess:returnData];
        
        
    }
    
    //[parser release];
    
}
-(NSString*)parseData:(NSString *)content{
    
    NSDictionary *jsonDict = [content JSONValue];
    NSString *status=[jsonDict objectForKey:@"access_token"];
    if([status length] >0)
    {
        return  status;
    }
    else
        return @"failed";
    
    
}
@end
