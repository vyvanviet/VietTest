//
//  mm_FeedbackLocationCell.h
//  mymenu
//
//  Created by Dang Duc Nam on 11/6/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mm_FeedbackLocationCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *contentBackground;
@property (weak, nonatomic) IBOutlet UIView *bgContent;
@property (weak, nonatomic) IBOutlet UITextView *content;
@property (weak, nonatomic) IBOutlet UIImageView *rateImage;
@property (weak, nonatomic) IBOutlet UIImageView *avatar;
@property (weak, nonatomic) IBOutlet UILabel *dateFeedback;


+ (NSString *)reuseIdentifier;

@end


