//
//  mm_FeedbackLocationCell.m
//  mymenu
//
//  Created by Dang Duc Nam on 11/6/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_FeedbackLocationCell.h"
#import "string.h"

@implementation mm_FeedbackLocationCell

+ (NSString *)reuseIdentifier {
    return NSStringFromClass(self);
}
@synthesize content;
@synthesize avatar;
@synthesize rateImage;
@synthesize bgContent;
@synthesize contentBackground;
@synthesize dateFeedback;
@end
