//
//  mm_FeedbackLocationCell2.m
//  mymenu
//
//  Created by Dang Duc Nam on 11/11/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_FeedbackLocationCell2.h"

@implementation mm_FeedbackLocationCell2
+ (NSString *)reuseIdentifier {
    return NSStringFromClass(self);
}
@synthesize content;
@synthesize avatar;
@synthesize rateImage;
@synthesize bgContent;
@synthesize contentBackground;
@synthesize dateFeedback;
@end
