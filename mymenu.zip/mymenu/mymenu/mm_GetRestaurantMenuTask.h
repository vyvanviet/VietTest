//
//  mm_GetRestaurantMenuTask.h
//  mymenu
//
//  Created by Le Nam on 11/5/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//
#import "mm_sycndata.h"

#import <Foundation/Foundation.h>
@protocol getrestaurantmenuProtocol   //define delegate protocol
- (void) getdata_success:(NSMutableArray *) restaurantArray;  //define delegate method to be implemented within another class
- (void) getdata_unsusscess:(NSString *)error;

@end //end protocol

@interface mm_GetRestaurantMenuTask : mm_sycndata
{
    NSString *postdata;
}
@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <getrestaurantmenuProtocol> delegate;
-(void)seach:(NSString *)location_id access_token:(NSString *)token;
@end
