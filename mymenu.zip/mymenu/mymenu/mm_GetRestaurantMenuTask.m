//
//  mm_GetRestaurantMenuTask.m
//  mymenu
//
//  Created by Le Nam on 11/5/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//
#import "JSON.h"
#import "mm_GetRestaurantMenuTask.h"
#import "string.h"
#import "mm_MenuCatalogy.h"
#import "mm_Menu.h"
@implementation mm_GetRestaurantMenuTask
@synthesize postdata;
@synthesize delegate;
-(void)seach:(NSString *)location_id access_token:(NSString *)token {

postdata=[NSString stringWithFormat:@"access_token=%@",token];
    NSString *url=[NSString stringWithFormat:@"%@%@%@%@",searchrestaurantlurl,location_id,@"/menu.json?",postdata];
     [self request:searchrestaurantlurl];
}
-(void)request:(NSString *)url;
{
    //Declare NSData postData

	NSLog(@"search url = %@",url);
	
	//Declare NSMutableURLRequest request_url
    NSString *getVideoURL =url;
    
	NSMutableURLRequest *request_url = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",getVideoURL ]]                                         cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
                                                           timeoutInterval:1];
	//use method GET of request_url and set value of NSMutableURLRequest
	[request_url setHTTPMethod:@"GET"];
	//[request_url setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request_url setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Current-Type"];
	//[request_url setHTTPBody:postData];
    [request_url setTimeoutInterval:100];
	
	//init NSURLConnection connectionURL
	connectionURL = [[NSURLConnection alloc] initWithRequest:request_url delegate:self];
	if (connectionURL) {
        datacontent = [NSMutableData data] ;
	}
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [datacontent setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
    [datacontent appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    
	
	datacontent = nil;
    [self.delegate getdata_unsusscess:@"Connection Fail"];
    
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *cotentfromserver= [[NSString alloc]initWithData:datacontent encoding:NSUTF8StringEncoding];
    NSLog(@"cotentfromserver = %@",cotentfromserver);
    NSMutableArray *array=[self parseData:cotentfromserver];
     [self.delegate getdata_success:array];
}

-(NSMutableArray*)parseData:(NSString *)conntent{
    {
    // NSString *mcontent=@"{\"menus\":[{\"id\":1,\"name\":\"A+\",\"reward_points\":10,\"items\":[{\"id\":1,\"name\":\"Cafe\",\"price\":700,\"description\":\"\",\"calories\":null,\"reward_points\":123,\"category_id\":1,\"special_message\":\"Doublepointtomorrow\",\"rating\":\"90.0\",\"image\":\"\/uploads\/item\/logo\/1\/image002.jpg\",\"review\":3,\"},}],\"isFavorite\":[{\"id\":1}],\"isNexttime\":[{\"id\":1}]}";
        
    NSMutableArray *dataArray=[[NSMutableArray alloc]init];
    
    NSDictionary *jsonDict = [conntent JSONValue];
    
    NSArray *menuArray=[jsonDict objectForKey:@"menus"];
   
        NSLog(@"menuArray.count = %d",menuArray.count);
        for (int i=0; i<menuArray.count; i++) {
                 NSDictionary *objectJson=[[NSDictionary alloc]initWithDictionary:[menuArray objectAtIndex:i]];
            mm_MenuCatalogy *catalogy=[[mm_MenuCatalogy alloc]init];
            catalogy.mid=[objectJson objectForKey:@"id"];
            
            catalogy.name=[objectJson objectForKey:@"name"];
            
            catalogy.reward_points=[objectJson objectForKey:@"reward_points"];
            catalogy.isFavorite=@"0";

            catalogy.isNexttime=@"0";
            int numberfavorite=0;
            int numbernexttime=0;
            NSArray *isFavoriteArray=[objectJson objectForKey:@"isFavorite"];
            NSArray *isNextTime=[objectJson objectForKey:@"isNexttime"];
            NSArray *items=[objectJson objectForKey:@"items"];
            NSMutableArray *itemArray=[[NSMutableArray alloc]init];
             for (int j=0; j<items.count; j++) {
                  NSDictionary *itemOjb=[[NSDictionary alloc]initWithDictionary:[items objectAtIndex:j]];
                 mm_Menu *menu=[[mm_Menu alloc]init];
                 menu.mid=[itemOjb objectForKey:@"id"];
                 menu.name=[itemOjb objectForKey:@"name"];
                 menu.price=[itemOjb objectForKey:@"price"];
                 menu.description=[itemOjb objectForKey:@"description"];
                 menu.calories=[itemOjb objectForKey:@"calories"];
                 menu.reward_points=[itemOjb objectForKey:@"reward_points"];
                 menu.category_id=[itemOjb objectForKey:@"category_id"];
                 menu.special_message=[itemOjb objectForKey:@"special_message"];
                 menu.rating=[itemOjb objectForKey:@"rating"];
                 menu.image=[itemOjb objectForKey:@"image"];
                 menu.review=[itemOjb objectForKey:@"review"];
                 [itemArray addObject:menu];
                 
             }
            for (int k=0; k<isFavoriteArray.count; k++) {
                
                NSDictionary *objectJson=[[NSDictionary alloc]initWithDictionary:[isFavoriteArray objectAtIndex:k]];
                NSString *mid=[objectJson objectForKey:@"id"];
                for (int j=0;j< itemArray.count; j++) {
                    mm_Menu *menu=[itemArray objectAtIndex:j];
                    if ([mid compare:menu.mid]==NSOrderedSame) {
                        menu.isFavorite=@"1";
                        numberfavorite++;
                    }
                }
                
            }
            
            for (int k=0; k<isNextTime.count; k++) {
                NSDictionary *objectJson=[[NSDictionary alloc]initWithDictionary:[isFavoriteArray objectAtIndex:k]];
                NSString *mid=[objectJson objectForKey:@"id"];
                for (int j=0;j< itemArray.count; j++) {
                    mm_Menu *menu=[itemArray objectAtIndex:j];
                    if ([mid compare:menu.mid]==NSOrderedSame) {
                        menu.isNexttime=@"1";
                        numbernexttime++;
                    }
                }
                
                
            }
            catalogy.itemsMenu=itemArray;
            catalogy.isNexttime=[NSString stringWithFormat:@"%d",numbernexttime];
            catalogy.isFavorite=[NSString stringWithFormat:@"%d",numberfavorite];
            [dataArray addObject:catalogy];
        }
        
           return dataArray;
    
    // return  returnData;
}
}
@end
