//
//  mm_HomeViewController.h
//  mymenu
//
//  Created by Le Cao Hoai Yen on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "SpeechToTextModule.h"
#import "JSON.h"
@interface mm_HomeViewController : UIViewController<MKMapViewDelegate,UITextFieldDelegate>
{
    UIButton *btnSubmit;
    UIButton *btnCancel;
	SpeechToTextModule *stt;
}
- (IBAction)myMenuPressed:(id)sender;
- (IBAction)mySearchPressed:(id)sender;
- (IBAction)GoogleVoicePressed:(id)sender;
@end
