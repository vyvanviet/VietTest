//
//  mm_HomeViewController.m
//  mymenu
//
//  Created by Le Cao Hoai Yen on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_HomeViewController.h"
#import <MapKit/MapKit.h>
#import "mm_SeachNomalTask.h"
#import "mm_LocationObject.h"
#import "string.h"
#import <QuartzCore/QuartzCore.h>
#import "mm_RestaurantViewController.h"
#define span 40000

@interface mm_HomeViewController ()<MKMapViewDelegate,UISearchBarDelegate,UITableViewDataSource, UITableViewDelegate,searchnormalusscessProtocol,CLLocationManagerDelegate,UITextFieldDelegate>

@property (nonatomic, weak) IBOutlet MKMapView *mapView;
@property (nonatomic, weak) IBOutlet UIButton *expandButton;
@property (nonatomic, strong) IBOutlet UITableView *locationTable;
@property (nonatomic, weak) IBOutlet UISearchBar *locationSearchBar;
@property (nonatomic, weak) IBOutlet UIActivityIndicatorView *locationIndicator;
@property (nonatomic, weak) IBOutlet NSLayoutConstraint *mapViewBottom;
@property (nonatomic, weak) IBOutlet NSLayoutConstraint *tableViewHeight;
@property (nonatomic, assign) BOOL mapViewExpanded;
@property (nonatomic, strong) NSString *firstLongitude;
@property (nonatomic, strong) NSString  *firstLatitude;
@property (nonatomic, assign) NSString *accessToken;
@property(nonatomic,retain)NSMutableArray *dataShow;
@property (nonatomic,strong)NSArray *dataGet;
@property(nonatomic,strong)IBOutlet UIImageView *imageLogo;
@property(nonatomic,strong) IBOutlet UILabel *lbName;
@property(nonatomic,strong) IBOutlet UILabel *lbAdd;
@property (nonatomic,strong) NSMutableArray *dataViewMap;
@property (nonatomic,strong) UIView *myView;
@property (nonatomic,strong) UIView *viewIndicator;
@property(nonatomic,strong) NSString *dataSearch;
@property(nonatomic,strong)UITextField *txtKeySearch;
@property(nonatomic,assign)BOOL *checkSearchNormal;
@property(nonatomic,strong)UIImage *imageCheck;
@property(nonatomic,strong)UIImage *imageNotCheck;
@property(nonatomic,strong)UIButton *btnCheck;
@property (nonatomic,strong)CLLocationManager *locationManager;
@property(nonatomic,strong) NSString *latitudeCheck;
@property(nonatomic,strong) NSString *longitudeCheck;
@property(nonatomic,strong)MKPointAnnotation *annotation;
@property(nonatomic,strong)UILabel *noDataSearch;
@end

@implementation mm_HomeViewController
@synthesize  mapView,expandButton,locationSearchBar,locationIndicator,mapViewBottom,tableViewHeight,mapViewExpanded,firstLatitude,firstLongitude,accessToken,locationTable,dataShow,dataGet,imageLogo,lbName,lbAdd,dataViewMap;
@synthesize myView,dataSearch,txtKeySearch,checkSearchNormal,imageCheck,btnCheck,imageNotCheck,viewIndicator,locationManager,longitudeCheck,latitudeCheck,annotation,noDataSearch;


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    //stt = [[SpeechToTextModule alloc] initWithCustomDisplay:NULL];
    //stt.delegate=self;

    self.mapView.delegate=self;
    self.mapViewExpanded = YES;
    self.locationSearchBar.delegate=self;
    //self.locationTable.delegate=self;
    locationManager = [[CLLocationManager alloc] init];
    locationManager.delegate = self;
    locationManager.desiredAccuracy = kCLLocationAccuracyBest;
    locationManager.distanceFilter = kCLDistanceFilterNone;
    [locationManager startUpdatingLocation];    
    //CLLocation *location = [locationManager location];
    //CLLocationCoordinate2D coordinate = [location coordinate];
    self.firstLatitude=@"0.000000";
    self.firstLatitude=@"0.000000";
    self.accessToken= [[NSUserDefaults standardUserDefaults] objectForKey:kTokenkey];
    dataSearch=[[NSString alloc]init];
    checkSearchNormal=FALSE;    
}
- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
{
//    self.latitudeCheck=[NSString stringWithFormat:@"%f",[self.locationManager location].coordinate.latitude];
//    self.longitudeCheck=[NSString stringWithFormat:@"%f",[self.locationManager location].coordinate.longitude];
    self.latitudeCheck=[NSString stringWithFormat:@"%f",newLocation.coordinate.latitude];
    self.longitudeCheck=[NSString stringWithFormat:@"%f",newLocation.coordinate.longitude];
//    NSLog(@"ssss new%f",newLocation.coordinate.latitude);
//    NSLog(@"aaaa new%f",newLocation.coordinate.longitude);
    NSLog(@"ssss%@",self.latitudeCheck);
    NSLog(@"aaaa%@",self.longitudeCheck);
    //[locationManager stopUpdatingLocation];
    
    if (![self.latitudeCheck isEqual: self.firstLatitude] && ![self.longitudeCheck isEqual: self.firstLongitude]) {
        CLLocation *firstLocation = [[CLLocation alloc] initWithLatitude:[self.firstLatitude floatValue] longitude:[self.firstLongitude floatValue]];
        
        CLLocation *afterLocation = [[CLLocation alloc] initWithLatitude:[self.latitudeCheck floatValue] longitude:[self.longitudeCheck floatValue]];
        
        CLLocationDistance distance = [firstLocation distanceFromLocation:afterLocation];
        NSLog(@"distance %f",distance);
        if (distance/1000>1) {
            self.firstLatitude=self.latitudeCheck;
            self.firstLongitude=self.longitudeCheck;
            dataSearch=@"";
            mm_SeachNomalTask *searchTask=[[mm_SeachNomalTask alloc]init];
            searchTask.delegate=self;
            [searchTask search:self.accessToken latitude:latitudeCheck longitude:longitudeCheck name:dataSearch];
            //[searchTask search:self.accessToken latitude:@"16.071898" longitude:@"108.225178" name:dataSearch];
            [locationTable reloadData];
            [self showIndicator];
        }
    }
}
- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error
{
    NSLog(@"didFailWithError: %@", error);
    UIAlertView *errorAlert = [[UIAlertView alloc]
                               initWithTitle:@"Error" message:@"Failed to Get Your Location" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [errorAlert show];
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    NSLog(@"textFieldShouldBeginEditing");
    textField.backgroundColor = [UIColor colorWithRed:220.0f/255.0f green:220.0f/255.0f blue:220.0f/255.0f alpha:1.0f];
    return YES;
}
- (void)textFieldDidBeginEditing:(UITextField *)textField{
    NSLog(@"textFieldDidBeginEditing");
}
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
}
- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:animated];
    
}
- (void)viewWillDisappear:(BOOL)animated {
    
    [super viewWillDisappear:animated];
    
    [self.locationSearchBar resignFirstResponder];
    
}
-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
    UITouch *touch = [[event allTouches] anyObject];
    if ([self.locationSearchBar isFirstResponder] && [touch view] != self.locationSearchBar)
    {
        [self.locationSearchBar resignFirstResponder];
    }
    [super touchesBegan:touches withEvent:event];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
}        
//- (IBAction)expandButtonPressed:(id)sender {
//    self.locationTable.hidden = YES;
//    if (self.mapViewExpanded) {
//        self.mapViewBottom.constant = 300.;
//        //self.tableViewHeight.constant = 300.;
//        if (!IS_IPHONE5) {
//            self.mapView.userInteractionEnabled = NO;
//        }
//    } else {
//        self.mapViewBottom.constant = 160.;
//        //self.tableViewHeight.constant = 160.;
//        self.mapView.userInteractionEnabled = YES;
//    }
//    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
//        if (self.mapViewExpanded) {
//            //self.locationTable setFrameYOffset:181.];
//            self.tableViewHeight.constant = 300.;
//        } else {
//            //[self.locationTable setFrameYOffset:344.];
//            self.tableViewHeight.constant = 160.;
//        }
//        [self.view layoutIfNeeded];
//    } completion: ^(BOOL finished)  {
//        self.locationTable.hidden = NO;
//    }];
//    self.mapViewExpanded = !self.mapViewExpanded;
//}
- (IBAction)myMenuPressed:(id)sender;
{
    [self performSegueWithIdentifier:@"gotoleftfromhome" sender:nil];
}
- (IBAction)mySearchPressed:(id)sender
{
    /*ngocptn
    [self performSegueWithIdentifier:@"gotoadvancesearchfromhome" sender:nil];
     */
}
- (void) searchnormal_susscess:(NSMutableArray *) array
{
    noDataSearch.hidden=YES;
    locationTable.hidden=NO;
    dataShow=[NSMutableArray arrayWithCapacity:array.count];
    dataShow=array;
    [self showLocationInMap:dataShow];
    [self.locationTable reloadData];    
}
- (void) searchnormal_unsusscess
{
    locationTable.hidden=YES;
    noDataSearch=[[UILabel alloc]initWithFrame:CGRectMake(locationTable.frame.origin.x , locationTable.frame.origin.y, locationTable.frame.size.width , locationTable.frame.size.height)];
    noDataSearch.text=@"No Data Search";
    [noDataSearch setBackgroundColor:[UIColor blackColor]];
    [noDataSearch setTextColor:[UIColor whiteColor]];
    [self.view addSubview:noDataSearch];
    NSLog(@"Khong co data do loi search");
    [dataShow removeAllObjects];    
    [locationTable reloadData];
    [viewIndicator removeFromSuperview];
    [mapView removeAnnotations:mapView.annotations];
    
}
- (void) showLocationInMap:(NSMutableArray *) array
{
    [mapView removeAnnotations:mapView.annotations];
    for (int i=0; i<array.count; i++) {
        mm_LocationObject *obj= [dataShow objectAtIndex:i];
        CLLocationCoordinate2D location=CLLocationCoordinate2DMake([obj.latitude doubleValue], [obj.longitude doubleValue]);        
        MKCoordinateRegion region=MKCoordinateRegionMakeWithDistance(location,span ,span );
        MKCoordinateRegion adjustedRegion = [self.mapView regionThatFits:region];
        [self.mapView setRegion:adjustedRegion animated:YES];
        annotation = [[MKPointAnnotation alloc]init];
        annotation.coordinate=location;
        annotation.title=[NSString stringWithFormat: @"%@",obj.name];
        [self.mapView   addAnnotation:annotation];
    }
    [viewIndicator removeFromSuperview];
}
-(BOOL) shouldAutorotate {
    
    // Return YES for supported orientations
    return NO;
    
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.       
    return [dataShow count];    
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView
                             dequeueReusableCellWithIdentifier:@"RestaurantViewCell"];
    if (dataShow.count >0) {	
    mm_LocationObject *object = [dataShow objectAtIndex:indexPath.row];    
    NSString*url=[NSString stringWithFormat:@"%@",object.logo];
    NSString *urlimage=[urlmagrabbit stringByAppendingString:url];        
    UIImage *image;        
        if (![url isEqual:@"<null>"]) {
            image= [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:urlimage]]];
        }
        else
        {
            image = [UIImage imageNamed: @"icon.png"];
        }
    imageLogo=(UIImageView *)[cell viewWithTag:100];
    lbName=(UILabel *)[cell viewWithTag:101];
    lbAdd =(UILabel *)[cell viewWithTag:102];
    lbName.text= object.name;
    lbAdd.text =[NSString stringWithFormat:@"%.3fmi",[object.distance floatValue]];
    [imageLogo setImage:image];
    }
    return cell;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    /*
    [self performSegueWithIdentifier:@"gotorestaurantfromhome" sender:tableView];
     */
    
}
-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender
{
    mm_RestaurantViewController *viewController = [segue destinationViewController];
    mm_LocationObject *custObject = [dataShow objectAtIndex:[self.locationTable indexPathForSelectedRow].row];
    viewController.locationObject = custObject;
}

- (void)searchBarTextDidBeginEditing:(UISearchBar *)searchBar
{
    [self.locationSearchBar resignFirstResponder];
    [self addViewSearch];
    
}
-(BOOL) textFieldShouldReturn:(UITextField *)textField{
    
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - Table view delegate

- (IBAction)cancelButtonPressed:(id)sender {
    [UIView animateWithDuration:1 animations:^{
        myView.frame =  CGRectMake(0, 480, self.view.frame.size.width,self.view.frame.size.height);
    }];
    if (IS_IPHONE_5) {
        [myView removeFromSuperview];
    }
}
-(void)DoSearch{
    [self showIndicator];
    mm_SeachNomalTask *searchTask=[[mm_SeachNomalTask alloc]init];
    searchTask.delegate=self;
    [searchTask search:self.accessToken latitude:[NSString stringWithFormat:@"%@",self.latitudeCheck] longitude:[NSString stringWithFormat:@"%@",self.longitudeCheck] name:dataSearch];
    //[searchTask search:self.accessToken latitude:@"16.071898" longitude:@"108.225178" name:dataSearch];
    [UIView animateWithDuration:1 animations:^{
        myView.frame =  CGRectMake(0, 480, self.view.frame.size.width,self.view.frame.size.height);
    }];

}
- (IBAction)submitButtonPressed:(id)sender {
    if (txtKeySearch.text.length>0)
    {
        dataSearch=txtKeySearch.text;
    }
    else
    {
        dataSearch=@"";
    }
    locationSearchBar.text=txtKeySearch.text;
    [self DoSearch];
    if (IS_IPHONE_5) {
        [myView removeFromSuperview];
    }
    
   }
- (IBAction)checkButtonPressed:(id)sender {
    if(btnCheck.isSelected)
    {
        [btnCheck setSelected:NO];
    }
    else
    {
        [btnCheck setSelected:YES];
    }
}
-(void)showIndicator
{
    viewIndicator=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
    [viewIndicator setBackgroundColor: [UIColor clearColor]];
    UIActivityIndicatorView *activityView=[[UIActivityIndicatorView alloc]     initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
    
    activityView.center=self.view.center;
    activityView.color = [UIColor grayColor];
    [activityView startAnimating];
    [viewIndicator addSubview:activityView];
    [self.view addSubview:viewIndicator];     
}
//Google voice search begin
- (IBAction)GoogleVoicePressed:(id)sender{
        //[stt beginRecording];
}
- (BOOL)didReceiveVoiceResponse:(NSData *)data{
     NSString *cotentfromserver= [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"google voicoi resule = %@",cotentfromserver);
    //  NSString *cotentfromserver=@"{\"status\":0,\"id\":\"7234983274239749832\",\"hypotheses\":[{\"utterance\":\"hello\",\"confidence\":0.5}]}";
      NSDictionary *jsonDict = [cotentfromserver JSONValue];
      NSString *status=[jsonDict objectForKey:@"status"];
    if([status intValue]==0){
        NSArray *resultArray=[jsonDict objectForKey:@"hypotheses"];
        if(resultArray.count>0){
            NSDictionary *object = [[NSDictionary alloc] initWithDictionary:[resultArray objectAtIndex:0]];
                NSString *text= [object objectForKey:@"utterance"];
                locationSearchBar.text=text;
            dataSearch=text;
            [self DoSearch];
        }
    }else{
        //[stt beginRecording];

    }
    return YES;
}
//Google voice search end
-(void) addViewSearch
{
    myView=[[UIView alloc]initWithFrame:CGRectMake(0, 480, self.view.frame.size.width, self.view.frame.size.height)];
    UIColor *myColor = [UIColor colorWithRed:(0.0 / 255.0) green:(0.0 / 255.0) blue:(0.0 / 255.0) alpha: 0.9];
    [myView setBackgroundColor: myColor];
    
    [UIView animateWithDuration:0.5 animations:^{
        myView.frame =  CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height);
    }];
    
    btnSubmit = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btnSubmit addTarget:self action:@selector(submitButtonPressed:)
        forControlEvents:UIControlEventTouchDown];
    [btnSubmit setTitle:@"Submit" forState:UIControlStateNormal];
    [btnSubmit setFrame:CGRectMake(20, self.view.frame.size.height-50, 100, 30)];
    [myView addSubview:btnSubmit];
    btnCancel = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btnCancel addTarget:self action:@selector(cancelButtonPressed:)
        forControlEvents:UIControlEventTouchDown];
    [btnCancel setTitle:@"Cancel" forState:UIControlStateNormal];
    [btnCancel setFrame:CGRectMake(200, self.view.frame.size.height-50, 100, 30)];
    [myView addSubview:btnCancel];
    UIImageView *viewSearch=[[UIImageView alloc ]initWithFrame:CGRectMake(100, 40, 40, 40)];
    UIImage *image = [UIImage imageNamed: @"search_icon.png"];
    [viewSearch setImage:image];
    [myView addSubview:viewSearch];
    UILabel *lbSearch=[[UILabel alloc]initWithFrame:CGRectMake(140, 40, 120, 40)];
    lbSearch.text=@"Search";
    [lbSearch setBackgroundColor:[UIColor clearColor]];
    [lbSearch setTextColor:[UIColor whiteColor]];
    [myView addSubview:lbSearch];
    UILabel *lbrundefault=[[UILabel alloc]initWithFrame:CGRectMake(20, 100, 280, 40)];
    lbrundefault.text=@"Run Default Search Pro�E�le";
    [lbrundefault setBackgroundColor:[UIColor clearColor]];
    [lbrundefault setTextColor:[UIColor whiteColor]];
    [myView addSubview:lbrundefault];
    imageCheck = [UIImage imageNamed: @"check.gif"];    
    imageNotCheck=[UIImage imageNamed:@"check_01.png"];
    btnCheck = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnCheck addTarget:self action:@selector(checkButtonPressed:)
       forControlEvents:UIControlEventTouchDown];
    [btnCheck setBackgroundImage:imageCheck forState:UIControlStateNormal];
    [btnCheck setFrame:CGRectMake(280, 110, 20, 20)];
    
    [myView addSubview:btnCheck];
    UILabel *lbOr=[[UILabel alloc]initWithFrame:CGRectMake(20, 120, 280, 40)];
    lbOr.text=@"or";
    [lbOr setBackgroundColor:[UIColor clearColor]];
    [lbOr setTextColor:[UIColor whiteColor]];
    lbOr.textAlignment=NSTextAlignmentCenter;
    [myView addSubview:lbOr];
    txtKeySearch=[[UITextField alloc]initWithFrame:CGRectMake(20, 160, 280, 60)];
    txtKeySearch.textColor=[UIColor blackColor];
    txtKeySearch.layer.cornerRadius=8.0f;
    txtKeySearch.layer.masksToBounds=YES;
    txtKeySearch.layer.borderColor=[[UIColor grayColor]CGColor];
    [txtKeySearch setBackgroundColor:[UIColor grayColor]];
    txtKeySearch.layer.borderWidth= 1.0f;
    txtKeySearch.placeholder=@"Keyword Search";
    txtKeySearch.returnKeyType=UIReturnKeyDefault;
    txtKeySearch.delegate=self;
    [myView addSubview:txtKeySearch];
    [btnCheck setBackgroundImage:imageNotCheck forState:UIControlStateNormal];
    [btnCheck setBackgroundImage:imageCheck forState:UIControlStateSelected];
    [btnCheck setSelected:YES];
    [self.view addSubview:myView];
}
@end
