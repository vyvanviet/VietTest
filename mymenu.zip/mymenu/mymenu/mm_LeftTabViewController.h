#import <UIKit/UIKit.h>

@interface mm_LeftTabViewController :UIViewController <UITableViewDelegate, UITableViewDataSource>
{
    UITableView *menuTable;
    UIImageView *userImage;
    UIImageView *imageBackground;
    UIImageView *dividerImage;
    UIButton *createAccountButton;
    UILabel *pointsLabel;
    UILabel *reviewsLabel;
    UILabel *myPointsLabel;
    UILabel *myReviewsLabel;
    UIActivityIndicatorView *indicator;
    NSArray *menuItems;
}
@property (nonatomic, strong) NSArray *menuItems;
@property (nonatomic, retain) UITableView *menuTable;
- (IBAction)myMenuClick:(id)sender;
@end
