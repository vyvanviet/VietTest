//
//  mm_LeftTabViewController.m
//  mymenu
//
//  Created by Le Cao Hoai Yen on 10/30/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_LeftTabViewController.h"
#import "LeftTabCell.h"

@interface mm_LeftTabViewController ()

@end

@implementation mm_LeftTabViewController
@synthesize menuItems;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor darkGrayColor];
    CGFloat width = self.view.frame.size.width;
    //CGFloat height = self.view.frame.size.height - 130;
    CGFloat height = self.view.frame.size.height - 45;
    //CGRect tableFrame = CGRectMake(0, 130, width, height);
    CGRect tableFrame = CGRectMake(0, 45, width, height);
    menuTable = [[UITableView alloc]initWithFrame:tableFrame style:UITableViewStylePlain];
    menuTable.delegate = self;
    menuTable.dataSource = self;
    menuTable.backgroundColor = [UIColor clearColor];
    [self.view addSubview:menuTable];
    //self.menuItems = [NSArray arrayWithObjects: @"Favorites", @"Account Settings", @"My Tags", @"My Points", @"Notifications", @"My Ratings", @"My Server", @"Feedback", nil];
    self.menuItems = [NSArray arrayWithObjects: @"MyPoints", @"MyNotifications", @"MySettings", @"MySearch", @"MyFriends", @"MyWallet", @"MyFavorites", @"MyCalories", nil];
	// Do any additional setup after loading the view.
}
-(IBAction)setLocationObject:(id)sender
{
    
}
- (IBAction)myMenuClick:(id)sender {
    //[self dismissViewControllerAnimated:YES completion:nil];
    //self.slidingViewController.underLeftViewController  = [LeftTabViewController new];
    //[self.slidingViewController anchorTopViewTo:ECRight];
    [self performSegueWithIdentifier:@"gotohomefromleft" sender:self];
    
}
#pragma mark TableView Delegates
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    LeftTabCell *cell = (LeftTabCell *)[tableView dequeueReusableCellWithIdentifier:[LeftTabCell reuseIdentifier]];
    
    if (!cell) {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([LeftTabCell class]) owner:self options:nil];
        cell = nib[0];
        NSLog(@"cell width %f", cell.frame.size.width);
    }
    cell.menuItems = self.menuItems;
    cell.indexPathRow = indexPath.row;
    return cell;
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60.;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.menuItems.count;
    //return 20.0f;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    /*UINavigationController *navController = nil;
     BOOL isGuest = [UserObject isGuest];
     
     switch (indexPath.row) {
     case 0:{
     UINavigationController *currentNavController = (UINavigationController *)self.slidingViewController.topViewController;
     for (UIViewController *controller in currentNavController.viewControllers) {
     if ([controller isKindOfClass:[HomeViewController class]]) {
     [self.slidingViewController resetTopView];
     return;
     }
     }
     navController =  [[UINavigationController alloc] initWithRootViewController:[HomeViewController new]];
     break;
     }
     case 0:
     navController =  [[UINavigationController alloc] initWithRootViewController:[FavoritesViewController new]];
     break;
     case 1:
     navController = [[UINavigationController alloc] initWithRootViewController:[AccountViewController new]];
     break;
     case 2:
     if (isGuest) {
     [self showGuestAlert];
     return;
     }
     navController =  [[UINavigationController alloc] initWithRootViewController:[HistoryViewController new]];
     break;
     case 3:
     if (isGuest) {
     [self showGuestAlert];
     return;
     }
     navController =  [[UINavigationController alloc] initWithRootViewController:[MyPointsViewController new]];
     break;
     case 4:
     if (isGuest) {
     [self showGuestAlert];
     return;
     }
     navController =  [[UINavigationController alloc] initWithRootViewController:[NotificationsViewController new]];
     break;
     case 5:
     if (isGuest) {
     [self showGuestAlert];
     return;
     }
     navController = [[UINavigationController alloc] initWithRootViewController:[MyRatingsViewController new]];
     break;
     case 6:
     if (isGuest) {
     [self showGuestAlert];
     return;
     }
     [[[UIAlertView alloc] initWithTitle:@"Coming Soon..." message:@"Feature will be added soon!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles: nil] show];
     return;
     break;
     case 7:
     if (isGuest) {
     [self showGuestAlert];
     return;
     }
     navController =  [[UINavigationController alloc] initWithRootViewController:[FeedbackViewController new]];
     break;
     default:
     return;
     break;
     }
     */
    //[self setSlidingControllerViewWithNavigationController:navController];
    switch (indexPath.row) {
        case 2:
            [self performSegueWithIdentifier:@"gotosettingfromleft" sender:nil];
            break;
            
        default:
            return;
            break;
    }
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
