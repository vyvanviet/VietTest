//
//  mm_LoadLocationFeedbackTask.h
//  mymenu
//
//  Created by Dang Duc Nam on 11/5/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "mm_sycndata.h"

@protocol loadLocationFeedbackProtocal

- (void) loadLocationFeedback_success:(NSDictionary *) dict;
- (void) loadLocationFeedback_unsuccess:(NSString *)error;

@end

@interface mm_LoadLocationFeedbackTask : mm_sycndata

@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <loadLocationFeedbackProtocal> delegate;

-(void)loadLocationFeedback:(int*)locationId;

@end
