//
//  mm_LoadLocationFeedbackTask.m
//  mymenu
//
//  Created by Dang Duc Nam on 11/5/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_LoadLocationFeedbackTask.h"
#import "string.h"

@implementation mm_LoadLocationFeedbackTask

@synthesize postdata;
@synthesize delegate;

-(void)loadLocationFeedback:(int*)locationId{
    
    NSString *url = [NSString stringWithFormat:@"%@%d%@",loadLocationFeedbackStart,locationId,loadLocationFeedbackEnd];
       
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *token = [defaults stringForKey:kTokenkey];
    
    postdata =[NSString stringWithFormat:@"access_token=%@",token];
    NSLog(@"postdata: %@", postdata);
    
    NSLog(@"url %@", url);
    [self request:url];
}

-(void)request:(NSString *)url;
{
    NSData *postData = [postdata dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
	
	//Declare NSString postLength and get length postData
	NSString *postLength = [NSString stringWithFormat:@"%d",[postData length]];
	NSLog(@"lengh postdata = %@",postLength);
	//Declare NSMutableURLRequest request_url
    NSString *searchURL =url;
    searchURL = [searchURL stringByAppendingString:postdata];
    NSLog(@"searchURL %@",searchURL);
    NSMutableURLRequest *request_url = [[NSMutableURLRequest alloc] init] ;
    [request_url setURL:[NSURL URLWithString:searchURL]];
	//init NSURLConnection connectionURL
	connectionURL = [[NSURLConnection alloc] initWithRequest:request_url delegate:self];
    NSLog(@"connectionURL= %@",connectionURL);
	if (connectionURL) {
        datacontent = [NSMutableData data] ;
        NSLog(@"datacontent= %@",datacontent);
	}
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [datacontent setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
    [datacontent appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    datacontent = nil;
    NSLog(@"loi service roi");
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *cotentfromserver= [[NSString alloc]initWithData:datacontent encoding:NSUTF8StringEncoding];
    NSLog(@"cotentfromserver = %@",cotentfromserver);
    
    NSData *jsonData = [cotentfromserver dataUsingEncoding:NSUTF8StringEncoding];
    NSError *e;
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:jsonData options:nil error:&e];
    
    NSString *error = [dict objectForKey:@"error"];
    NSLog(@"error: %@", error);
    if(error == NULL){
        [self.delegate loadLocationFeedback_success:dict];
    }else{
        [self.delegate loadLocationFeedback_unsuccess:(NSString *)error];
    }
}

- (NSString *)createJSONFromDictionary:(NSDictionary *)dictionary {
    NSError* error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:kNilOptions error:&error];
    if (!error) {
        NSString* jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return jsonString;
    } else {
        return nil;
    }
}

- (NSString *)toCreateJSON{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *token = [defaults stringForKey:kTokenkey];
        
    NSMutableDictionary *mutableDictionary = [NSMutableDictionary new];
    [mutableDictionary setObject:token forKey:kJsonToken];
        
    NSDictionary *userInfo = [NSDictionary dictionaryWithDictionary:mutableDictionary];
    return [self createJSONFromDictionary:userInfo];
}
@end
