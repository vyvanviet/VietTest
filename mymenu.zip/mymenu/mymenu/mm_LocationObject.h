//
//  mm_LocationObject.h
//  mymenu
//
//  Created by Le Cao Hoai Yen on 11/1/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface mm_LocationObject : NSObject
{
    NSString *idsv;
    NSString *name;
    NSString *address;
    NSString *city;
    NSString *state;
    NSString *country;
    NSString *created_at;    
    NSString *latitude;    
    NSString *longitude;
    NSString *phone;
    NSString *owner_id;
    NSString *url;
    NSString *rating;
    NSString *redeemption_password;
    NSString *slug;
    NSString *subscription_type;
    NSString *updated_at;    
    NSString *zip;
    NSString *tax;
    NSString *hour_of_operation;
    NSString *bio;
    NSString *distance;
    NSString *logo;
    NSArray *isFavourite;
    NSArray *images;
}
@property(nonatomic,copy)NSString *idsv;
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *address;
@property(nonatomic,copy)NSString *city;
@property(nonatomic,copy)NSString *state;
@property(nonatomic,copy)NSString *country;
@property(nonatomic,copy)NSString *created_at;
@property(nonatomic,copy)NSString *latitude;
@property(nonatomic,copy)NSString *longitude;
@property(nonatomic,copy)NSString *phone;
@property(nonatomic,copy)NSString *owner_id;
@property(nonatomic,copy)NSString *url;
@property(nonatomic,copy)NSString *rating;
@property(nonatomic,copy)NSString *redeemption_password;
@property(nonatomic,copy)NSString *slug;
@property(nonatomic,copy)NSString *subscription_type;
@property(nonatomic,copy)NSString *updated_at;
@property(nonatomic,copy)NSString *zip;
@property(nonatomic,copy)NSString *tax;
@property(nonatomic,copy)NSString *hour_of_operation;
@property(nonatomic,copy)NSString *bio;
@property(nonatomic,copy)NSString *distance;
@property(nonatomic,copy)NSString *logo;
@property(nonatomic,copy)NSArray *isFavourite;
@property(nonatomic,copy)NSArray *images;
@property (nonatomic, strong) UIImage *restaurantIcon;
@property (nonatomic, strong) NSString *restaurantIconURLString;


@end
