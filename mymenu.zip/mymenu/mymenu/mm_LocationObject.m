//
//  mm_LocationObject.m
//  mymenu
//
//  Created by Le Cao Hoai Yen on 11/1/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_LocationObject.h"

@implementation mm_LocationObject
@synthesize latitude,longitude,city,country,created_at,phone,state,slug,subscription_type,zip,updated_at,url,address,idsv,rating,owner_id,redeemption_password,name,logo,distance,images,bio,hour_of_operation,tax,isFavourite,restaurantIcon,restaurantIconURLString;
@end
