//
//  mm_LocationRatingController.h
//  mymenu
//
//  Created by Dang Duc Nam on 11/4/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mm_LocationRatingTask.h"
#import "mm_LoadLocationFeedbackTask.h"
#import "mm_LocationObject.h"

@interface mm_LocationRatingController : UIViewController<locationRatingProtocol,loadLocationFeedbackProtocal, UITableViewDelegate, UITableViewDataSource>
{
    IBOutlet UISlider *rateSlider;
    IBOutlet UITextView *comment;
    IBOutlet UIButton *btnSubmit;
    IBOutlet UIButton *btnCancel;
    IBOutlet UIScrollView *scrView;
    IBOutlet UIButton *rateImage;
    IBOutlet UITableView *cmttableView;
    IBOutlet UILabel *ratingHeader;
    IBOutlet UIActivityIndicatorView *indicator;
    IBOutlet UILabel *reviews;
    
    mm_LocationRatingTask *taskRate;
    mm_LoadLocationFeedbackTask *taskLoad;
    mm_LocationObject *locationObject;
    
}

@property (strong, nonatomic) IBOutlet UISlider *rateSlider;
@property (strong, nonatomic) IBOutlet UITextView *comment;
@property (strong, nonatomic) IBOutlet UIButton *btnSubmit;
@property (strong, nonatomic) IBOutlet UIButton *btnCancel;
@property (strong, nonatomic) IBOutlet UIScrollView *scrView;
@property (strong, nonatomic) IBOutlet UIButton *rateImage;
@property (strong, nonatomic) UITableView *cmttableView;
@property (nonatomic, strong) NSArray *entries;
@property (strong, nonatomic) IBOutlet UIActivityIndicatorView *indicator;

@property (strong, nonatomic) IBOutlet UILabel *reviews;
@property (strong, nonatomic) IBOutlet UILabel *ratingHeader;
@property(nonatomic,strong)mm_LocationObject *locationObject;

-(IBAction)btn_submit_click:(id)sender;
-(IBAction)btn_return_click:(id)sender;
-(IBAction)btn_cancel_click:(id)sender;
-(IBAction)rateSliderValueChanged:(id)sender;

@end
