//
//  mm_LocationRatingController.m
//  mymenu
//
//  Created by Dang Duc Nam on 11/4/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_LocationRatingController.h"
#import <QuartzCore/QuartzCore.h>
#import "FeedbackObject.h"
#import "string.h"
#import "mm_FeedbackLocationCell.h"
#import "mm_FeedbackLocationCell2.h"
#import "IconDownloader.h"
#import "AppRecord.h"
#import "mm_RestaurantViewController.h"

int clickIndex = 0;
float cellHeight = 75;
int rating;
UIImage *imgA1;
UIImage *imgA2;
UIImage *imgA3;
UIImage *imgB1;
UIImage *imgB2;
UIImage *imgB3;
UIImage *imgC1;
UIImage *imgC2;
UIImage *imgC3;
UIImage *imgD1;
UIImage *imgD2;
UIImage *imgD3;
UIImage *imgE1;
UIImage *imgE2;
UIImage *imgE3;
UIImage *imgF1;
UIImage *imgF2;
NSArray *comments;

@interface mm_LocationRatingController ()<UIScrollViewDelegate>
{
    UITextView *activeField;
    CGPoint originalOffset;
}
@property (nonatomic, strong) NSMutableDictionary *imageDownloadsInProgress;

@end
@implementation mm_LocationRatingController

@synthesize rateSlider,comment,btnCancel,btnSubmit,scrView,rateImage,cmttableView,locationObject,ratingHeader,indicator,entries,reviews;

- (void) loadLocationFeedback_success:(NSDictionary *)dict{
    int comments_count = [[dict objectForKey:@"comments_count"] integerValue];
    int ratings_count = [[dict objectForKey:@"ratings_count"] integerValue];
    int rating_sum = [[dict objectForKey:@"rating"] integerValue];
    if(ratings_count <= 1)
        reviews.text = [NSString stringWithFormat:@"%d Review",ratings_count];
    else
        reviews.text = [NSString stringWithFormat:@"%d Reviews",ratings_count];
    switch (rating_sum) {
        case 1:
            ratingHeader.text = @"F";
            break;
        case 2:
            ratingHeader.text = @"F+";
            break;
        case 3:
            ratingHeader.text = @"E-";
            break;
        case 4:
            ratingHeader.text = @"E";
            break;
        case 5:
            ratingHeader.text = @"E+";
            break;
        case 6:
            ratingHeader.text = @"D-";
            break;
        case 7:
            ratingHeader.text = @"D";
            break;
        case 8:
            ratingHeader.text = @"D+";
            break;
        case 9:
            ratingHeader.text = @"C-";
            break;
        case 10:
            ratingHeader.text = @"C";
            break;
        case 11:
            ratingHeader.text = @"C+";
            break;
        case 12:
            ratingHeader.text = @"B-";
            break;
        case 13:
            ratingHeader.text = @"B";
            break;
        case 14:
            ratingHeader.text = @"B+";
            break;
        case 15:
            ratingHeader.text = @"A-";
            break;
        case 16:
            ratingHeader.text = @"A";
            break;
        case 17:
            ratingHeader.text = @"A+";
            break;
        
    }
        
    NSMutableArray *workingArray = [NSMutableArray array];
    comments = [dict objectForKey:@"comments"];
    for (int i = 0 ; i < comments.count; i++) {
        AppRecord *entry = [[AppRecord alloc]init];
        NSDictionary *item=[[NSDictionary alloc]initWithDictionary:[comments objectAtIndex:i]];
        NSString *text = [item objectForKey:@"text"];
        NSString *user_avatar = [item objectForKey:@"user_avatar"];
        NSString *avatarUrl = [NSString stringWithFormat:@"%@%@", domainmagrabbit ,user_avatar];
        NSLog(@"avatarUrl: %@",avatarUrl);
        entry.appName = text;
        entry.imageURLString = avatarUrl;
        entry.artist = @"nguyennls";
        entry.appURLString = avatarUrl;
        [workingArray addObject:entry];
    }
    
    entries = [NSArray arrayWithArray:workingArray];
    NSLog(@"entries count: %d", entries.count);
    [cmttableView reloadData];
    [indicator stopAnimating];
}
- (void) loadLocationFeedback_unsuccess:(NSString *)error{
    [indicator stopAnimating];
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Notice message"
                                                      message:error
                                                     delegate:self
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    [message show];
}

- (void) locationRating_success{
     comment.text = @"";
    rating = 17;
    rateSlider.value = 100;
    rateImage.frame = CGRectMake(279, 50, 31, 18);
    [rateImage setImage:imgA1 forState:UIControlStateNormal];
    [self resignAllTextFields];
    [indicator stopAnimating];
    [self bindListFeedback];
    
}

- (void) locationRating_unsuccess:(NSDictionary *)dict{
    [indicator stopAnimating];
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Notice message"
                                                      message:@"Rating location failed. "
                                                     delegate:self
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    [message show];
}

- (void) bindListFeedback{
    [indicator startAnimating];
    taskLoad = [[mm_LoadLocationFeedbackTask alloc]init];
    taskLoad.delegate = self;
    [taskLoad loadLocationFeedback:(int)[self.locationObject.idsv intValue]];
}

-(IBAction)btn_submit_click:(id)sender{
    NSString *comment = [self.comment text];
        
    if (comment.length == 0) {
        UIAlertView *message = [[UIAlertView alloc] initWithTitle:@"Notice message"
                                                          message:@"Please enter your comment. "
                                                         delegate:self
                                                cancelButtonTitle:@"OK"
                                                otherButtonTitles:nil];
        [message show];

        [self.comment becomeFirstResponder];
        return;
    }
    int idLocation = (int)[self.locationObject.idsv intValue];
    [indicator startAnimating];
    taskRate = [[mm_LocationRatingTask alloc]init];
    taskRate.delegate = self;
    [taskRate locationRating:rating comment:comment idLocation:idLocation];
    
}
-(IBAction)btn_cancel_click:(id)sender{
    clickIndex = 1;
    [self performSegueWithIdentifier:@"ratingBackRestaurant" sender:nil];
}
- (void)resignAllTextFields {
    [self.comment resignFirstResponder];
    
}

-(UIImage *) getImageRating:(int)ratingPoint{
    UIImage *result = imgA1;
    switch(ratingPoint){
        case 1:
            result = imgF2;
            break;
        case 2:
            result = imgF1;
            break;
        case 3:
            result = imgE3;
            break;
        case 4:
            result = imgE2;
            break;
        case 5:
            result = imgE1;
            break;
        case 6:
            result = imgD3;
            break;
        case 7:
            result = imgD2;
            break;
        case 8:
            result = imgD1;
            break;
        case 9:
            result = imgC3;
            break;
        case 10:
            result = imgC2;
            break;
        case 11:
            result = imgC1;
            break;
        case 12:
            result = imgB3;
            break;
        case 13:
            result = imgB2;
            break;
        case 14:
            result = imgB1;
            break;
        case 15:
            result = imgA3;
            break;
        case 16:
            result = imgA2;
            break;
        case 17:
            result = imgA1;
            break;
    }
    return result;
}
-(IBAction)rateSliderValueChanged:(UISlider *)sender{
    float value = [sender value];
    float duration = 100/16;

    int rateSliderWidth = self.rateSlider.frame.size.width;
    int rateSliderX = self.rateSlider.frame.origin.x;
    int rateImageWidth = self.rateImage.frame.size.width;
    int rateImageHeight = self.rateImage.frame.size.height;
    int rateImageX = self.rateImage.frame.origin.x;
    int rateImageY = self.rateImage.frame.origin.y;
    
    int reX;
    UIImage *reImage;
    
    int durWidth = rateSliderWidth/16;
        
    if(value < duration){
        reX = rateSliderX;
        reImage = imgF2;
        rating = 1;
    }
    else if(value < duration*2){
        reX = rateSliderX + durWidth;
        reImage = imgF1;
        rating = 2;
    }
    else if(value < duration*3){
        reX = rateSliderX + durWidth*2;
        reImage = imgE3;
        rating = 3;
    }
    else if(value < duration*4){
        reX = rateSliderX + durWidth*3;
        reImage = imgE2;
        rating = 4;
    }
    else if(value < duration*5){
        reX = rateSliderX + durWidth*4;
        reImage = imgE1;
        rating = 5;
    }
    else if(value < duration*6){
        reX = rateSliderX + durWidth*5;
        reImage = imgD3;
        rating = 6;
    }
    else if(value < duration*7){
        reX = rateSliderX + durWidth*6;
        reImage = imgD2;
        rating = 7;
    }
    else if(value < duration*8){
        reX = rateSliderX + durWidth*7;
        reImage = imgD1;
        rating = 8;
    }
    else if(value < duration*9){
        reX = rateSliderX + durWidth*8;
        reImage = imgC3;
        rating = 9;
    }
    else if(value < duration*10){
        reX = rateSliderX + durWidth*9;
        reImage = imgC2;
        rating = 10;
    }
    else if(value < duration*11){
        reX = rateSliderX + durWidth*10;
        reImage = imgC1;
        rating = 11;
    }
    else if(value < duration*12){
        reX = rateSliderX + durWidth*11;
        reImage = imgB3;
        rating = 12;
    }
    else if(value < duration*13){
        reX = rateSliderX + durWidth*12;
        reImage = imgB2;
        rating = 13;
    }
    else if(value < duration*14){
        reX = rateSliderX + durWidth*13;
        reImage = imgB1;
        rating = 14;
    }
    else if(value < duration*15){
        reX = rateSliderX + durWidth*14;
        reImage = imgA3;
        rating = 15;
    }
    else if(value < duration*16){
        reX = rateSliderX + durWidth*15;
        reImage = imgA2;
        rating = 16;
    }
    else{
        reX = rateImageX;
        reImage = imgA1;
        rating = 17;
    }
    rateImage.frame = CGRectMake(reX, rateImageY, rateImageWidth, rateImageHeight);
    [rateImage setImage:reImage forState:UIControlStateNormal];
    [rateImage setNeedsDisplay];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad{
    [super viewDidLoad];
    self.imageDownloadsInProgress = [NSMutableDictionary dictionary];
    cmttableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 225, 320, self.view.frame.size.height - 225)];
    [cmttableView setSeparatorStyle:UITableViewCellSeparatorStyleNone];
    [cmttableView setSeparatorColor:[UIColor clearColor]];
    cmttableView.backgroundColor = [UIColor clearColor];
    cmttableView.dataSource = self;
    cmttableView.delegate = self;
    cmttableView.separatorStyle = 10;
    [self.scrView addSubview:cmttableView];
    
          
    //rating
    rating = 17;
    imgA1 = [UIImage imageNamed: @"a+.png"];
    imgA2 = [UIImage imageNamed: @"a.png"];
    imgA3 = [UIImage imageNamed: @"a-.png"];
    imgB1 = [UIImage imageNamed: @"b+.png"];
    imgB2 = [UIImage imageNamed: @"b.png"];
    imgB3 = [UIImage imageNamed: @"b-.png"];
    imgC1 = [UIImage imageNamed: @"c+.png"];
    imgC2 = [UIImage imageNamed: @"c.png"];
    imgC3 = [UIImage imageNamed: @"c-.png"];
    imgD1 = [UIImage imageNamed: @"d+.png"];
    imgD2 = [UIImage imageNamed: @"d.png"];
    imgD3 = [UIImage imageNamed: @"d-.png"];
    imgE1 = [UIImage imageNamed: @"e+.png"];
    imgE2 = [UIImage imageNamed: @"e.png"];
    imgE3 = [UIImage imageNamed: @"e-.png"];
    imgF1 = [UIImage imageNamed: @"f+.png"];
    imgF2 = [UIImage imageNamed: @"f.png"];
    
    //slider
    UIImage *sliderThumb = [UIImage imageNamed:@"thanhkeo-2.png"];
    [rateSlider setThumbImage:sliderThumb forState:UIControlStateNormal];
    UIImage *sliderMinimum = [[UIImage imageNamed:@"thanhngang.png"] stretchableImageWithLeftCapWidth:4 topCapHeight:0];
    [rateSlider setMinimumTrackImage:sliderMinimum forState:UIControlStateNormal];
    UIImage *sliderMaximum = [[UIImage imageNamed:@"thanhngang.png"] stretchableImageWithLeftCapWidth:4 topCapHeight:0];
    [rateSlider setMaximumTrackImage:sliderMaximum forState:UIControlStateNormal];
    
    comment.layer.cornerRadius = 5;
     
    //
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(singleTapGestureCaptured:)];
    [self.scrView addGestureRecognizer:singleTap];
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(keyboardWillShow:)
                                                 name: UIKeyboardWillShowNotification
                                               object: nil];
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(keyboardWillHide:)
                                                 name: UIKeyboardWillHideNotification
                                               object: nil];
    [self bindListFeedback];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    NSArray *allDownloads = [self.imageDownloadsInProgress allValues];
    [allDownloads makeObjectsPerformSelector:@selector(cancelDownload)];
    
    [self.imageDownloadsInProgress removeAllObjects];
}

-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender
{
    if(clickIndex == 1)
    {
        mm_RestaurantViewController *viewController = [segue destinationViewController];
        viewController.locationObject = locationObject;
    }
}

#pragma mark - Notifications
- (void)keyboardWillShow: (NSNotification *) notification {
    NSDictionary* info = [notification userInfo];
    CGRect kbRect = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
	kbRect = [self.view convertRect:kbRect toView:nil];
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbRect.size.height, 0.0);
    self.scrView.contentInset = contentInsets;
    self.scrView.scrollIndicatorInsets = contentInsets;
    
    CGRect aRect = self.view.frame;
    CGFloat width = aRect.size.width;
    CGFloat height = aRect.size.height;
    CGRect frame = CGRectMake(aRect.origin.x, aRect.origin.y, height, width);
    aRect = frame;
    aRect.size.height -= kbRect.size.height;
    CGPoint fieldOrigin = [self.view convertPoint:activeField.frame.origin fromView:[activeField superview]];
    originalOffset = self.scrView.contentOffset;
    if (!CGRectContainsPoint(aRect, fieldOrigin) ) {
        CGRect fieldFrame = [self.scrView convertRect:activeField.frame fromView:[activeField superview]];
        [self.scrView scrollRectToVisible:fieldFrame animated:YES];
    }
}
- (void)keyboardWillHide: (NSNotification *) notification {
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    self.scrView.contentInset = contentInsets;
    self.scrView.scrollIndicatorInsets = contentInsets;
    [self.scrView setContentOffset:originalOffset animated:YES];
}

- (void)singleTapGestureCaptured:(UITapGestureRecognizer *)gesture {
    [self resignAllTextFields];
}


#pragma mark TableView Delegates
- (UITableViewCell *)tableView:(UITableView *)tableView
         cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"vo dau truoc ha - bbbbbbbbbbbbbbb");
    NSUInteger nodeCount = [self.entries count];
    
    static NSString *CellIdentifier = @"LazyTableCell";
    static NSString *PlaceholderCellIdentifier = @"PlaceholderCell";
    
    if (nodeCount == 0 && indexPath.row == 0)
	{
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:PlaceholderCellIdentifier];
        
		cell.detailTextLabel.text = @"Loading…";
		
		return cell;
    }
    
    NSDictionary *item=[[NSDictionary alloc]initWithDictionary:[comments objectAtIndex:indexPath.row]];
    int rating = [[item objectForKey:@"rating"] integerValue];
    NSString *contentFB = [item objectForKey:@"text"];
    NSString *dateFB = [item objectForKey:@"date"];
        
    if(indexPath.row % 2 == 0){
        mm_FeedbackLocationCell *cell = (mm_FeedbackLocationCell *)[tableView dequeueReusableCellWithIdentifier:[mm_FeedbackLocationCell reuseIdentifier]];
    
        if (!cell) {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([mm_FeedbackLocationCell class]) owner:self options:nil];
            cell = nib[0];
        }
        cell.rateImage.image = [self getImageRating:rating];
        cell.content.text = contentFB;
        cell.content.editable = NO;
        cell.dateFeedback.text = dateFB;
        
        UIImage *lblBGImg;
        float currentVersion = 6.0;
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= currentVersion)
        {
            //device have iOS 6 or above
            lblBGImg = [[UIImage imageNamed:@"khung_2.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(15, 15, 15, 15)  resizingMode:UIImageResizingModeStretch];
        }else{
            //device have iOS 5.1 or belove
            lblBGImg = [[UIImage imageNamed: @"khung_2.png"] stretchableImageWithLeftCapWidth:15.0 topCapHeight:15.0];
        }
        cell.contentBackground.image = lblBGImg;
        
        //Leave cells empty if there's no data yet
        if (nodeCount > 0)
        {
            // Set up the cell...
            AppRecord *appRecord = [self.entries objectAtIndex:indexPath.row];
            
            // Only load cached images; defer new downloads until scrolling ends
            if (!appRecord.appIcon)
            {
                if (self.cmttableView.dragging == NO && self.cmttableView.decelerating == NO)
                {
                    [self startIconDownload:appRecord forIndexPath:indexPath];
                }
                cell.avatar.image = [UIImage imageNamed:@"noavatar.png"];
            }
            else
            {
                cell.avatar.image = appRecord.appIcon;
            }
        }
        return cell;
    } else{
        mm_FeedbackLocationCell2 *cell = (mm_FeedbackLocationCell2 *)[tableView dequeueReusableCellWithIdentifier:[mm_FeedbackLocationCell2 reuseIdentifier]];
        
        if (!cell) {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([mm_FeedbackLocationCell2 class]) owner:self options:nil];
            cell = nib[0];
        }
        cell.rateImage.image = [self getImageRating:rating];
        cell.content.text = contentFB;
        cell.content.editable = NO;
        cell.dateFeedback.text = dateFB;
        
        UIImage *lblBGImg;
        float currentVersion = 6.0;
        if ([[[UIDevice currentDevice] systemVersion] floatValue] >= currentVersion)
        {
            //device have iOS 6 or above
            lblBGImg = [[UIImage imageNamed:@"khung_2.png"] resizableImageWithCapInsets:UIEdgeInsetsMake(15, 15, 15, 15)  resizingMode:UIImageResizingModeStretch];
        }else{
            //device have iOS 5.1 or belove
            lblBGImg = [[UIImage imageNamed: @"khung_2.png"] stretchableImageWithLeftCapWidth:15.0 topCapHeight:15.0];
        }
        cell.contentBackground.image = lblBGImg;
        
        //Leave cells empty if there's no data yet
        if (nodeCount > 0)
        {
            // Set up the cell...
            AppRecord *appRecord = [self.entries objectAtIndex:indexPath.row];
            
            // Only load cached images; defer new downloads until scrolling ends
            if (!appRecord.appIcon)
            {
                if (self.cmttableView.dragging == NO && self.cmttableView.decelerating == NO)
                {
                    [self startIconDownload:appRecord forIndexPath:indexPath];
                }
                cell.avatar.image = [UIImage imageNamed:@"noavatar.png"];
            }
            else
            {
                cell.avatar.image = appRecord.appIcon;
            }
        }
        NSLog(@"content height: %f",cell.content.frame.size.height);
        return cell;
    }    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSDictionary *item=[[NSDictionary alloc]initWithDictionary:[comments objectAtIndex:indexPath.row]];
    NSString *contentFB = [item objectForKey:@"text"];
    mm_FeedbackLocationCell2 *cell = (mm_FeedbackLocationCell2 *)[tableView dequeueReusableCellWithIdentifier:[mm_FeedbackLocationCell2 reuseIdentifier]];
        
    if (!cell) {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:NSStringFromClass([mm_FeedbackLocationCell2 class]) owner:self options:nil];
        cell = nib[0];
    }
    cell.content.text = contentFB;
    return cell.content.contentSize.height + 15;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return entries.count;
}
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
}

#if __IPHONE_OS_VERSION_MIN_REQUIRED < __IPHONE_6_0
// -------------------------------------------------------------------------------
//	shouldAutorotateToInterfaceOrientation:
//  Rotation support for iOS 5.x and earlier, note for iOS 6.0 and later all you
//  need is "UISupportedInterfaceOrientations" defined in your Info.plist.
// -------------------------------------------------------------------------------
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}
#endif

#pragma mark - Table cell image support

// -------------------------------------------------------------------------------
//	startIconDownload:forIndexPath:
// -------------------------------------------------------------------------------
- (void)startIconDownload:(AppRecord *)appRecord forIndexPath:(NSIndexPath *)indexPath
{
    IconDownloader *iconDownloader = [self.imageDownloadsInProgress objectForKey:indexPath];
    if (iconDownloader == nil)
    {
        iconDownloader = [[IconDownloader alloc] init];
        iconDownloader.appRecord = appRecord;
        [iconDownloader setCompletionHandler:^{
            
            UITableViewCell *cell = [self.cmttableView cellForRowAtIndexPath:indexPath];
            
            // Display the newly loaded image
            cell.imageView.image = appRecord.appIcon;
            
            // Remove the IconDownloader from the in progress list.
            // This will result in it being deallocated.
            [self.imageDownloadsInProgress removeObjectForKey:indexPath];
            
        }];
        [self.imageDownloadsInProgress setObject:iconDownloader forKey:indexPath];
        [iconDownloader startDownload];
    }
}

// -------------------------------------------------------------------------------
//	loadImagesForOnscreenRows
//  This method is used in case the user scrolled into a set of cells that don't
//  have their app icons yet.
// -------------------------------------------------------------------------------
- (void)loadImagesForOnscreenRows
{
    if ([self.entries count] > 0)
    {
        NSArray *visiblePaths = [self.cmttableView indexPathsForVisibleRows];
        for (NSIndexPath *indexPath in visiblePaths)
        {
            AppRecord *appRecord = [self.entries objectAtIndex:indexPath.row];
            
            if (!appRecord.appIcon)
                // Avoid the app icon download if the app already has an icon
            {
                [self startIconDownload:appRecord forIndexPath:indexPath];
            }
        }
    }
}

#pragma mark - UIScrollViewDelegate

// -------------------------------------------------------------------------------
//	scrollViewDidEndDragging:willDecelerate:
//  Load images for all onscreen rows when scrolling is finished.
// -------------------------------------------------------------------------------
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    if (!decelerate)
	{
        [self loadImagesForOnscreenRows];
    }
}

// -------------------------------------------------------------------------------
//	scrollViewDidEndDecelerating:
// -------------------------------------------------------------------------------
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    [self loadImagesForOnscreenRows];
}
@end
