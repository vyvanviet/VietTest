//
//  mm_LocationRatingTask.h
//  mymenu
//
//  Created by Dang Duc Nam on 11/4/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mm_sycndata.h"

@protocol locationRatingProtocol

- (void) locationRating_success;
- (void) locationRating_unsuccess:(NSDictionary *) dict;

@end

@interface mm_LocationRatingTask : mm_sycndata

@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <locationRatingProtocol> delegate;

-(void)locationRating:(int *)rating comment:(NSString *)comment idLocation:(int *)idLocation;

@end
