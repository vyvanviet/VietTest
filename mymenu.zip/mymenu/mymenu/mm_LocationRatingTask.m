//
//  mm_LocationRatingTask.m
//  mymenu
//
//  Created by Dang Duc Nam on 11/4/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_LocationRatingTask.h"
#import "string.h"

@implementation mm_LocationRatingTask
@synthesize postdata;
@synthesize delegate;

-(void)locationRating:(int *)rating comment:(NSString *)comment idLocation:(int *)idLocation{
        NSString *url = [NSString stringWithFormat:@"%@%d%@",locationRatingUrlStart,idLocation,locationRatingUrlEnd];
    
    postdata = [self toCreateJSON:rating comment:comment];
    NSLog(@"postdata: %@", postdata);
    
    NSLog(@"url %@", url);
    [self request:url];
}

-(void)request:(NSString *)url;
{
    //Declare NSData postData
	NSData *postData = [postdata dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
	
	//Declare NSString postLength and get length postData
	NSString *postLength = [NSString stringWithFormat:@"%d",[postData length]];
	
	//Declare NSMutableURLRequest request_url
    NSString *getVideoURL =url;
    
	NSMutableURLRequest *request_url = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",getVideoURL ]]                                         cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
                                                           timeoutInterval:1];
	//use method GET of request_url and set value of NSMutableURLRequest
	[request_url setHTTPMethod:@"POST"];
	[request_url setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request_url setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Current-Type"];
	[request_url setHTTPBody:postData];
    [request_url setTimeoutInterval:100];
	
	//init NSURLConnection connectionURL
	connectionURL = [[NSURLConnection alloc] initWithRequest:request_url delegate:self];
	if (connectionURL) {
        datacontent = [NSMutableData data] ;
    }
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [datacontent setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
    [datacontent appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    datacontent = nil;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *cotentfromserver= [[NSString alloc]initWithData:datacontent encoding:NSUTF8StringEncoding];
    NSLog(@"cotentfromserver = %@",cotentfromserver);
    
    NSData *jsonData = [cotentfromserver dataUsingEncoding:NSUTF8StringEncoding];
    NSError *e;
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:jsonData options:nil error:&e];
    
    NSString *status = [dict objectForKey:@"status"];
    NSLog(@"status: %@", status);
    if([status isEqual:@"success"]){
        [self.delegate locationRating_success];
    }else{
        [self.delegate locationRating_unsuccess:dict];
    }
}

- (NSString *)createJSONFromDictionary:(NSDictionary *)dictionary {
    NSError* error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:kNilOptions error:&error];
    if (!error) {
        NSString* jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return jsonString;
    } else {
        return nil;
    }
}

- (NSString *)toCreateJSON:(int *)rating comment:(NSString *)comment{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *token = [defaults stringForKey:kTokenkey];
    
    NSString *ratingstr = [NSString stringWithFormat:@"%d",rating];
    
    NSMutableDictionary *mutableDictionary = [NSMutableDictionary new];
    [mutableDictionary setObject:token forKey:kJsonToken];
    [mutableDictionary setObject:ratingstr forKey:kJsonRating];
    [mutableDictionary setObject:comment forKey:kJsonComment];
    
    
    NSDictionary *userInfo = [NSDictionary dictionaryWithDictionary:mutableDictionary];
    return [self createJSONFromDictionary:userInfo];
}


@end