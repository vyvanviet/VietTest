//
//  mm_LoginViewController.h
//  mymenu
//
//  Created by vo thanh hung on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mm_loginTask.h"
#import "mm_loginTwitterTask.h"
#import "mm_LoginViewController.h"

#import "NSString+EmailValidation.h"
#import "FacebookSDK/FacebookSDK.h"
#import "string.h"
#import "mm_forgotTask.h"
#import "GoogleOAuth.h"
#import <GooglePlus/GooglePlus.h>
@interface mm_LoginViewController : UIViewController<loginsusscessProtocol,loginTwittersusscessProtocol,forgotsusscessProtocol,UIAlertViewDelegate>{
    IBOutlet UIButton *btnSubmit;
    IBOutlet UIButton *btnCreateAccount;
    IBOutlet UIButton *btnForgot;
    IBOutlet UITextField *userName;
    IBOutlet UITextField *passWord;
   
    IBOutlet UIActivityIndicatorView *loading;
    IBOutlet UIScrollView *scrollView;
    UITextField *myEmailText;
   
 }

@property (strong, nonatomic) IBOutlet UIButton *btn_home;
- (IBAction)Demo_Test:(id)sender;
- (IBAction)toShare:(id)sender;

- (IBAction)btnBackTo:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btn_create_account;
@property (strong, nonatomic) IBOutlet UIButton *btnForgot;
@property (strong, nonatomic) IBOutlet UITextField *userName;
@property (strong, nonatomic) IBOutlet UITextField *passWord;
@property (strong, nonatomic)  IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) NSString *loggedInUserID;


@property (strong, nonatomic) FBSession *loggedInSession;
-(IBAction)btn_submit_click:(id)sender;
-(IBAction)btn_create_account_click:(id)sender;
-(IBAction)btn_google_login_click:(id)sender;

-(IBAction)btn_twitter_login_click:(id)sender;
-(IBAction)btn_forgot_click:(id)sender;
- (IBAction)authButtonAction:(id)sender;


@end
