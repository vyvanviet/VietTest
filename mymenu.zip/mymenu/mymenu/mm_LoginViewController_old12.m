//
//  mm_LoginViewController.m
//  mymenu
//
//  Created by vo thanh hung on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_LoginViewController.h"
#import <CoreLocation/CoreLocation.h>
#import <FacebookSDK/FBSessionTokenCachingStrategy.h>
#import "mm_AppDelegate.h"
#import "FHSTwitterEngine.h"
#import "mm_CreateAccountTask.h"


@interface mm_LoginViewController ()<FHSTwitterEngineAccessTokenDelegate,UITextFieldDelegate>{
    CGPoint originalOffset;
    UITextField *activeField;
}

@property (unsafe_unretained, nonatomic) IBOutlet UIButton *authButton;
@property (strong, nonatomic) IBOutlet UIButton *reauthButton;
@property(nonatomic,retain)NSString *userTwitter;
@property(nonatomic,retain)NSString *uidTwitter;
@property(nonatomic,retain)NSString *returnData;
@property(nonatomic,retain)NSString *provider;
@property (weak, nonatomic) IBOutlet FBLoginView *loginView;
@property (nonatomic, strong) GoogleOAuth *googleOAuth;
@property (nonatomic, strong) NSMutableArray *arrProfileInfo;
@property (nonatomic, strong) NSMutableArray *arrProfileInfoLabel;

@end

@implementation mm_LoginViewController
@synthesize loggedInUserID = _loggedInUserID;
@synthesize loggedInSession = _loggedInSession;
@synthesize userName,passWord,scrollView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)sessionStateChanged:(NSNotification*)notification {
    
    
    if (FBSession.activeSession.isOpen) {
        [self.authButton setTitle:@"Logout" forState:UIControlStateNormal];
        self.reauthButton.hidden = NO;
       
    } else {
        
        [self.authButton setTitle:@"Login" forState:UIControlStateNormal];
        self.reauthButton.hidden = YES;
        [[NSUserDefaults standardUserDefaults]setValue:@"facebook" forKey:kUserLoginMode];
        
        NSLog(@"hungcaoxuan2");
        
    }
}



- (void)gppInit {

  
    // Make sure the GPPSignInButton class is linked in because references from
    // xib file doesn't count.
    /*[GPPSignInButton class];
    
    GPPSignIn *signIn = [GPPSignIn sharedInstance];
    signIn.shouldFetchGooglePlusUser = YES;
    signIn.shouldFetchGoogleUserEmail = YES;
  
    // Sync the current sign-in configurations to match the selected
    // app activities in the app activity picker.
    
    signIn.delegate = self;*/
}- (void)viewDidLoad
{
    [super viewDidLoad];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillShow:)
                                                 name:UIKeyboardWillShowNotification
                                               object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self
                                             selector:@selector(keyboardWillHide:)
                                                 name:UIKeyboardWillHideNotification
                                               object:nil];
   
    _arrProfileInfo = [[NSMutableArray alloc] init];
    _arrProfileInfoLabel = [[NSMutableArray alloc] init];
    
	// Do any additional setup after loading the view.
    [self scrollviewScreen ];
    self.loginView.readPermissions = @[@"basic_info"];
     

    [[FHSTwitterEngine sharedEngine]permanentlySetConsumerKey:@"XlBErz6SjQ2iGmNbwyBeA" andSecret:@"6ZIYXu181ka3bfnh1HwUirBtuG8WPlB3K3e9kZMiM"];
    [[FHSTwitterEngine sharedEngine]setDelegate:self];
    
    
   self.userName.delegate = self;
    self.passWord.delegate = self;
    self.passWord.secureTextEntry = YES;
    self.userName.textAlignment = NSTextAlignmentCenter;
    self.passWord.textAlignment = NSTextAlignmentCenter;
//   
    [FBSession.activeSession closeAndClearTokenInformation];
    [FBSession.activeSession close];
    [FBSession setActiveSession:nil];
    
     //[[GPPSignIn sharedInstance] signOut];
    [[FHSTwitterEngine sharedEngine]clearAccessToken];
    [_googleOAuth revokeAccessToken];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(sessionStateChanged:)
     name:FBSessionStateChangedNotification
     object:nil];
    CGRect rect=self.view.frame;
    rect.origin.y=rect.origin.y-20;
    rect.size.height=rect.size.height+20;
    
    self.view.frame =rect;
    _googleOAuth = [[GoogleOAuth alloc] initWithFrame:self.view.frame];
    [_googleOAuth setGOAuthDelegate:self];
    
    // Check the session for a cached token to show the proper authenticated
    // UI. However, since this is not user intitiated, do not show the login UX.
//    mm_AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
//    [appDelegate openSessionWithAllowLoginUI:NO];
    
    [self openSessionWithAllowLoginUI:NO];
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboard)];
    
    [self.view addGestureRecognizer:tap];
    
    
    
 [self gppInit];
}
-(BOOL) shouldAutorotate {
    
    // Return YES for supported orientations
    return NO;
    
}

- (void)keyboardWillHide:(NSNotification *)aNotification
{
    // the keyboard is hiding reset the table's height
    NSTimeInterval animationDuration =
    [[[aNotification userInfo] objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    CGRect frame = self.view.frame;
    frame.origin.y += 160;
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    self.view.frame = frame;
    [UIView commitAnimations];
}

- (void)keyboardWillShow:(NSNotification *)aNotification
{
    // the keyboard is showing so resize the table's height
    NSTimeInterval animationDuration =
    [[[aNotification userInfo] objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    CGRect frame = self.view.frame;
    frame.origin.y -= 160;
    [UIView beginAnimations:@"ResizeForKeyboard" context:nil];
    [UIView setAnimationDuration:animationDuration];
    self.view.frame = frame;
    [UIView commitAnimations];
}


//hidden keyboard when input done


-(BOOL)textFieldShouldReturn:(UITextField *)textFie
{// When tab button Done of keyboard then hide keyboard
    
    [textFie resignFirstResponder];
    return YES;
}


-(void)viewDidAppear:(BOOL)animated{
    
    
    
    NSLog(@"btn_google_login_click");
    [_googleOAuth revokeAccessToken];
    if([self.provider isEqualToString:@"twitter"])
    {
        [[NSUserDefaults standardUserDefaults]setValue:@"existsTwitter" forKey:@"getFrom"];
         [self performSegueWithIdentifier:@"gotoCreateAccoutFrom" sender:nil];
        UIApplication* app = [UIApplication sharedApplication];
        app.networkActivityIndicatorVisible = NO;
    }
    }



//scroll screen start
-(void)scrollviewScreen
{
    UITapGestureRecognizer *singleTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:nil];
    [scrollView addGestureRecognizer:singleTap];
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(keyboardWillShowLogin:)
                                                 name: UIKeyboardWillShowNotification
                                               object: nil];
    
    [[NSNotificationCenter defaultCenter] addObserver: self
                                             selector: @selector(keyboardWillHideLogin:)
                                                 name: UIKeyboardWillHideNotification
                                               object: nil];

}

- (void)keyboardWillShowLogin: (NSNotification *) notification {
    NSDictionary* info = [notification userInfo];
    CGRect kbRect = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue];
	kbRect = [self.view convertRect:kbRect toView:nil];
    UIEdgeInsets contentInsets = UIEdgeInsetsMake(0.0, 0.0, kbRect.size.height, 0.0);
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
    
    CGRect aRect = self.view.frame;
    CGFloat width = aRect.size.width;
    CGFloat height = aRect.size.height;
    CGRect frame = CGRectMake(aRect.origin.x, aRect.origin.y, height, width);
    aRect = frame;
    aRect.size.height -= kbRect.size.height;
    CGPoint fieldOrigin = [self.view convertPoint:activeField.frame.origin fromView:[activeField superview]];
    originalOffset = scrollView.contentOffset;
    if (!CGRectContainsPoint(aRect, fieldOrigin) ) {
        CGRect fieldFrame = [scrollView convertRect:activeField.frame fromView:[activeField superview]];
        [scrollView scrollRectToVisible:fieldFrame animated:YES];
    }
}
- (void)keyboardWillHideLogin: (NSNotification *) notification {
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    scrollView.contentInset = contentInsets;
    scrollView.scrollIndicatorInsets = contentInsets;
    [scrollView setContentOffset:originalOffset animated:YES];
}
//end

- (void)viewDidUnload {
    
     [self setLoginView:nil];
    [self setAuthButton:nil];
    [self setReauthButton:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    
    [[NSNotificationCenter defaultCenter] removeObserver:self];
}

//facebook button login
- (IBAction)authButtonAction:(id)sender {
    NSLog(@"click button facebook ");
    
    
    mm_loginTwitterTask *taskTwitter=[[mm_loginTwitterTask alloc]init];
    taskTwitter.delegate = self;
    
    [taskTwitter loginTwitter:[[UIDevice currentDevice] uniqueIdentifier] provider:@"facebook" email:@""];

   
    
    
}

- (BOOL)openSessionWithAllowLoginUI:(BOOL)allowLoginUI {
    
    return [FBSession openActiveSessionWithReadPermissions:nil
                                              allowLoginUI:allowLoginUI
                                         completionHandler:^(FBSession *session,
                                                             FBSessionState state,
                                                             NSError *error) {
                                             [self sessionStateChanged:session
                                                                 state:state
                                                                 error:error];
                                         }];
}

/*
 *
 */
- (void) closeSession {
    [FBSession.activeSession closeAndClearTokenInformation];
}


- (void)sessionStateChanged:(FBSession *)session
                      state:(FBSessionState) state
                      error:(NSError *)error
{
    switch (state) {
        case FBSessionStateOpen:
            if (!error) {
                // We have a valid session
                //NSLog(@"User session found");
                [FBRequestConnection
                 startForMeWithCompletionHandler:^(FBRequestConnection *connection,
                                                   NSDictionary<FBGraphUser> *user,
                                                   NSError *error) {
                     
                     //mm_LoginViewController *login = (mm_LoginViewController *)[[UIApplication sharedApplication] delegate];
                     // login.abc = [[mm_loginTwitterTask alloc]init];
                     if (!error) {
                         self.loggedInUserID = user.id;
                         NSLog(@"hung cao %@",user.id);
                         
                         FBRequest *me = [FBRequest requestForGraphPath:@"me"];
                         [me startWithCompletionHandler:^(FBRequestConnection *connection,
                                                          NSDictionary<FBGraphUser> *my,
                                                          NSError *error) {
                             NSLog(@"My info: %@", my);
                             
                             SBJsonWriter *jsonWriter = [[SBJsonWriter alloc] init];
                             
                             NSString *jsonString = [jsonWriter stringWithObject:my];
                             
                             NSDictionary *jsonDict = [jsonString JSONValue];
                             NSString *email=[jsonDict objectForKey:@"email"];
                             NSLog(@"hung11 %@",email);
                             
                             NSString *fistName=user.first_name;
                             NSLog(@"fistName %@",fistName);
                             
                             NSString *lastName=user.last_name;
                             NSLog(@"lastName %@",lastName);
                             
                             NSString *address=@"";
                             NSLog(@"address %@",address);
                             
                             NSString *city=@"";
                             NSLog(@"city %@",city);
                             
                             NSString *state=[jsonDict objectForKey:@"locale"];
                             NSLog(@"state %@",state);
                             
                             NSString *zip=@"";
                             NSLog(@"zip %@",zip);
                             
                             NSString *gender=[jsonDict objectForKey:@"gender"];
                             NSLog(@"gender %@",gender);
                             
                             mm_AccountEntity *fbAcc = [[mm_AccountEntity alloc]init];
                             fbAcc.firstName = fistName;
                             fbAcc.lastName = lastName;
                             fbAcc.address = address;
                             fbAcc.city = city;
                             fbAcc.state = state;
                             fbAcc.zip = zip;
                             fbAcc.gender = gender;
                             fbAcc.email = email;
                             
                             
                             fbAcc.username = user.username;
                             fbAcc.password = @"";
                             
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.username forKey:kUserName];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.email forKey:kEmail];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.firstName forKey:kFirstName];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.lastName forKey:kLastName];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.address forKey:kaddress];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.city forKey:kCity];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.state forKey:kstate];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.zip forKey:kzip];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.gender forKey:kgender];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.points forKey:kpoints];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.age forKey:kage];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.avatar forKey:kavatar];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.favourite forKey:kfavourite];
                             [[NSUserDefaults standardUserDefaults]setValue:fbAcc.DefaultSearchProfile forKey:kDefaultSearchProfile];
                             [[NSUserDefaults standardUserDefaults]setValue:@"existsFB" forKey:@"getFrom"];
                             
                             [self performSegueWithIdentifier:@"gotoCreateAccoutFrom" sender:nil];
                             
                             
                         }];
                         
                         
                         //self.loggedInSession = FBSession.activeSession;
                     }
                 }];
            }
            break;
        case FBSessionStateClosed:
        case FBSessionStateClosedLoginFailed:
            [FBSession.activeSession closeAndClearTokenInformation];
            break;
        default:
            break;
    }
    
    [[NSNotificationCenter defaultCenter]
     postNotificationName:FBSessionStateChangedNotification
     object:session];
    
    if (error) {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Notice Message"
                                  message:error.localizedDescription
                                  delegate:nil
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil];
        [alertView show];
    }
}



- (void)openSession
{
    NSArray *permissions = [[NSArray alloc] initWithObjects: @"email", @"user_birthday", @"user_location", nil];
    
    
    [FBSession openActiveSessionWithPermissions:permissions allowLoginUI:YES completionHandler:^(FBSession *session, FBSessionState status, NSError *error) {
        if(error) {
            NSLog(@"Error opening session: %@", error);
            return;
        }
        
               
    }];
}



- (IBAction)reauthButtonAction:(id)sender {
    FBSessionTokenCachingStrategy *tokenCachingStrategy =
    [[FBSessionTokenCachingStrategy alloc] initWithUserDefaultTokenInformationKeyName:@"reauth"];
    FBSession *session = [[FBSession alloc] initWithAppID:nil
                                              permissions:nil
                                          urlSchemeSuffix:nil
                                       tokenCacheStrategy:tokenCachingStrategy];
    [FBSession setActiveSession:session];
    mm_AppDelegate *appDelegate = [[UIApplication sharedApplication] delegate];
    [session openWithBehavior:FBSessionLoginBehaviorForcingWebView
            completionHandler:^(FBSession *session,
                                FBSessionState status,
                                NSError *error) {
                if (!error) {
                    [FBRequestConnection
                     startForMeWithCompletionHandler:^(FBRequestConnection *connection,
                                                       NSDictionary<FBGraphUser> *user,
                                                       NSError *error) {
                         if (!error) {
                             if ([appDelegate loggedInUserID] == user.id) {
                                 NSLog(@"Matching users");
                             } else {
                                 NSLog(@"Error!! Not logged in user");
                             }
                         } else {
                             NSLog(@"Error getting user info");
                         }
                     }];
                    [FBSession setActiveSession:appDelegate.loggedInSession];
                } else {
                    NSLog(@"Error logging in user with webview");
                }
            }];
}





- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}



- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)btn_submit_click:(id)sender
{
    
    if([userName.text length ]>0 && [passWord.text length]>0)
    {
     [loading startAnimating];
    mm_loginTask *task=[[mm_loginTask alloc]init];
    task.delegate = self;
    
    NSString *user = [userName text];
    NSLog(@"username %@",user);
    NSString *pass = [passWord text];
    NSLog(@"password %@",pass);
    
    [task login:user password:pass];
    [userName resignFirstResponder];
    [passWord resignFirstResponder];
    }
    else{
        if([userName.text length ]==0)
        {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Notice Message"
                                                        message:@"Username or Email is required"
                                                       delegate:self
                                              cancelButtonTitle:btnOK
                                              otherButtonTitles:nil];
        [alert show];
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Notice Message"
                                                            message:@"Password is required"
                                                           delegate:self
                                                  cancelButtonTitle:btnOK
                                                  otherButtonTitles:nil];
            [alert show];
        }

    }
    
}

-(void)login_susscess:(mm_AccountEntity *)_account{
    
    [[NSUserDefaults standardUserDefaults]setValue:_account.acces_token forKey:kTokenkey];
    [[NSUserDefaults standardUserDefaults]setValue:_account.username forKey:kUserName];
    [[NSUserDefaults standardUserDefaults]setValue:_account.email forKey:kEmail];
    [[NSUserDefaults standardUserDefaults]setValue:_account.firstName forKey:kFirstName];
    [[NSUserDefaults standardUserDefaults]setValue:_account.lastName forKey:kLastName];
    [[NSUserDefaults standardUserDefaults]setValue:_account.address forKey:kaddress];
    [[NSUserDefaults standardUserDefaults]setValue:_account.city forKey:kCity];
    [[NSUserDefaults standardUserDefaults]setValue:_account.state forKey:kstate];
    [[NSUserDefaults standardUserDefaults]setValue:_account.zip forKey:kzip];
    [[NSUserDefaults standardUserDefaults]setValue:_account.gender forKey:kgender];
    [[NSUserDefaults standardUserDefaults]setValue:_account.points forKey:kpoints];
    [[NSUserDefaults standardUserDefaults]setValue:_account.age forKey:kage];
    [[NSUserDefaults standardUserDefaults]setValue:_account.avatar forKey:kavatar];
    [[NSUserDefaults standardUserDefaults]setValue:_account.favourite forKey:kfavourite];
    [[NSUserDefaults standardUserDefaults]setValue:_account.DefaultSearchProfile forKey:kDefaultSearchProfile];
    
    [loading stopAnimating];
    
    [self performSegueWithIdentifier:@"gotohomefromlogin" sender:nil];
}
-(void)login_unsusscess:(NSString *)error
{
    [loading stopAnimating];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:loixayra
                                                    message:error
                                                   delegate:self
                                          cancelButtonTitle:btnOK
                                          otherButtonTitles:nil];
    [alert show];

    
    NSLog(@"login fail");
}



-(IBAction)btn_google_login_click:(id)sender{
 NSLog(@"btn_google_login_click");
    mm_loginTwitterTask *taskTwitter=[[mm_loginTwitterTask alloc]init];
    taskTwitter.delegate = self;
    
    [taskTwitter loginTwitter:[[UIDevice currentDevice] uniqueIdentifier] provider:@"google" email:@""];
     
}


-(IBAction)btn_twitter_login_click:(id)sender{
    
            
        mm_loginTwitterTask *taskTwitter=[[mm_loginTwitterTask alloc]init];
        taskTwitter.delegate = self;
        
        [taskTwitter loginTwitter:[[UIDevice currentDevice] uniqueIdentifier] provider:@"twitter" email:@""];
        
   
    

    
    
    
}



-(void)loginTwitter_susscess:(mm_AccountEntity *)fbAcc{
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.acces_token forKey:kTokenkey];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.username forKey:kUserName];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.email forKey:kEmail];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.firstName forKey:kFirstName];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.lastName forKey:kLastName];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.address forKey:kaddress];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.city forKey:kCity];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.state forKey:kstate];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.zip forKey:kzip];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.gender forKey:kgender];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.points forKey:kpoints];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.age forKey:kage];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.avatar forKey:kavatar];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.favourite forKey:kfavourite];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.DefaultSearchProfile forKey:kDefaultSearchProfile];
    
    [self performSegueWithIdentifier:@"gotohomefromlogin" sender:nil];
}

-(void)loginTwitter_unsusscess:(NSString *)_provider
{
    NSLog(@"Error social provider %@",_provider);
    if([_provider isEqualToString:@"twitter"])
    {
        [[FHSTwitterEngine sharedEngine]showOAuthLoginControllerFromViewController:self withCompletion:^(BOOL success) {
            

        NSLog(success?@"L0L success":@"O noes!!! Loggen faylur!!!");
        self.userTwitter  = [[FHSTwitterEngine sharedEngine]loggedInUsername];
        self.uidTwitter = [[FHSTwitterEngine sharedEngine]loggedInID];
        NSLog(@"%@",self.userTwitter);
        NSLog(@"%@",self.uidTwitter);
        
        self.provider = @"twitter";
        mm_AccountEntity *fbAcc = [[mm_AccountEntity alloc]init];
        fbAcc.firstName = @"";
        fbAcc.lastName = @"";
        fbAcc.address = @"";
        fbAcc.city = @"";
        fbAcc.state = @"";
        fbAcc.zip = @"";
        fbAcc.gender = @"";
        
        fbAcc.email = @"";
        
        fbAcc.username = self.userTwitter;
        fbAcc.password = @"";
        
        
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.username forKey:kUserName];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.email forKey:kEmail];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.firstName forKey:kFirstName];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.lastName forKey:kLastName];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.address forKey:kaddress];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.city forKey:kCity];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.state forKey:kstate];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.zip forKey:kzip];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.gender forKey:kgender];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.points forKey:kpoints];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.age forKey:kage];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.avatar forKey:kavatar];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.favourite forKey:kfavourite];
        [[NSUserDefaults standardUserDefaults]setValue:fbAcc.DefaultSearchProfile forKey:kDefaultSearchProfile];
        
                 
        
    }];
}
    else if([_provider isEqualToString:@"facebook"])
    {
        [[NSUserDefaults standardUserDefaults]setValue:@"facebook" forKey:kUserLoginMode];
        if (FBSession.activeSession.isOpen) {
            [self closeSession];
        } else {
            
            [self openSessionWithAllowLoginUI:YES];
        }
    }
    else
    {
     [_googleOAuth authorizeUserWithClienID:@"90295778878.apps.googleusercontent.com"
                               andClientSecret:@"iPMnl2G01bcOV9VWSJpvJq2v"
                                 andParentView:self.view
                                     andScopes:[NSArray arrayWithObjects:@"https://www.googleapis.com/auth/userinfo.profile",@"https://www.googleapis.com/auth/userinfo.email", nil]
         ];

      }

}
    


-(void)accessTokenWasRevoked{
    
    
    [_arrProfileInfo removeAllObjects];
    [_arrProfileInfoLabel removeAllObjects];
    
}


-(void)responseFromServiceWasReceived:(NSString *)responseJSONAsString andResponseJSONAsData:(NSData *)responseJSONAsData{
    if ([responseJSONAsString rangeOfString:@"family_name"].location != NSNotFound) {
        NSError *error;
        NSMutableDictionary *dictionary = [NSJSONSerialization JSONObjectWithData:responseJSONAsData
                                                                          options:NSJSONReadingMutableContainers
                                                                            error:&error];
        if (error) {
            NSLog(@"An error occured while converting JSON data to dictionary.");
            return;
        }
        else{
             mm_AccountEntity *fbAcc = [[mm_AccountEntity alloc]init];
            if (_arrProfileInfoLabel != nil) {
                _arrProfileInfoLabel = nil;
                _arrProfileInfo = nil;
                _arrProfileInfo = [[NSMutableArray alloc] init];
            }
            
            _arrProfileInfoLabel = [[NSMutableArray alloc] initWithArray:[dictionary allKeys] copyItems:YES];
            for (int i=0; i<[_arrProfileInfoLabel count]; i++) {
              
                [_arrProfileInfo addObject:[dictionary objectForKey:[_arrProfileInfoLabel objectAtIndex:i]]];
                
                 
                if([[_arrProfileInfoLabel objectAtIndex:i] isEqualToString:@"family_name"])
                {
                    fbAcc.firstName = [_arrProfileInfo objectAtIndex:i];
                    NSLog(@"firstname = %@",fbAcc.firstName);
                }
                if([[_arrProfileInfoLabel objectAtIndex:i] isEqualToString:@"given_name"]){
                    fbAcc.lastName = [_arrProfileInfo objectAtIndex:i];
                    NSLog(@"lastName = %@",fbAcc.lastName);
                }
                 if([[_arrProfileInfoLabel objectAtIndex:i] isEqualToString:@"gender"]){
                    fbAcc.gender = [_arrProfileInfo objectAtIndex:i];
                     NSLog(@"gender = %@",fbAcc.gender);
                 }
                if([[_arrProfileInfoLabel objectAtIndex:i] isEqualToString:@"name"]){
                    fbAcc.username = [_arrProfileInfo objectAtIndex:i];
                    NSLog(@"username = %@",fbAcc.username);
                }
                if([[_arrProfileInfoLabel objectAtIndex:i] isEqualToString:@"locale"]){
                    fbAcc.state = [_arrProfileInfo objectAtIndex:i];
                    NSLog(@"state = %@",fbAcc.state);
                }
                
                if([[_arrProfileInfoLabel objectAtIndex:i] isEqualToString:@"email"]){
                    fbAcc.email= [_arrProfileInfo objectAtIndex:i];
                    NSLog(@"email = %@",fbAcc.email);
                }
                if([[_arrProfileInfoLabel objectAtIndex:i] isEqualToString:@"zip"]){
                    fbAcc.email= [_arrProfileInfo objectAtIndex:i];
                    NSLog(@"zip = %@",fbAcc.zip);
                }
            }

   

    fbAcc.address = @"";
    fbAcc.city = @"";
    
    fbAcc.zip = @"";
    
    
   
    
   
    fbAcc.password = @"";
    
    
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.username forKey:kUserName];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.email forKey:kEmail];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.firstName forKey:kFirstName];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.lastName forKey:kLastName];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.address forKey:kaddress];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.city forKey:kCity];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.state forKey:kstate];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.zip forKey:kzip];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.gender forKey:kgender];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.points forKey:kpoints];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.age forKey:kage];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.avatar forKey:kavatar];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.favourite forKey:kfavourite];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.DefaultSearchProfile forKey:kDefaultSearchProfile];
    
    
    [[NSUserDefaults standardUserDefaults]setValue:@"existsGoogle" forKey:@"getFrom"];
    [self performSegueWithIdentifier:@"gotoCreateAccoutFrom" sender:nil];    

            }
    }
}
  
-(void)errorOccuredWithShortDescription:(NSString *)errorShortDescription andErrorDetails:(NSString *)errorDetails{
    NSLog(@"%@", errorShortDescription);
    NSLog(@"%@", errorDetails);
}
   
  -(void)errorInResponseWithBody:(NSString *)errorMessage{
    NSLog(@"%@", errorMessage);
}  
-(void)authorizationWasSuccessful{
    [_googleOAuth callAPI:@"https://www.googleapis.com/oauth2/v1/userinfo"
           withHttpMethod:httpMethod_GET
       postParameterNames:nil postParameterValues:nil];    
}


-(void)register_susscess:(NSString *)token{
    [[NSUserDefaults standardUserDefaults]setValue:token forKey:kTokenkey];
    [self performSegueWithIdentifier:@"gotohomefromlogin" sender:nil];
}

-(void)register_unsusscess{
    NSLog(@"register social error ");
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:loixayra
                                                    message:messageError
                                                   delegate:self
                                          cancelButtonTitle:btnOK
                                          otherButtonTitles:nil];
    [alert show];
    
    
    NSLog(@"login fail");
}




- (void)storeAccessToken:(NSString *)accessToken {
    [[NSUserDefaults standardUserDefaults]setObject:accessToken forKey:@"SavedAccessHTTPBody"];
}

- (NSString *)loadAccessToken {
    return [[NSUserDefaults standardUserDefaults]objectForKey:@"SavedAccessHTTPBody"];
}




-(IBAction)btn_create_account_click:(id)sender{
    [self performSegueWithIdentifier:@"gotoCreateAccoutFrom" sender:nil];  
}


-(void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    
    if ([[segue identifier] isEqualToString:@"gotoHomeFromLogin"]) {
        //bi_HomeScreenViewController *homeview = [segue destinationViewController];
        // homeview.mUser_Id=mUser_Id;
    }
}
//Google login protocol begin
/*-(void)finishedWithAuth: (GTMOAuth2Authentication *)auth error: (NSError *) error
{
    if (error) {
        NSLog(@"error= @",error);
        return;
    }
    
    mm_AccountEntity *fbAcc = [[mm_AccountEntity alloc]init];
    fbAcc.firstName = @"";
    fbAcc.lastName = @"";
    fbAcc.address = @"";
    fbAcc.city = @"";
    fbAcc.state = @"";
    fbAcc.zip = @"";
    fbAcc.gender = @"";
   
    //fbAcc.email = [GPPSignIn sharedInstance].userEmail;
    
    fbAcc.username = @"";
    fbAcc.password = @"";
    
    mm_loginTwitterTask *taskTwitter=[[mm_loginTwitterTask alloc]init];
    taskTwitter.delegate = self;
    
    
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.username forKey:kUserName];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.email forKey:kEmail];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.firstName forKey:kFirstName];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.lastName forKey:kLastName];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.address forKey:kaddress];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.city forKey:kCity];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.state forKey:kstate];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.zip forKey:kzip];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.gender forKey:kgender];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.points forKey:kpoints];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.age forKey:kage];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.avatar forKey:kavatar];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.favourite forKey:kfavourite];
    [[NSUserDefaults standardUserDefaults]setValue:fbAcc.DefaultSearchProfile forKey:kDefaultSearchProfile];
    
    [self performSegueWithIdentifier:@"gotoCreateAccoutFrom" sender:nil];
    
    
   }*/
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if(buttonIndex == 1)
    {
        //check email validate
        NSLog(@"invalid");
        if (myEmailText.text.length == 0 || ![myEmailText.text isValidEmailAddress]) {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Error" message: @"Email is invalid" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
        }else
        {
            //call service
            [loading startAnimating];
            mm_forgotTask *task=[[mm_forgotTask alloc]init];
            task.delegate = self;
            [task forgot:myEmailText.text];
        }
    }
}

-(IBAction)btn_forgot_click:(id)sender
{
    UIAlertView *myAlertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"Forgot My Menu Password", @"new_list_dialog")
                                                          message:@"   " delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
    myEmailText = [[UITextField alloc] initWithFrame:CGRectMake(12.0, 45.0, 260.0, 25.0)];
    [myEmailText setBackgroundColor:[UIColor whiteColor]];
    myEmailText.placeholder = @"Email is required";
    [myAlertView addSubview:myEmailText];
    [myAlertView show];
}
-(void)dismissKeyboard {
    [userName resignFirstResponder];
    [passWord resignFirstResponder];
}
-(void)forgot_susscess
{
    NSLog(@"success");
    [loading stopAnimating];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Info" message: @"Your new password has been sent to your email address." delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

-(void)forgot_unsusscess
{
    NSLog(@"fail");
    [loading stopAnimating];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Info" message: @"System cannot send password to your email. Please try again!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}








- (IBAction)toShare:(id)sender {
     [self performSegueWithIdentifier:@"demo" sender:nil];  
}

- (IBAction)btnBackTo:(id)sender {
    NSString *url = [[NSUserDefaults standardUserDefaults] objectForKey:kBackTo];
    NSLog(@"url = %@",url);
    [self performSegueWithIdentifier:url sender:nil];  
}
@end
