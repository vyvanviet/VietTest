//
//  mm_MainViewController.h
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 10/30/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface mm_MainViewController : UIViewController<MKMapViewDelegate,UIScrollViewDelegate, UIGestureRecognizerDelegate,CLLocationManagerDelegate>
{
    UIScrollView *imagesScrollView;
    UIPanGestureRecognizer *scrGes;
    UIButton *registerButton;
    UIButton *loginButton;
    UIImageView *itemImage;
    UIPageControl *imagePageControl;
    NSInteger currentPage;
    BOOL inScroll;
    NSInteger currentPhoto;
    NSInteger currentIndex;
    NSInteger previousPage;
    UIView *opaqueView;
    BOOL panning;
}
@property (nonatomic, strong)UIScrollView *imagesScrollView;
@property (nonatomic, strong)IBOutlet UIPanGestureRecognizer *scrGes;
- (IBAction)registerButtonPressed:(id)sender;
- (IBAction)loginButtonPressed:(id)sender;
- (IBAction)pageControlSelected:(UIPageControl *)sender;
@end

