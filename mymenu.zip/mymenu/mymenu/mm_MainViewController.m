//
//  mm_MainViewController.m
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 10/30/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_MainViewController.h"
#import "string.h"
@interface mm_MainViewController ()

@end

@implementation mm_MainViewController
@synthesize imagesScrollView;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
        // Do any additional setup after loading the view from its nib.
        //[self.view addGestureRecognizer: self.slidingViewController.panGesture];
        //self.imagesScrollView.frame = [[UIScreen mainScreen] bounds];
        imagesScrollView = [[UIScrollView alloc]initWithFrame:[[UIScreen mainScreen] bounds]];
        imagesScrollView.pagingEnabled = YES;
        imagesScrollView.delegate = self;
        [self.view addSubview:imagesScrollView];
        //[self addGestureRecognizers];
        [self buildImageScrollView];
        imagePageControl = [[UIPageControl alloc] init];
        imagePageControl.frame = CGRectMake(self.view.frame.size.width/2 -50,self.view.frame.size.height- 80,100,20);
        imagePageControl.backgroundColor = [UIColor clearColor];
        imagePageControl.pageIndicatorTintColor = [UIColor grayColor];
        imagePageControl.currentPageIndicatorTintColor = [UIColor whiteColor];
        imagePageControl.numberOfPages = 5;
        imagePageControl.currentPage = 0;
        [self setUpGestureHandlersOnScrollView:imagesScrollView];
        [imagePageControl addTarget:self action:@selector(pageControlSelected:) forControlEvents:UIControlEventTouchUpInside];
        [self.view addSubview:imagePageControl];
        UIImage *regisImg = [UIImage imageNamed:@"btn_register.png"];
        UIButton *btnRegis = [UIButton buttonWithType:UIButtonTypeCustom];
        btnRegis.userInteractionEnabled = YES;
        [btnRegis setFrame:CGRectMake(10.0, self.view.frame.size.height - 50	, 130, 30)];
        [btnRegis setImage:regisImg forState:UIControlStateNormal];
        [btnRegis addTarget:self
                     action:@selector(registerButtonPressed:)
           forControlEvents:UIControlEventTouchDown];
        [self.view addSubview:btnRegis];
        UIImage *loginImg = [UIImage imageNamed:@"btn_login.png"];
        UIButton *btnLogin = [UIButton buttonWithType:UIButtonTypeCustom];
        btnLogin.userInteractionEnabled = YES;
        [btnLogin setFrame:CGRectMake(180 , self.view.frame.size.height - 50	, 130, 30)];
        [btnLogin setImage:loginImg forState:UIControlStateNormal];
        [btnLogin addTarget:self
                     action:@selector(loginButtonPressed:)
           forControlEvents:UIControlEventTouchDown];
        
        currentPhoto = 0;
        previousPage = 0;
        [self.view addSubview:btnLogin];
}
- (void) setUpGestureHandlersOnScrollView:(UIScrollView *)scrollView {
    NSLog(@"aaaa")
    ;    // set up a two-finger pan recognizer as a dummy to steal two-finger scrolls from the scroll view
    // we initialize without a target or action because we don't want the two-finger pan to be handled
    UIPanGestureRecognizer *twoFingerPan = [[UIPanGestureRecognizer alloc] init];
    //twoFingerPan.minimumNumberOfTouches = 1;
    //twoFingerPan.maximumNumberOfTouches = 2;
    [scrollView addGestureRecognizer:twoFingerPan];
    
    // set up the two-finger left and right swipe recognizers
    UISwipeGestureRecognizer *twoFingerSwipeLeft = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleGestureFrom:)];
    twoFingerSwipeLeft.direction = UISwipeGestureRecognizerDirectionLeft;
    //twoFingerSwipeLeft.numberOfTouchesRequired = 1;
    [scrollView addGestureRecognizer:twoFingerSwipeLeft];
    
    UISwipeGestureRecognizer *twoFingerSwipeRight = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(handleGestureFrom:)];
    twoFingerSwipeRight.direction = UISwipeGestureRecognizerDirectionRight;
    //twoFingerSwipeRight.numberOfTouchesRequired = 1;
    [scrollView addGestureRecognizer:twoFingerSwipeRight];
    
    // prevent the two-finger pan recognizer from stealing the two-finger swipe gestures
    // this is essential for the swipe recognizers to work
    [twoFingerPan requireGestureRecognizerToFail:twoFingerSwipeLeft];
    [twoFingerPan requireGestureRecognizerToFail:twoFingerSwipeRight];
}
- (void)handleGestureFrom:(UISwipeGestureRecognizer *)recognizer {
    NSLog(@"aaaabccc");
    if(recognizer.direction == UISwipeGestureRecognizerDirectionLeft)
    {
        [self scrollViewSwipedLeft:recognizer];
    }else if(recognizer.direction == UISwipeGestureRecognizerDirectionRight)
    {
        [self scrollViewSwipedRight:recognizer];
    }
}
-(void)scrollViewSwipedDown:(id)sender
{
    NSLog(@"sender %@",sender);
}
- (BOOL)gestureRecognizerShouldBegin:(UIGestureRecognizer *)gestureRecognizer{
    NSLog(@"sss");
    return YES;
}

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer{
    return YES;
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch{
    return YES;
}
- (void)scrollViewDidZoom:(UIScrollView *)scrollView {
    if (scrollView.zoomScale!=1.0) {
        // Zooming, enable scrolling
        scrollView.scrollEnabled = TRUE;
    } else {
        // Not zoomed, disable scrolling so gestures get used instead
        scrollView.scrollEnabled = FALSE;
    }
}
//- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
//    // Return YES for supported orientations
//    return NO;
//    
//    // Use this to allow upside down as well
//    //return (interfaceOrientation == UIInterfaceOrientationPortrait || interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
//}
-(BOOL) shouldAutorotate {
    
    // Return YES for supported orientations
    return NO;
    
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController setNavigationBarHidden:YES animated:animated];
    
}
#pragma mark Scroll Handlers
- (void)addGestureRecognizers {
    NSLog(@"gesture");
    UISwipeGestureRecognizer *leftSwipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(scrollViewSwipedLeft:)];
    leftSwipe.direction = UISwipeGestureRecognizerDirectionLeft;
    [imagesScrollView addGestureRecognizer:leftSwipe];
    
    UISwipeGestureRecognizer *rightSwipe = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(scrollViewSwipedRight:)];
    rightSwipe.direction = UISwipeGestureRecognizerDirectionRight;
    [imagesScrollView addGestureRecognizer:rightSwipe];
}

#pragma mark Helpers
- (void)buildImageScrollView {
    CGFloat xCoord = 0.;
    for (int i = 0; i< 5 ;i++) {
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(xCoord, 0, 320., self.view.frame.size.height)];
        UIImage *image = [UIImage imageNamed:[NSString stringWithFormat:@"img_%i.png",i+1]];
        imageView.image = image;
        [imagesScrollView addSubview:imageView];
        
        xCoord += 320.;
    }
    currentPhoto = 0.;
    [imagePageControl setNumberOfPages:5];
    imagePageControl.currentPage = 0;
    [imagesScrollView setContentSize:CGSizeMake(xCoord, self.view.frame.size.height)];
    
    //[self addGestureRecognizers];
    // [[iMenuAppController sharedController] removeActivityIndicator];
}

/*- (void)scrollViewSwipedDown:(UISwipeGestureRecognizer *)recognizer {
 //Scroll Up
 if (self.currentPage == 1) {
 [self scrollToScrollRegion:UIScrollRegionTop];
 } else if (self.currentPage == 2) {
 [self scrollToScrollRegion:UIScrollRegionMiddle];
 }
 
 }
 - (void)scrollViewSwipedUp:(UISwipeGestureRecognizer *)recognizer {
 //Scroll Down
 if (self.currentPage == 0) {
 [self scrollToScrollRegion:UIScrollRegionMiddle];
 } else if (self.currentPage == 1) {
 [self scrollToScrollRegion:UIScrollRegionBottom];
 }
 }*/
- (void)scrollViewSwipedLeft:(UISwipeGestureRecognizer *)recognizer {
    if (currentPhoto < 4) {
        
        currentPhoto ++;
        [imagesScrollView setContentOffset:CGPointMake(currentPhoto * 320, 0.) animated:YES];
        imagePageControl.currentPage = currentPhoto;
    }
}
- (void)scrollViewSwipedRight:(UISwipeGestureRecognizer *)recognizer {
    if (currentPhoto > 0) {
        currentPhoto --;
        [imagesScrollView setContentOffset:CGPointMake(currentPhoto * 320, 0.) animated:YES];
        imagePageControl.currentPage = currentPhoto;
        
    }
}
#pragma mark Action Methods
- (IBAction)registerButtonPressed:(id)sender {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:false forKey:kIsUpdateUser];
    [[NSUserDefaults standardUserDefaults]removeObjectForKey:@"getFrom"];
    [defaults synchronize];
    //[self performSegueWithIdentifier:@"gotologinfromsplash" sender:nil];
    [self performSegueWithIdentifier:@"gotoregisterfromsplash" sender:nil];
}
- (IBAction)loginButtonPressed:(id)sender {
    NSString *myString = [[NSUserDefaults standardUserDefaults] objectForKey:kTokenkey];
    NSLog(@"my String%@",myString);
    if([myString isEqualToString:@""] || !myString)
    {
        [[NSUserDefaults standardUserDefaults] setObject:@"backfromlogintosplash" forKey:kBackTo];
        [self performSegueWithIdentifier:@"gotologinfromsplash" sender:nil];
    }
    else
    {
        [self performSegueWithIdentifier:@"gotohomefromsplash" sender:self];
    }
    
}
- (IBAction)pageControlSelected:(UIPageControl *)sender {
    float scrollToRect = sender.currentPage * 320.;
    [imagesScrollView setContentOffset:CGPointMake(scrollToRect, 0.)];
}
- (void)homeViewController
{
    NSLog(@"hoooo");
    [self performSegueWithIdentifier:@"gotohomefromsplash" sender:self];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end

