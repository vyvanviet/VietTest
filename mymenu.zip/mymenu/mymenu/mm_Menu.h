//
//  mm_Menu.h
//  mymenu
//
//  Created by Le Nam on 11/5/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "mm_MenuCatalogy.h"
@interface mm_Menu : NSObject
@property (nonatomic, strong) NSString *mid;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *price;
@property (nonatomic, strong) NSString *image;
@property (nonatomic, strong) NSString *description;
@property (nonatomic, strong) NSString *calories;
@property (nonatomic, strong) NSString *reward_points;
@property (nonatomic, strong) NSString *category_id;
@property (nonatomic, strong) NSString *special_message;
@property (nonatomic, strong) NSString *rating;
@property (nonatomic, strong) NSString *review;
@property (nonatomic, strong) NSString *isFavorite;
@property (nonatomic, strong) NSString *isNexttime;
-(void)copyToShow:(mm_MenuCatalogy *)catalogy;
@end
