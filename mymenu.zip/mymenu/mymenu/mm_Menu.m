//
//  mm_Menu.m
//  mymenu
//
//  Created by Le Nam on 11/5/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_Menu.h"

@implementation mm_Menu
@synthesize mid,image,price,rating,reward_points,review,calories,category_id,name,description,special_message,isFavorite,isNexttime;
-(void)copyToShow:(mm_MenuCatalogy *)catalogy{
    mid=catalogy.mid;
    name=catalogy.name;
    isFavorite=catalogy.isFavorite;
    isNexttime=catalogy.isNexttime;
}
@end
