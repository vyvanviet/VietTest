//
//  mm_MenuCatalogy.h
//  mymenu
//
//  Created by Le Nam on 11/7/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//
#import <Foundation/Foundation.h>

@interface mm_MenuCatalogy : NSObject
@property (nonatomic, strong) NSString *mid;
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSString *reward_points;
@property (nonatomic, strong) NSString *isFavorite;
@property (nonatomic, strong) NSString *isNexttime;
@property (nonatomic, strong) NSMutableArray *itemsMenu;

@end
