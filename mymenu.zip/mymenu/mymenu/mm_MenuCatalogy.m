//
//  mm_MenuCatalogy.m
//  mymenu
//
//  Created by Le Nam on 11/7/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_MenuCatalogy.h"

@implementation mm_MenuCatalogy
@synthesize mid,itemsMenu,name,reward_points,isFavorite,isNexttime;
@end
