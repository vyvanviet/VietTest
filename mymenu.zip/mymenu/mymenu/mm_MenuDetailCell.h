//
//  mm_MenuDetailCell.h
//  mymenu
//
//  Created by Le Nam on 11/6/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mm_MenuDetailCell : UITableViewCell
{
    IBOutlet UIImageView *imvBackground;
    IBOutlet UIImageView *imvIconHeard;
    IBOutlet UIImageView *imvIconNextTime;
    IBOutlet UILabel *lblText;
}
@property (nonatomic,strong) IBOutlet UIImageView *imvBackground;
@property (nonatomic,strong) IBOutlet UIImageView *imvIconHeard;
@property (nonatomic,strong) IBOutlet UIImageView *imvIconNextTime;
@property (nonatomic,strong) IBOutlet UILabel *lblText;
@end
