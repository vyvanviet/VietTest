//
//  mm_MenuDetailCell.m
//  mymenu
//
//  Created by Le Nam on 11/6/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_MenuDetailCell.h"

@implementation mm_MenuDetailCell
@synthesize lblText,imvBackground,imvIconHeard,imvIconNextTime;
- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
