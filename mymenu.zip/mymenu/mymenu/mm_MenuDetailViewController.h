//
//  mm_MenuDetailViewController.h
//  mymenu
//
//  Created by Le Nam on 11/5/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "string.h"
#import "mm_LocationObject.h"
#import "mm_GetRestaurantMenuTask.h"
#import "mm_MenuDetailCell.h"
#import "mm_MenuCatalogy.h"
#import "mm_Menu.h"
//ngocptn#import "SpeechToTextModule.h"
#import "JSON.h"
@interface mm_MenuDetailViewController : UIViewController<getrestaurantmenuProtocol>//ngocptn,SpeechToTextModuleDelegate>
{
    
    IBOutlet UIView *uivShowWaiting;
    IBOutlet UIActivityIndicatorView *uivWaiting;
    IBOutlet UIButton *btnMySearch;
    IBOutlet UIButton *btnGoogleSearch;
    IBOutlet UIButton *btnStartOver;
    IBOutlet UIButton *btnOder;
    IBOutlet UIButton *btnPay;
    IBOutlet UIButton *btnNextTime;
    IBOutlet UITextField *txfSearchText;
    IBOutlet UILabel *txfRestaurantName;
     IBOutlet UIImageView *imvRestaurantIcon;
    IBOutlet UITableView *tbvDataTable;
    IBOutlet UITextField *textSearch;
    NSMutableArray *mSearchData;
    NSMutableArray *mOriginData;
    	//ngocptnSpeechToTextModule *stt;

}
//ngocptn@property(nonatomic,strong)SpeechToTextModule *stt;
@property(nonatomic,strong) IBOutlet UIView *uivShowWaiting;
@property(nonatomic,strong)IBOutlet UIActivityIndicatorView *uivWaiting;
@property(nonatomic,strong) IBOutlet UITextField *textSearch;
@property(nonatomic,strong)mm_LocationObject *locationObject;
@property (nonatomic,strong) IBOutlet UIButton *btnMySearch;

@property (nonatomic,strong)IBOutlet UIButton *btnGoogleSearch;
@property (nonatomic,strong)IBOutlet UIButton *btnStartOver;
@property (nonatomic,strong)IBOutlet UIButton *btnOder;
@property (nonatomic,strong)IBOutlet UIButton *btnPay;
@property (nonatomic,strong)IBOutlet UIButton *btnNextTime;
@property (nonatomic,strong)IBOutlet UITextField *txfSearchText;
@property (nonatomic,strong)IBOutlet UITableView *tbvDataTable;
@property (nonatomic,strong)NSMutableArray *mSearchData;

@property (nonatomic,strong) IBOutlet UILabel *txfRestaurantName;
@property (nonatomic,strong) IBOutlet UIImageView *imvRestaurantIcon;
 @property (nonatomic,strong) NSMutableArray *mOriginData;

-(IBAction)textSearchEditting:(id)sender;
- (IBAction)GoogleVoicePressed:(id)sender;
@end
