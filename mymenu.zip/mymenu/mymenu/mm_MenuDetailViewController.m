//
//  mm_MenuDetailViewController.m
//  mymenu
//
//  Created by Le Nam on 11/5/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_MenuDetailViewController.h"

@interface mm_MenuDetailViewController ()

@end

@implementation mm_MenuDetailViewController
@synthesize mSearchData,btnGoogleSearch,btnMySearch,btnNextTime,btnOder,btnPay,btnStartOver,tbvDataTable,txfSearchText,txfRestaurantName,imvRestaurantIcon,mOriginData,uivShowWaiting,uivWaiting;//ngocptn,stt;
@synthesize locationObject;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
    NSString *token=[[NSUserDefaults standardUserDefaults]valueForKey:kTokenkey];
    NSString *locationid=locationObject.idsv;
    NSLog(@"locationid = %@",locationid);
    NSLog(@"locationObject.logo = %@",locationObject.logo);
    [self showWatting];
    
   // if([locationObject.logo compare:@"<null>"]!=NSOrderedSame){
    if(![locationObject.logo isEqual:[NSNull null]]){
    NSData * imageData = [[NSData alloc] initWithContentsOfURL: [NSURL URLWithString: locationObject.logo]];
    imvRestaurantIcon.image = [UIImage imageWithData: imageData];
    }
    txfRestaurantName.text=locationObject.name;
    mm_GetRestaurantMenuTask *task=[[mm_GetRestaurantMenuTask alloc]init];
    mSearchData=[[NSMutableArray alloc]init];
    
    task.delegate=self;
    [task seach:locationid access_token:token];
    //ngocptnstt = [[SpeechToTextModule alloc] initWithCustomDisplay:NULL];
    //ngocptnstt.delegate=self;

}
-(void)showWatting{
    uivShowWaiting.hidden=NO;
    [uivWaiting startAnimating];
    
}
-(void)hideWatting{
    uivShowWaiting.hidden=YES;
    [uivWaiting stopAnimating];

}
- (void) getdata_success:(NSMutableArray *) restaurantArray{
    [self hideWatting];
    mOriginData=restaurantArray;
    if(mOriginData.count==0){
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Message"
                              message:@"Data Not Found"
                              delegate:self
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil];
        [alert show];

    }else{
        NSLog(@"co data");
        for (int i=0; i<mOriginData.count; i++) {
            mm_Menu *menu=[[mm_Menu alloc]init];
            mm_MenuCatalogy *catalgy=[mOriginData objectAtIndex:i];
            [menu copyToShow:catalgy];
            menu.name=[NSString stringWithFormat:@"%@(%d)",catalgy.name,catalgy.itemsMenu.count];
            [mSearchData addObject:menu];
        }
        [tbvDataTable reloadData];
    }

}

- (void) getdata_unsusscess:(NSString *)error{
     [self hideWatting];
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@"Notice Message"
                          message:@"Internet Connection Failed"
                          delegate:self
                          cancelButtonTitle:@"OK"
                          otherButtonTitles:nil];
    [alert show];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"delegate");
   }
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return mSearchData.count;

}
-(CGFloat)tableView: (UITableView*)tableView heightForRowAtIndexPath: (NSIndexPath*) indexPath{
    return 45;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"cellForRowAtIndexPath = %d",indexPath.row);
    static NSString *cellIdentifier = @"menudetailCell";
    //3
    mm_MenuDetailCell *tablecell = (mm_MenuDetailCell *)[tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    //3.1 you do not need this if you have set TableCellID as identifier in the storyboard (else you can remove the comments on this code). Do not use this code if you are following this tutorial
    //if (cell == nil)
    //    {
    //        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
    //   }
    
    //3.2
    
    mm_Menu * catalogy = [mSearchData objectAtIndex:indexPath.row];
    
    tablecell.lblText.text = catalogy.name;
    UIImage *favoriteIcon = [UIImage imageNamed:@"icon_favorites.png"];
    UIImage *nexttimeIcon = [UIImage imageNamed:@"icon_nexttime.png"];
    
    if([catalogy.isFavorite intValue]>0){
        tablecell.imvIconHeard.image=favoriteIcon;
    }else{
        tablecell.imvIconHeard.image=nil;
    }
    
    if([catalogy.isNexttime intValue]>0){
        tablecell.imvIconNextTime.image=nexttimeIcon;
    }else{
        tablecell.imvIconNextTime.image=nil;
    }
     UIImage *khungimg = [UIImage imageNamed:@"menudetail.png"];
    if(indexPath.row%2==0){
        tablecell.imvBackground.image=khungimg;
    }else{
        tablecell.imvBackground.image=nil;
    }
    //4
    return tablecell;
    
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
}

-(void)doLocalSearch{
    NSString *testSearch=txfSearchText.text;
    
    [ mSearchData removeAllObjects];
    
    NSLog(@"mOriginData.count =%d ",mOriginData.count);
    for (int i=0;i<mOriginData.count; i++) {
        mm_MenuCatalogy *catalo=[mOriginData objectAtIndex:i];
        int fault=0;
        NSArray*itemArray=catalo.itemsMenu;
        for(int j=0;j<itemArray.count;j++){
            mm_Menu *mMenu=[itemArray objectAtIndex:j];
            NSLog(@"mMenu.name = %@",mMenu.name );
            if ([mMenu.name rangeOfString:testSearch].location == NSNotFound){
            
            }else{
                fault=1;
                break;
            }
        }
        if(fault==1){
            
            mm_Menu *menu=[[mm_Menu alloc]init];
            [menu copyToShow:catalo];
            menu.name=[NSString stringWithFormat:@"%@(%d)",catalo.name,catalo.itemsMenu.count];
            [mSearchData addObject:menu];
        }
    }
    if(testSearch.length==0){
        for (int i=0; i<mOriginData.count; i++) {
            mm_Menu *menu=[[mm_Menu alloc]init];
            mm_MenuCatalogy *catalgy=[mOriginData objectAtIndex:i];
            [menu copyToShow:catalgy];
            menu.name=[NSString stringWithFormat:@"%@(%d)",catalgy.name,catalgy.itemsMenu.count];
            [mSearchData addObject:menu];
        }

    }
      NSLog(@"mSearchData.count =%d ",mSearchData.count);
    [tbvDataTable reloadData];
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [txfSearchText resignFirstResponder];
     [self showWatting];
    [self doLocalSearch];
    return NO;
}

-(IBAction)textSearchEditting:(id)sender{

}

//Google voice search begin
- (IBAction)GoogleVoicePressed:(id)sender{
  //ngocptn[stt beginRecording];
}
- (BOOL)didReceiveVoiceResponse:(NSData *)data{
    NSString *cotentfromserver= [[NSString alloc]initWithData:data encoding:NSUTF8StringEncoding];
    NSLog(@"google voicoi resule = %@",cotentfromserver);
    //  NSString *cotentfromserver=@"{\"status\":0,\"id\":\"7234983274239749832\",\"hypotheses\":[{\"utterance\":\"hello\",\"confidence\":0.5}]}";
    NSDictionary *jsonDict = [cotentfromserver JSONValue];
    NSString *status=[jsonDict objectForKey:@"status"];
    if([status intValue]==0){
        NSArray *resultArray=[jsonDict objectForKey:@"hypotheses"];
        if(resultArray.count>0){
            NSDictionary *object = [[NSDictionary alloc] initWithDictionary:[resultArray objectAtIndex:0]];
            NSString *text= [object objectForKey:@"utterance"];
            txfSearchText.text=text;
            [self doLocalSearch];
        }
    }else{
        //[stt beginRecording];
        
    }
    return YES;
}
//Google voice search end
@end
