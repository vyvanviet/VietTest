//
//  mm_MenuViewController.m
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 10/30/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_MenuViewController.h"

@interface mm_MenuViewController ()

@end

@implementation mm_MenuViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
