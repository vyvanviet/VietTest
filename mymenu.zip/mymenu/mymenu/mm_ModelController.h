//
//  mm_ModelController.h
//  mymenu
//
//  Created by Le Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>

@class mm_DataViewController;

@interface mm_ModelController : NSObject <UIPageViewControllerDataSource>

- (mm_DataViewController *)viewControllerAtIndex:(NSUInteger)index storyboard:(UIStoryboard *)storyboard;
- (NSUInteger)indexOfViewController:(mm_DataViewController *)viewController;

@end
