//
//  mm_MySearchViewController.h
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 11/1/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mm_MySearchViewController : UIViewController<UITableViewDataSource, UITableViewDelegate>
{
    IBOutlet UITableView *tblProfile;
    IBOutlet UIButton *btnSave;
    IBOutlet UIButton *btnCreate;
}
@property (nonatomic,strong)IBOutlet UITableView *tblProfile;
@property (nonatomic,strong)IBOutlet UIButton *btnSave;
@property (nonatomic,strong)IBOutlet UIButton *btnCreate;
-(IBAction)MySearchclick:(id)sender;
-(IBAction)MyCreateProfileClick:(id)sender;
-(IBAction)MySaveProfileClick:(id)sender;
@end
