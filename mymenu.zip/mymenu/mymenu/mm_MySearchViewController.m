//
//  mm_MySearchViewController.m
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 11/1/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_MySearchViewController.h"

@interface mm_MySearchViewController ()

@end

@implementation mm_MySearchViewController
@synthesize btnSave,btnCreate,tblProfile;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    //[super viewDidLoad];
    self.view.backgroundColor = [UIColor blueColor];
	// Do any additional setup after loading the view.
}
- (IBAction)MyCreateProfileClick:(id)sender {
    [btnCreate setBackgroundImage:[UIImage imageNamed:@"btn_createhove.png"] forState:UIControlStateNormal];
    [btnSave setBackgroundImage:[UIImage imageNamed:@"btn_saveprofile.png"] forState:UIControlStateNormal];
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
