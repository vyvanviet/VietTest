//
//  mm_RestaurantViewController.h
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 10/30/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mm_LocationObject.h"

@interface mm_RestaurantViewController : UIViewController<UIScrollViewDelegate>
{
    UIScrollView *imagesScrollView;
    UIPageControl *imagePageControl;
    IBOutlet UIImageView *imageRating;
    IBOutlet UIImageView *imageLogo;
    IBOutlet UIButton *btnMyMenu;
    UIView *viewAddButton;
    UIButton *btnShare;
    UIButton *btnInfo;
    UIButton *btnFavorites;
    UIButton *btnRating;
    UIImageView *imageViewInfo;
    int clickIndex;
}
@property (nonatomic, retain) UIScrollView *imagesScrollView;
@property (nonatomic, retain) UIPageControl *imagePageControl;
@property (nonatomic, retain) IBOutlet UIImageView *imageRating;
@property (nonatomic, retain) IBOutlet UIImageView *imageLogo;
@property(nonatomic,strong)IBOutlet UIButton *btnMyMenu;
@property (nonatomic, strong) NSArray *imageArray;
@property (nonatomic,strong) UIView *viewAddButton;
@property(nonatomic,strong)UIButton *btnShare;
@property(nonatomic,strong)UIButton *btnInfo;
@property(nonatomic,strong)UIButton *btnFavorites;
@property(nonatomic,strong)UIButton *btnRating;
@property(nonatomic,strong)mm_LocationObject *locationObject;
@property(nonatomic,strong)UIImageView *imageViewInfo;
@property (nonatomic, assign) NSString *accessToken;
@property (nonatomic, strong) NSString *valueFavorite;
@property(nonatomic,strong)UIImage *imageFavoritesCheck;
@property(nonatomic,strong)UIImage *imageFavoritesNonCheck;
@property(nonatomic,strong)NSString *statusValue;

-(IBAction)btnMyMenuClick:(id)sender;


@end
