//
//  mm_RestaurantViewController.m
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 10/30/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_RestaurantViewController.h"
#import "FacebookSDK/FacebookSDK.h"
#import "mm_LocationRatingController.h"
#import "mm_ShareSocialViewController.h"
#import "string.h"
#import "mm_SendFavoriteTask.h"

@interface mm_RestaurantViewController ()<sendfavoritesusscessProtocol>

@property (weak, nonatomic) IBOutlet FBLoginView *loginView;
@end

@implementation mm_RestaurantViewController
@synthesize imagesScrollView,imagePageControl,imageArray,imageLogo,imageRating,btnMyMenu,viewAddButton;
@synthesize btnFavorites,btnInfo,btnRating,btnShare,locationObject,imageViewInfo,accessToken,valueFavorite;
@synthesize imageFavoritesCheck,imageFavoritesNonCheck,statusValue;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
     self.loginView.readPermissions = @[@"basic_info"];
	// Do any additional setup after loading the view.    
//    NSLog(@"lat %@",locationObject.latitude);
//    NSLog(@"long %@",locationObject.longitude);
//    NSLog(@"name %@",locationObject.name);
    imageArray =locationObject.images;
    self.accessToken= [[NSUserDefaults standardUserDefaults] objectForKey:kTokenkey];
    NSString*logoUrl=[NSString stringWithFormat:@"%@",locationObject.logo];
    NSString *urlimage=[urlmagrabbit stringByAppendingString:logoUrl];
    UIImage *imageLogo1= [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:urlimage]]];
    if (locationObject.isFavourite.count>0) {        
            NSDictionary *objectFavourite=[[NSDictionary alloc]initWithDictionary:[locationObject.isFavourite objectAtIndex:0]];
            self.valueFavorite=[NSString stringWithFormat:@"%@",[objectFavourite objectForKey:@"favourite"]];
    }
    else
    {
        self.valueFavorite=@"2";
    }
    imageFavoritesNonCheck = [UIImage imageNamed: @"heart_40.png"];
    imageFavoritesCheck = [UIImage imageNamed: @"heart_red_40.png"];

    [self.imageLogo setImage:imageLogo1];
    self.imageLogo.contentMode=UIViewContentModeScaleAspectFit;    
    [self showImageRestaurant];
    [self showInfoRestaurant];
    NSLog(@"valueFavorite %@",self.valueFavorite);
    
}
-(void)viewDidUnload{
     [self setLoginView:nil];
    [super viewDidUnload];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
-(IBAction)btnMyMenuClick:(id)sender
{
    
}
-(void )sendFavorite_unsusscess
{
    
}
-(void) sendFavorite_susscess:(NSString *)status
{
    statusValue=status;    
}
-(void) showImageRestaurant
{
    self.imagesScrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 90, self.view.frame.size.width,250)];
    self.imagesScrollView.delegate=self;
    [self.imagesScrollView setCanCancelContentTouches:NO];
    
    self.imagesScrollView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
    self.imagesScrollView.clipsToBounds = YES;
    self.imagesScrollView.scrollEnabled = YES;
    self.imagesScrollView.pagingEnabled = YES;
    [self.imagesScrollView setBackgroundColor:[UIColor clearColor]];
    [self.imagesScrollView setContentOffset: CGPointMake(0, 0)];
    self.imagesScrollView.showsHorizontalScrollIndicator=NO;
    [self.view addSubview:self.imagesScrollView];
    //imageArray = [[NSArray alloc] initWithObjects:@"image_1.jpeg", @"image_2.jpeg", @"image_3.jpeg", nil];
    self.imagePageControl = [[UIPageControl alloc] init];
    self.imagePageControl.frame = CGRectMake(self.view.frame.size.width/2 -50,self.imagesScrollView.frame.size.height+60,100,20);
    self.imagePageControl.backgroundColor = [UIColor clearColor];
    self.imagePageControl.pageIndicatorTintColor = [UIColor whiteColor];
    self.imagePageControl.currentPageIndicatorTintColor = [UIColor yellowColor];
    self.imagePageControl.numberOfPages = [imageArray count];
    self.imagePageControl.currentPage = 0;        
    for (int i = 0; i < [imageArray count]; i++ ) {
        NSDictionary *objectImage=[[NSDictionary alloc]initWithDictionary:[imageArray objectAtIndex:i]];
        NSString*imageUrl=[NSString stringWithFormat:@"%@",[objectImage objectForKey:@"image"]];
        NSString *urlimage=[urlmagrabbit stringByAppendingString:imageUrl];
        //NSLog(@"urlimage = %@",urlimage);
        UIImage *image;
        image= [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:urlimage]]];
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(self.imagesScrollView.frame.size.width * i, 0,self.imagesScrollView.frame.size.width,self.imagesScrollView.frame.size.height)];
        [imageView setImage:image];
        //imageView.image = [UIImage imageNamed:[imageArray objectAtIndex:i]];
        [self.imagesScrollView addSubview:imageView];
    }
    self.imagesScrollView.contentSize = CGSizeMake(self.imagesScrollView.frame.size.
                                                   width *[imageArray count],
                                                   self.imagesScrollView.frame.size.height);
    viewAddButton=[[UIView alloc]initWithFrame:CGRectMake(0, 300, self.view.frame.size.width, 40)];
    UIColor *myColor = [UIColor colorWithRed:(0.0 / 255.0) green:(0.0 / 255.0) blue:(0.0 / 255.0) alpha: 0.6];
    [viewAddButton setBackgroundColor: myColor];
    [self.view addSubview:viewAddButton];
    [self.view addSubview:self.imagePageControl];
    btnShare = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btnShare addTarget:self action:@selector(shareButtonPressed:)
        forControlEvents:UIControlEventTouchDown];
    UIImage *imageShare = [UIImage imageNamed: @"share_40.PNG"];
    [btnShare setBackgroundImage:imageShare forState:UIControlStateNormal];
    [btnShare setFrame:CGRectMake(viewAddButton.frame.origin.x+20, viewAddButton.frame.origin.y+5, 30, 30)];
    [self.view addSubview:btnShare];
    btnInfo = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btnInfo addTarget:self action:@selector(infoButtonPressed:)
       forControlEvents:UIControlEventTouchDown];
    UIImage *imageInfo = [UIImage imageNamed: @"info_40.png"];
    [btnInfo setBackgroundImage:imageInfo forState:UIControlStateNormal];
    [btnInfo setFrame:CGRectMake(btnShare.frame.origin.x+50, btnShare.frame.origin.y, 30, 30)];
    [self.view addSubview:btnInfo];   
        
    btnFavorites = [UIButton buttonWithType:UIButtonTypeCustom];
    [btnFavorites addTarget:self action:@selector(favoritesButtonPressed:)
    forControlEvents:UIControlEventTouchDown];
    [btnFavorites setBackgroundImage:imageFavoritesNonCheck forState:UIControlStateNormal];
    [btnFavorites setFrame:CGRectMake(viewAddButton.frame.size.width -100, btnInfo.frame.origin.y, 30, 30)];
    if ([self.valueFavorite isEqual: @"2"]) {
        [btnFavorites setBackgroundImage:imageFavoritesNonCheck forState:UIControlStateNormal];
    }
    else
    {
        [btnFavorites setBackgroundImage:imageFavoritesCheck forState:UIControlStateSelected];
        [btnFavorites setSelected:YES];
    }
    [self.view addSubview:btnFavorites];
    btnRating = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    [btnRating addTarget:self action:@selector(ratingButtonPressed:)
           forControlEvents:UIControlEventTouchDown];
    UIImage *imageRatingIcon = [UIImage imageNamed: @"star_40.png"];
    [btnRating setBackgroundImage:imageRatingIcon forState:UIControlStateNormal];
    [btnRating setFrame:CGRectMake(viewAddButton.frame.size.width -50, btnFavorites.frame.origin.y, 30, 30)];
    [self.view addSubview:btnRating];    
    
}
-(void)showInfoRestaurant
{
    imageViewInfo = [[UIImageView alloc] initWithFrame:CGRectMake(0, self.imagesScrollView.frame.origin.y+self.imagesScrollView.frame.size.height,self.imagesScrollView.frame.size.width,self.view.frame.size.height-self.imagesScrollView.frame.size.height-90)];
    UIImage *imageInfo = [UIImage imageNamed: @"khung_thanhngang.PNG"];
    [imageViewInfo setImage:imageInfo];
    [self.view addSubview:imageViewInfo];
    UILabel *restaurantName=[[UILabel alloc ]initWithFrame:CGRectMake(40, self.imageViewInfo.frame.origin.y+15, 250, 20)];
    [restaurantName setBackgroundColor:[UIColor clearColor]];
    restaurantName.textColor=[UIColor whiteColor];
    restaurantName.text=locationObject.name;
    [self.view addSubview:restaurantName];
    UIButton *btnRestaurantBio=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnRestaurantBio setBackgroundColor:[UIColor clearColor]];    
    [btnRestaurantBio addTarget:self action:@selector(bioButtonPressed:)
      forControlEvents:UIControlEventTouchDown];
    [btnRestaurantBio setTitle:@"Bio" forState:UIControlStateNormal];
    [btnRestaurantBio setFrame:CGRectMake(self.view.frame.size.width-80, restaurantName.frame.origin.y, 40, 20)];    
    [self.view addSubview:btnRestaurantBio];
    UIButton *btnRestaurantAddress=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnRestaurantAddress setBackgroundColor:[UIColor clearColor]];
    [btnRestaurantAddress addTarget:self action:@selector(addressButtonPressed:) forControlEvents:UIControlEventTouchDown];
    [btnRestaurantAddress setTitle:[NSString stringWithFormat:@"%@ %@,%@",locationObject.address,locationObject.state,locationObject.city] forState:UIControlStateNormal];
    [btnRestaurantAddress setFrame:CGRectMake(restaurantName.frame.origin.x, restaurantName.frame.origin.y+30, 250, 20)];
    btnRestaurantAddress.titleLabel.font = [UIFont systemFontOfSize:11];
    btnRestaurantAddress.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [self.view addSubview:btnRestaurantAddress];
    UIButton *btnPhone=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnRestaurantAddress setBackgroundColor:[UIColor clearColor]];
    [btnPhone addTarget:self action:@selector(phoneButtonPressed:) forControlEvents:UIControlEventTouchDown];
    [btnPhone setTitle:[NSString stringWithFormat:@"Phone:(%@).%@ |",locationObject.zip,locationObject.phone] forState:UIControlStateNormal];
    [btnPhone setFrame:CGRectMake(btnRestaurantAddress.frame.origin.x, btnRestaurantAddress.frame.origin.y+20, 100, 20)];
    UIButton *openRestaurant=[UIButton buttonWithType:UIButtonTypeCustom];
    [openRestaurant setBackgroundColor:[UIColor clearColor]];
    [openRestaurant addTarget:self action:@selector(openButtonPressed:) forControlEvents:UIControlEventTouchDown];
    [openRestaurant setTitle:[NSString stringWithFormat:@"Open time: %@",locationObject.hour_of_operation] forState:UIControlStateNormal];
    [openRestaurant setFrame:CGRectMake(btnPhone.frame.origin.x+btnPhone.frame.size.width, btnPhone.frame.origin.y, 100, 20)];
    openRestaurant.titleLabel.font = [UIFont systemFontOfSize:11];
    openRestaurant.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [self.view addSubview:openRestaurant];
    UIButton *btnUrl=[UIButton buttonWithType:UIButtonTypeCustom];
    [btnUrl setBackgroundColor:[UIColor clearColor]];
    [btnUrl addTarget:self action:@selector(urlButtonPressed:) forControlEvents:UIControlEventTouchDown];
    [btnUrl setTitle:[NSString stringWithFormat:@"%@",locationObject.url] forState:UIControlStateNormal];
    [btnUrl setFrame:CGRectMake(btnPhone.frame.origin.x, btnPhone.frame.origin.y+20, 250, 20)];
    btnUrl.titleLabel.font = [UIFont systemFontOfSize:11];
    btnUrl.contentHorizontalAlignment = UIControlContentHorizontalAlignmentLeft;
    [self.view addSubview:btnUrl];   
    
}
- (void)scrollViewDidScroll:(UIScrollView *)sender
{
    CGFloat pageWidth = self.imagesScrollView.frame.size.width;
    //calculate current page in scrollview
    int page = floor((self.imagesScrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
    self.imagePageControl.currentPage = page;
}
- (IBAction)shareButtonPressed:(id)sender {
    clickIndex = 1;
    
     [self performSegueWithIdentifier:@"gotoshareviewcontroller" sender:nil];
    
}
- (IBAction)infoButtonPressed:(id)sender {
    
}
- (IBAction)favoritesButtonPressed:(id)sender {
    
    mm_SendFavoriteTask *sendFavoriteTask=[[mm_SendFavoriteTask alloc]init];
    sendFavoriteTask.delegate=self;
    NSLog(@"self.accessToken %@",self.accessToken);
    NSLog(@"locationObject.idsv %@",locationObject.idsv);
    NSString *favItem;
    NSLog(@"ket qua la %@",self.valueFavorite);
    if(btnFavorites.isSelected)
    {
        [btnFavorites setSelected:NO];
        favItem=@"2";
    }
    else
    {
        [btnFavorites setSelected:YES];
        favItem=@"1";
    }
    [sendFavoriteTask sendFavorite:self.accessToken favItem:favItem dRestaurant:locationObject.idsv];
}
- (IBAction)ratingButtonPressed:(id)sender {
    clickIndex = 2;
    [self performSegueWithIdentifier:@"loginGotoLocationRating" sender:nil];
}
- (IBAction)phoneButtonPressed:(id)sender {
    NSLog(@"aaaa");
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"tel:%@",locationObject.phone]]];
}
- (IBAction)addressButtonPressed:(id)sender {
    
    CLLocationCoordinate2D currentLocation = CLLocationCoordinate2DMake([locationObject.latitude doubleValue], [locationObject.longitude doubleValue]);
    NSString* address = [NSString stringWithFormat:@"%@ %@,%@",locationObject.address,locationObject.state,locationObject.city];
    NSString* url = [NSString stringWithFormat: @"http://maps.google.com/maps?saddr=%f,%f&daddr=%@",
                     currentLocation.latitude, currentLocation.longitude,
                     [address stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    [[UIApplication sharedApplication] openURL: [NSURL URLWithString: url]];
}
- (IBAction)urlButtonPressed:(id)sender {
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",locationObject.url]]];
}
- (IBAction)openButtonPressed:(id)sender {
}

-(void)prepareForSegue:(UIStoryboardSegue*)segue sender:(id)sender
{
    if(clickIndex == 2)
    {
        mm_LocationRatingController *viewController = [segue destinationViewController];
        viewController.locationObject = locationObject;
    }else if(clickIndex == 1)
    {
        mm_ShareSocialViewController *viewController = [segue destinationViewController];
        viewController.locationObject = locationObject;
    }
}

@end
