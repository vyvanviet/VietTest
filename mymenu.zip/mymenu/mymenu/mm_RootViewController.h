//
//  mm_RootViewController.h
//  mymenu
//
//  Created by Le Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mm_RootViewController : UIViewController <UIPageViewControllerDelegate>

@property (strong, nonatomic) UIPageViewController *pageViewController;

@end
