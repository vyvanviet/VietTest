//
//  mm_RootViewController.m
//  mymenu
//
//  Created by Le Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_RootViewController.h"

#import "mm_ModelController.h"

#import "mm_DataViewController.h"

@interface mm_RootViewController ()
@property (readonly, strong, nonatomic) mm_ModelController *modelController;
@end

@implementation mm_RootViewController

@synthesize modelController = _modelController;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    // Configure the page view controller and add it as a child view controller.
    [NSTimer scheduledTimerWithTimeInterval:0.5
                                     target:self
                                   selector:@selector(gotoHomeFromLogin)
                                   userInfo:nil
                                    repeats:NO];

}
-(void) gotoHomeFromLogin{
    NSLog(@"gotoHomeFromLogin");
      NSString * str = [[NSUserDefaults standardUserDefaults]objectForKey:@"facebook"];
    NSLog(@"hung %@",str);
    if([str isEqualToString:@"true"])
    {
      //  [self performSegueWithIdentifier:@"gotohomefromlogin" sender:nil];
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (mm_ModelController *)modelController
{
     // Return the model controller object, creating it if necessary.
     // In more complex implementations, the model controller may be passed to the view controller.
    if (!_modelController) {
        _modelController = [[mm_ModelController alloc] init];
    }
    return _modelController;
}

#pragma mark - UIPageViewController delegate methods

/*
- (void)pageViewController:(UIPageViewController *)pageViewController didFinishAnimating:(BOOL)finished previousViewControllers:(NSArray *)previousViewControllers transitionCompleted:(BOOL)completed
{
    
}
 */

- (UIPageViewControllerSpineLocation)pageViewController:(UIPageViewController *)pageViewController spineLocationForInterfaceOrientation:(UIInterfaceOrientation)orientation
{
    // Set the spine position to "min" and the page view controller's view controllers array to contain just one view controller. Setting the spine position to 'UIPageViewControllerSpineLocationMid' in landscape orientation sets the doubleSided property to YES, so set it to NO here.
    UIViewController *currentViewController = self.pageViewController.viewControllers[0];
    NSArray *viewControllers = @[currentViewController];
    [self.pageViewController setViewControllers:viewControllers direction:UIPageViewControllerNavigationDirectionForward animated:YES completion:NULL];

    self.pageViewController.doubleSided = NO;
    return UIPageViewControllerSpineLocationMin;
}

@end
