//
//  mm_SeachNomalTask.h
//  mymenu
//
//  Created by Le Cao Hoai Yen on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//
#import "mm_sycndata.h"
#import <Foundation/Foundation.h>


@protocol searchnormalusscessProtocol   //define delegate protocol
- (void) searchnormal_susscess:(NSMutableArray *) array;  //define delegate method to be implemented within another class
- (void) searchnormal_unsusscess;

@end //end protocol


@interface mm_SeachNomalTask : mm_sycndata
{
    NSString *postdata;
}
@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <searchnormalusscessProtocol> delegate;
-(void)search:(NSString *)access_token latitude:(NSString *)lat longitude:(NSString *)longi name:(NSString *)name;
@end
