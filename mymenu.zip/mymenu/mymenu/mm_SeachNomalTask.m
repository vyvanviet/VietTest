//
//  mm_SeachNomalTask.m
//  mymenu
//
//  Created by Le Cao Hoai Yen on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_SeachNomalTask.h"
#import "JSON.h"
#import "string.h"
#import "mm_LocationObject.h"
@implementation mm_SeachNomalTask
@synthesize postdata;
@synthesize delegate;

-(void)search:(NSString *)access_token latitude:(NSString *)lat longitude:(NSString *)longi name:(NSString *)name {

    postdata =[NSString stringWithFormat:@"access_token=%@&latitude=%@&longitude=%@&name=%@",access_token,lat,longi ,name];
    NSLog(@"search postdata = %@",postdata);
    [self request:searchnormalurl];

    }
-(void)request:(NSString *)url;
{
    NSData *postData = [postdata dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
	
	//Declare NSString postLength and get length postData
	NSString *postLength = [NSString stringWithFormat:@"%d",[postData length]];
	NSLog(@"lengh postdata = %@",postLength);
	//Declare NSMutableURLRequest request_url
    NSString *searchURL =url;
    searchURL = [searchURL stringByAppendingString:postdata];
    [searchURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSString *urlEncodeing=[searchURL stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    //searchURL = [searchURL stringByReplacingOccurrencesOfString:@" "                                         withString:@"%20"];
    NSLog(@"searchURL %@",urlEncodeing);
    //NSURL *url = [NSURL URLWithString:searchURL];
    NSMutableURLRequest *request_url = [[NSMutableURLRequest alloc] init] ;
    [request_url setURL:[NSURL URLWithString:urlEncodeing]];
    
    NSLog(@"request_url = %@",request_url);
	//init NSURLConnection connectionURL
	connectionURL = [[NSURLConnection alloc] initWithRequest:request_url delegate:self];
    NSLog(@"connectionURL= %@",connectionURL);
	if (connectionURL) {
        datacontent = [NSMutableData data] ;
        
        NSLog(@"datacontent= %@",datacontent);
	}
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [datacontent setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
    [datacontent appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {    
	
	datacontent = nil;
    [self.delegate searchnormal_unsusscess];    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *cotentfromserver= [[NSString alloc]initWithData:datacontent encoding:NSUTF8StringEncoding];   
    NSLog(@"cotentfromserver = %@",cotentfromserver);    
    //NSDictionary *location1= [cotentfromserver JSONValue];
//    NSData* data = [cotentfromserver dataUsingEncoding:NSUTF8StringEncoding];
//    NSError *e;
//    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&e];
//    NSArray * values = [dict allKeys];
//    
//    NSLog(@"data la =%d",[values count]);
    NSArray *arrayJson=[cotentfromserver JSONFragmentValue];
    if (arrayJson.count>0) {
        NSMutableArray *locationArray=[NSMutableArray arrayWithCapacity:arrayJson.count];
        for (int i=0;i<[arrayJson count];  i++) {
            NSDictionary *objectJson=[[NSDictionary alloc]initWithDictionary:[arrayJson objectAtIndex:i]];
            mm_LocationObject *locaObject=[[mm_LocationObject alloc]init];
            NSString *ulrLogo=[objectJson objectForKey:@"logo"];
            NSLog(@"ulrLogo= %@",ulrLogo);
            locaObject.idsv=[objectJson objectForKey:@"id"];
            locaObject.name=[objectJson objectForKey:@"name"];
            locaObject.address=[objectJson objectForKey:@"address"];
            locaObject.city=[objectJson objectForKey:@"city"];
            locaObject.state=[objectJson objectForKey:@"state"];
            locaObject.country=[objectJson objectForKey:@"country"];
            locaObject.created_at=[objectJson objectForKey:@"created_at"];
            locaObject.latitude=[objectJson objectForKey:@"lat"];
            locaObject.longitude=[objectJson objectForKey:@"long"];
            locaObject.phone=[objectJson objectForKey:@"phone"];
            locaObject.owner_id=[objectJson objectForKey:@"owner_id"];
            locaObject.url=[objectJson objectForKey:@"url"];
            locaObject.rating=[objectJson objectForKey:@"rating"];
            locaObject.redeemption_password=[objectJson objectForKey:@"redeemption_password"];
            locaObject.slug=[objectJson objectForKey:@"slug"];
            locaObject.subscription_type=[objectJson objectForKey:@"subscription_type"];
            locaObject.updated_at=[objectJson objectForKey:@"updated_at"];
            locaObject.zip=[objectJson objectForKey:@"zip"];
            locaObject.tax=[objectJson objectForKey:@"tax"];
            locaObject.hour_of_operation=[objectJson objectForKey:@"hour_of_operation"];
            locaObject.bio=[objectJson objectForKey:@"bio"];
            locaObject.logo=[objectJson objectForKey:@"logo"];
            locaObject.distance=[objectJson objectForKey:@"distance"];
            locaObject.isFavourite=[objectJson objectForKey:@"isFavourite"];
            locaObject.images=[objectJson objectForKey:@"images"];
            locaObject.restaurantIconURLString=[urlmagrabbit stringByAppendingString:ulrLogo];
            [locationArray addObject:locaObject];
        }
        [self.delegate searchnormal_susscess:locationArray];
    }
    else
    {
        [self.delegate searchnormal_unsusscess];
    }
}


@end
