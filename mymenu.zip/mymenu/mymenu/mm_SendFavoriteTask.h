//
//  mm_SendFavoriteTask.h
//  mymenu
//
//  Created by Le Cao Hoai Yen on 11/6/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "mm_sycndata.h"
@protocol sendfavoritesusscessProtocol   //define delegate protocol
- (void) sendFavorite_susscess:(NSString *) status;  //define delegate method to be implemented within another class
- (void) sendFavorite_unsusscess;

@end //end protocol

@interface mm_SendFavoriteTask : mm_sycndata
{
    NSString *postdata;
}
@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <sendfavoritesusscessProtocol> delegate;
-(void)sendFavorite:(NSString *)access_token favItem:(NSString *)favItem dRestaurant:(NSString *)idr;
@end