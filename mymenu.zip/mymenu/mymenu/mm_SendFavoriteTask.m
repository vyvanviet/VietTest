//
//  mm_SendFavoriteTask.m
//  mymenu
//
//  Created by Le Cao Hoai Yen on 11/6/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_SendFavoriteTask.h"
#import "string.h"
#import "JSON.h"

@implementation mm_SendFavoriteTask
@synthesize postdata;
@synthesize delegate;
- (NSString *)createJSONFromDictionary:(NSDictionary *)dictionary {
    NSError* error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:kNilOptions error:&error];
    if (!error) {
        NSString* jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return jsonString;
    } else {
        return nil;
    }
}
-(void)sendFavorite:(NSString *)access_token favItem:(NSString *)favItem dRestaurant:(NSString *)idr
{
    NSLog(@"access_token %@",access_token);    
    NSMutableDictionary *mutableDictionary = [NSMutableDictionary new];    
    if (access_token.length > 0) {
        [mutableDictionary setObject:access_token forKey:@"access_token"];
    }    
    if (favItem.length > 0) {
        [mutableDictionary setObject:favItem forKey:@"favItem"];
    }
    NSDictionary *favoriteInfo = [NSDictionary dictionaryWithDictionary:mutableDictionary];
    postdata=[self createJSONFromDictionary:favoriteInfo];
    NSLog(@"login postdata = %@",postdata);
    NSString *urlServiceFavorite=[NSString stringWithFormat:@"/locations/%@/comment.json",idr];
    NSString *sendFavoriteUrl=[urlmagrabbit stringByAppendingString:urlServiceFavorite];
    NSLog(@"sendFavoriteUrl= %@",sendFavoriteUrl);
    [self request:sendFavoriteUrl];
}
-(void)request:(NSString *)url;
{
    //Declare NSData postData
	NSData *postData = [postdata dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
	
	//Declare NSString postLength and get length postData
	NSString *postLength = [NSString stringWithFormat:@"%d",[postData length]];
	
	//Declare NSMutableURLRequest request_url
    NSString *favoriteSendUrl =url;
    
	NSMutableURLRequest *request_url = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",favoriteSendUrl ]]                                         cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
                                                           timeoutInterval:1];
	//use method GET of request_url and set value of NSMutableURLRequest
	[request_url setHTTPMethod:@"POST"];
	[request_url setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request_url setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Current-Type"];
	[request_url setHTTPBody:postData];
    [request_url setTimeoutInterval:100];
	
	//init NSURLConnection connectionURL
	connectionURL = [[NSURLConnection alloc] initWithRequest:request_url delegate:self];
	if (connectionURL) {
        datacontent = [NSMutableData data] ;
	}
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [datacontent setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
    [datacontent appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {    
	
	datacontent = nil;
    [self.delegate sendFavorite_unsusscess];
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *cotentfromserver= [[NSString alloc]initWithData:datacontent encoding:NSUTF8StringEncoding];
    NSLog(@"cotentfromserver = %@",cotentfromserver);
    NSDictionary *jsonDict = [cotentfromserver JSONValue];
    NSString *status=[jsonDict objectForKey:@"status"];
    if ([status isEqual: @"success"]) {
        [self.delegate sendFavorite_susscess:@"success"];
    }
    else
        
    {
        [self.delegate sendFavorite_unsusscess];
    }

    
    
}

@end
