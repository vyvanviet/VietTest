//
//  mm_SettingViewController.h
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mm_logoutTask.h"
#import "GoogleOAuth.h"
@interface mm_SettingViewController : UIViewController< UIAlertViewDelegate,logoutsusscessProtocol>
{
    mm_logoutTask *request;
    IBOutlet UILabel *lblMail;
}
@property (nonatomic,strong)IBOutlet UILabel *lblMail;
@property (nonatomic,strong) UIView *viewIndicator;
@property (nonatomic, strong) GoogleOAuth *googleOAuth;
- (IBAction)myMenuClick:(id)sender;
- (IBAction)updateUserClick:(id)sender;
- (IBAction)logoutClick:(id)sender;
@end
