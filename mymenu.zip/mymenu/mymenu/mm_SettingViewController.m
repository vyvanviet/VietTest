//
//  mm_SettingViewController.m
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_SettingViewController.h"
#import <FacebookSDK/FacebookSDK.h>
#import "FHSTwitterEngine.h"
#import "GoogleOAuth.h"
#import "string.h"

@interface mm_SettingViewController ()

@end

@implementation mm_SettingViewController
@synthesize viewIndicator;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    NSLog(@"viewdidload setting");
    [super viewDidLoad];
    request = [[mm_logoutTask alloc]init];
    request.delegate = self;
    self.lblMail.textColor = [UIColor whiteColor];
    self.lblMail.backgroundColor = [UIColor clearColor];
    self.lblMail.textAlignment = NSTextAlignmentCenter;
    //NSString *myEmail = [[NSUserDefaults standardUserDefaults] stringForKey:@"email"];
    NSString *myEmail = [[NSUserDefaults standardUserDefaults] stringForKey:kEmail];
    self.lblMail.text = myEmail;
	// Do any additional setup after loading the view.
    _googleOAuth = [[GoogleOAuth alloc] initWithFrame:self.view.frame];
    [_googleOAuth setGOAuthDelegate:self];
}

-(void)logout_susscess
{
    //return to login view
    [self performSegueWithIdentifier:@"gotologinfromsetting" sender:nil];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kTokenkey];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kUserName];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kEmail];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kFirstName];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kLastName];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kaddress];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kCity];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kstate];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kzip];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kgender];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kpoints];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kage];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kavatar];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kPassword];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kfavourite];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultSearchProfile];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kIsUpdateUser];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"valueRegis"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    [viewIndicator removeFromSuperview];
    /*[FBSession.activeSession closeAndClearTokenInformation];
    [FBSession.activeSession close];
    [FBSession setActiveSession:nil];
    
    //[[GPPSignIn sharedInstance] signOut];
    [[FHSTwitterEngine sharedEngine]clearAccessToken];
    [_googleOAuth revokeAccessToken];*/

}

-(void)logout_unsusscess
{
    [viewIndicator removeFromSuperview];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Logout" message: @"Logout Failed" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}
- (IBAction)myMenuClick:(id)sender {
    NSLog(@"myMenuClick");
    //[self dismissViewControllerAnimated:YES completion:nil];
    [self performSegueWithIdentifier:@"gotoleftfromsetting" sender:self];
    //self.slidingViewController.underLeftViewController  = [LeftTabViewController new];
    //[self.slidingViewController anchorTopViewTo:ECRight];
}
- (IBAction)updateUserClick:(id)sender {
    NSLog(@"updateUserClick");
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setBool:true forKey:kIsUpdateUser];
    [defaults synchronize];
    
    [self performSegueWithIdentifier:@"gotocreatefromsetting" sender:nil];
    //self.slidingViewController.underLeftViewController  = [LeftTabViewController new];
    //[self.slidingViewController anchorTopViewTo:ECRight];
}
- (IBAction)logoutClick:(id)sender {
    NSLog(@"logoutClick");
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle: @"Logout" message: @"Are you sure you want to log out?" delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK",nil];
    [alert show];
    //self.slidingViewController.underLeftViewController  = [LeftTabViewController new];
    //[self.slidingViewController anchorTopViewTo:ECRight];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 0) {
        NSLog(@"user pressed OK");
    } else {
        //call service
        NSLog(@"user pressed Cancel");
        NSString *myAccess = [[NSUserDefaults standardUserDefaults] stringForKey:kTokenkey];
        //ngocptn
        
        //myAccess = @"h65ACUrZF6nLJ81DP85p";
        [request logout:myAccess];
        viewIndicator=[[UIView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height)];
        [viewIndicator setBackgroundColor: [UIColor clearColor]];
        UIActivityIndicatorView *activityView=[[UIActivityIndicatorView alloc]     initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        
        activityView.center=self.view.center;
        activityView.color = [UIColor grayColor];
        [activityView startAnimating];
        [viewIndicator addSubview:activityView];
        [self.view addSubview:viewIndicator];
        //
    }
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
