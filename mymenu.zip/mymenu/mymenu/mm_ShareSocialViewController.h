//
//  mm_ShareSocialViewController.h
//  mymenu
//
//  Created by vo thanh hung on 11/4/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mm_delegateAlertView.h"
#import "mm_LocationObject.h"
@interface mm_ShareSocialViewController : UIViewController<sharefacebookprotocol>{
    

    IBOutlet UIImageView *postImageView;
    IBOutlet UITextView *postMessageTextView;
    mm_delegateAlertView *delegateAlert;
    IBOutlet UILabel *postNameLabel;
    
    IBOutlet UILabel *postCaptionLabel;
    mm_LocationObject *locationObject;
}
@property(nonatomic,strong)mm_LocationObject *locationObject;
- (IBAction)google_share:(id)sender;
- (IBAction)facebook_share:(id)sender;
- (IBAction)twitter_share:(id)sender;
- (IBAction)intergram_share:(id)sender;

- (IBAction)sms_share:(id)sender;
- (IBAction)returnPress:(id)sender;
- (IBAction)email_share:(id)sender;







@end
