//
//  mm_ShareSocialViewController.m
//  mymenu
//
//  Created by vo thanh hung on 11/4/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_ShareSocialViewController.h"
#import "FacebookSDK/FacebookSDK.h"
#import "mm_AppDelegate.h"
#import "string.h"
#import "FHSTwitterEngine.h"
#import <Social/Social.h>
#import <MessageUI/MessageUI.h>
//ngocptn#import <GooglePlus/GooglePlus.h>
#import <QuartzCore/QuartzCore.h>




NSString *const kPlaceholderPostMessage = @"Say something about this...";


@interface mm_ShareSocialViewController ()<UITextViewDelegate,
UIAlertViewDelegate,FHSTwitterEngineAccessTokenDelegate>

@property (strong, nonatomic) NSMutableDictionary *postParams;
@property (strong, nonatomic) NSMutableData *imageData;
@property (strong, nonatomic) NSURLConnection *imageConnection;
@property (nonatomic, retain) UIDocumentInteractionController *dic;  



@end

@implementation mm_ShareSocialViewController
//@synthesize docFile = _docFile;
@synthesize locationObject;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    NSLog(@"hungcaoxuan");
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
        
        
        
    }
    return self;
}

- (void)storeAccessToken:(NSString *)accessToken {
    [[NSUserDefaults standardUserDefaults]setObject:accessToken forKey:@"SavedAccessHTTPBody"];
}

- (NSString *)loadAccessToken {
    return [[NSUserDefaults standardUserDefaults]objectForKey:@"SavedAccessHTTPBody"];
}


- (void)resetPostMessage
{
    postMessageTextView.text = kPlaceholderPostMessage;
    postMessageTextView.textColor = [UIColor lightGrayColor];
}

/*
 * Publish the story
 */
- (void)publishStory
{
    [FBRequestConnection
     startWithGraphPath:@"me/feed"
     parameters:self.postParams
     HTTPMethod:@"POST"
     completionHandler:^(FBRequestConnection *connection,
                         id result,
                         NSError *error) {
         NSString *alertText;
         if (error) {
             alertText = [NSString stringWithFormat:
                          @"error: domain = %@, code = %d",
                          error.domain, error.code];
         } else {
             alertText = [NSString stringWithFormat:
                          @"Posted action, id: %@",
                          result[@"id"]];
         }
         // Show the result in an alert
         [[[UIAlertView alloc] initWithTitle:@"Result"
                                     message:alertText
                                    delegate:nil
                           cancelButtonTitle:@"OK!"
                           otherButtonTitles:nil]
          show];
     }];
}



- (void)gppInit {
    
    
    // Make sure the GPPSignInButton class is linked in because references from
    // xib file doesn't count.
    /*[GPPSignInButton class];
     
     GPPSignIn *signIn = [GPPSignIn sharedInstance];
     signIn.shouldFetchGooglePlusUser = YES;
     signIn.shouldFetchGoogleUserEmail = YES;
     
     // Sync the current sign-in configurations to match the selected
     // app activities in the app activity picker.
     
     signIn.delegate = self;*/
}


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self gppInit];
    
    [[FHSTwitterEngine sharedEngine]permanentlySetConsumerKey:@"XlBErz6SjQ2iGmNbwyBeA" andSecret:@"6ZIYXu181ka3bfnh1HwUirBtuG8WPlB3K3e9kZMiM"];
    [[FHSTwitterEngine sharedEngine]setDelegate:self];
    
    
  
    
    delegateAlert = [[mm_delegateAlertView alloc]init];
    delegateAlert.delegate=self;
    
    self.postParams = [@{
                       @"link" : @"https://developers.facebook.com/ios",
                       @"picture" : @"https://developers.facebook.com/attachment/iossdk_logo.png",
                       @"name" : @"Facebook",
                       @"caption" : @"http://google.com",
                       @"description" : @"The Facebook SDK for iOS makes it easier and faster to develop Facebook integrated iOS apps."
                       } mutableCopy];
    postMessageTextView.delegate = self;
    [self resetPostMessage];
    // Set up the post information, hard-coded for this sample
    postNameLabel.text = self.postParams[@"name"];
    postCaptionLabel.text = self.postParams[@"caption"];
    [postCaptionLabel sizeToFit];
    
    [[NSNotificationCenter defaultCenter]
     addObserver:self
     selector:@selector(sessionStateChanged:)
     name:FBSessionStateChangedNotification
     object:nil];
    
    self.imageData = [[NSMutableData alloc] init];
    NSURLRequest *imageRequest = [NSURLRequest
                                  requestWithURL:
                                  [NSURL URLWithString:
                                   self.postParams[@"picture"]]];
    self.imageConnection = [[NSURLConnection alloc] initWithRequest:
                            imageRequest delegate:self];
    
    
    
    
}

#pragma mark - NSURLConnection delegate methods
- (void)connection:(NSURLConnection*)connection
    didReceiveData:(NSData*)data{
    [self.imageData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection{
    // Load the image
    NSLog(@"hung");
    postImageView.image = [UIImage imageWithData:
                           [NSData dataWithData:self.imageData]];
    self.imageConnection = nil;
    self.imageData = nil;
}

- (void)connection:(NSURLConnection *)connection
  didFailWithError:(NSError *)error{
    self.imageConnection = nil;
    self.imageData = nil;
}

#pragma mark - UIAlertViewDelegate methods
- (void) alertView:(UIAlertView *)alertView
didDismissWithButtonIndex:(NSInteger)buttonIndex
{
    [[self presentingViewController]
     dismissModalViewControllerAnimated:YES];
}

- (void)viewDidUnload
{
    
    [super viewDidUnload];
    
    
    if (self.imageConnection) {
        [self.imageConnection cancel];
        self.imageConnection = nil;
    }
    
    
    
}






- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

/*
 * A simple way to dismiss the message text view:
 * whenever the user clicks outside the view.
 */
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *) event
{
    UITouch *touch = [[event allTouches] anyObject];
    if ([postMessageTextView isFirstResponder] &&
        (postMessageTextView != touch.view))
    {
        [postMessageTextView resignFirstResponder];
    }
}



- (BOOL)openSessionWithAllowLoginUI:(BOOL)allowLoginUI {
    
    return [FBSession openActiveSessionWithReadPermissions:nil
                                              allowLoginUI:allowLoginUI
                                         completionHandler:^(FBSession *session,
                                                             FBSessionState state,
                                                             NSError *error) {
                                             [self sessionStateChanged:session
                                                                 state:state
                                                                 error:error];
                                         }];
}

- (void)sessionStateChanged:(FBSession *)session
                      state:(FBSessionState) state
                      error:(NSError *)error
{
    
    switch (state) {
        case FBSessionStateOpen:
            if (!error) {
                // We have a valid session
                //NSLog(@"User session found");
                [FBRequestConnection
                 startForMeWithCompletionHandler:^(FBRequestConnection *connection,
                                                   NSDictionary<FBGraphUser> *user,
                                                   NSError *error) {
                     
                     //mm_LoginViewController *login = (mm_LoginViewController *)[[UIApplication sharedApplication] delegate];
                     // login.abc = [[mm_loginTwitterTask alloc]init];
                     if (!error) {
                         
                         NSLog(@"hung cao %@",user.id);
                         
                         FBRequest *me = [FBRequest requestForGraphPath:@"me"];
                         [me startWithCompletionHandler:^(FBRequestConnection *connection,
                                                          NSDictionary<FBGraphUser> *my,
                                                          NSError *error) {
                             NSLog(@"My info: %@", my);
                             
                             // Hide keyboard if showing when button clicked
                             if ([postMessageTextView isFirstResponder]) {
                                 [postMessageTextView resignFirstResponder];
                             }
                             // Add user message parameter if user filled it in
                             if (![postMessageTextView.text
                                   isEqualToString:kPlaceholderPostMessage] &&
                                 ![postMessageTextView.text isEqualToString:@""]) {
                                 self.postParams[@"message"] = postMessageTextView.text;
                             }
                             
                             // Ask for publish_actions permissions in context
                             if ([FBSession.activeSession.permissions
                                  indexOfObject:@"publish_actions"] == NSNotFound) {
                                 // No permissions found in session, ask for it
                                 [FBSession.activeSession
                                  requestNewPublishPermissions:@[@"publish_actions"]
                                  defaultAudience:FBSessionDefaultAudienceFriends
                                  completionHandler:^(FBSession *session, NSError *error) {
                                      if (!error) {
                                          // If permissions granted, publish the story
                                          [self publishStory];
                                      }
                                  }];
                             } else {
                                 // If permissions present, publish the story
                                 [self publishStory];
                             }

                             
                             
                             
                         }];
                         
                         
                         //self.loggedInSession = FBSession.activeSession;
                     }
                 }];
            }
            break;
        case FBSessionStateClosed:
        case FBSessionStateClosedLoginFailed:
            [FBSession.activeSession closeAndClearTokenInformation];
            break;
        default:
            break;
    }

       
}



#pragma mark - UITextViewDelegate methods
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    NSLog(@"cao hung");
    // Clear the message text when the user starts editing
    if ([textView.text isEqualToString:kPlaceholderPostMessage]) {
        NSLog(@"dasdasd");
        textView.text = @"";
        textView.textColor = [UIColor blackColor];
    }
}

- (void)textViewDidEndEditing:(UITextView *)textView
{
    // Reset to placeholder text if the user is done
    // editing and no message has been entered.
    if ([textView.text isEqualToString:@""]) {
        [self resetPostMessage];
    }
}





/*- (IBAction)cancel_click:(id)sender {
}

- (IBAction)post_click:(id)sender {
    
   
    
        
}
- (IBAction)returnPress:(id)sender{
    [self performSegueWithIdentifier:@"gotoresfromshare" sender:nil];
}
- (IBAction)google_share:(id)sender {
    
    NSLog(@"CLick google share");
    
    [[NSUserDefaults standardUserDefaults]setValue:@"google" forKey:kUserLoginMode];
    [[GPPSignIn sharedInstance]authenticate];
  
    
}


//Google login protocol begin
-(void)finishedWithAuth: (GTMOAuth2Authentication *)auth error: (NSError *) error
 {
     if (error)
     {
         NSLog(@"error= %@",error);
         return;
     }
     else
     {
         if ([[GPPSignIn sharedInstance] authentication])
         {
             
             id<GPPNativeShareBuilder> shareBuilder = [[GPPShare sharedInstance] nativeShareDialog];
             [shareBuilder setURLToShare:[NSURL URLWithString:@"sample valid url"]];
             [shareBuilder setPrefillText:postMessageTextView.text];
             [(id<GPPNativeShareBuilder>)shareBuilder attachImage:postImageView.image];
             
             [shareBuilder open];
         }

     }

  
 
 }



- (void) share_facebook{
    
    NSLog(@"CLick OK");
     [[NSUserDefaults standardUserDefaults]setValue:@"facebook_share" forKey:kUserLoginMode];
    if (FBSession.activeSession.isOpen) {
        
       
        // Hide keyboard if showing when button clicked
        if ([postMessageTextView isFirstResponder]) {
            [postMessageTextView resignFirstResponder];
        }
        // Add user message parameter if user filled it in
        if (![postMessageTextView.text
              isEqualToString:kPlaceholderPostMessage] &&
            ![postMessageTextView.text isEqualToString:@""]) {
            self.postParams[@"message"] = postMessageTextView.text;
        }
        
        // Ask for publish_actions permissions in context
        if ([FBSession.activeSession.permissions
             indexOfObject:@"publish_actions"] == NSNotFound) {
            // No permissions found in session, ask for it
            [FBSession.activeSession
             requestNewPublishPermissions:@[@"publish_actions"]
             defaultAudience:FBSessionDefaultAudienceFriends
             completionHandler:^(FBSession *session, NSError *error) {
                 if (!error) {
                     // If permissions granted, publish the story
                     [self publishStory];
                 }
             }];
        } else {
            // If permissions present, publish the story
            [self publishStory];
        }
        
        
        
    } else {
        // The user has initiated a login, so call the openSession method
        // and show the login UX if necessary.
        [self openSessionWithAllowLoginUI:YES];
    }
    
    
}
-(void)share_facebook_cancel{
     NSLog(@"click cancel");
}



- (IBAction)facebook_share:(id)sender {
    
    
    UIAlertView *av = [[UIAlertView alloc]initWithTitle:@"Share Facebook" message:@"" delegate:delegateAlert
 cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
    [av setAlertViewStyle:UIAlertViewStyleDefault];
    
   
    [av show];
    
    
    
    
    
}






- (IBAction)twitter_share:(id)sender {
  
    
    if ([SLComposeViewController isAvailableForServiceType:SLServiceTypeTwitter])
    {
        SLComposeViewController *tweetSheet = [SLComposeViewController
                                               composeViewControllerForServiceType:SLServiceTypeTwitter];
        [tweetSheet setInitialText:postMessageTextView.text];
        [tweetSheet addImage:postImageView.image];
        [self presentViewController:tweetSheet animated:YES completion:nil];
        }
    
    
    
    
}

- (IBAction)intergram_share:(id)sender {
    NSLog(@"intargram");
    
    CGRect rect = CGRectMake(0 ,0 , 0, 0);
    
    UIGraphicsBeginImageContextWithOptions(self.view.bounds.size, self.view.opaque, 0.0);
    [self.view.layer renderInContext:UIGraphicsGetCurrentContext()];
    UIGraphicsEndImageContext();
    //NSString  *jpgPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/Icon_120.PNG"];
    
    NSURL *igImageHookFile = [[NSURL alloc] initWithString:@"https://developers.facebook.com/attachment/iossdk_logo.png"];
    
    self.docFile.UTI = @"com.instagram.photo";
    self.docFile = [self setupControllerWithURL:igImageHookFile usingDelegate:self];
    self.docFile=[UIDocumentInteractionController interactionControllerWithURL:igImageHookFile];
    [self.docFile presentOpenInMenuFromRect: rect inView: self.view animated: YES ];
    NSURL *instagramURL = [NSURL URLWithString:@"instagram://media?id=MEDIA_ID"];
    if ([[UIApplication sharedApplication] canOpenURL:instagramURL]) {
        [self.docFile presentOpenInMenuFromRect: rect    inView: self.view animated: YES ];
    }
    else {
        NSLog(@"No Instagram Found");
    }

    
}

- (UIDocumentInteractionController *) setupControllerWithURL: (NSURL*) fileURL usingDelegate: (id <UIDocumentInteractionControllerDelegate>) interactionDelegate {
    
    UIDocumentInteractionController *interactionController = [UIDocumentInteractionController interactionControllerWithURL: fileURL];
    interactionController.delegate = interactionDelegate;
    
    return interactionController;
}





- (void)documentInteractionControllerWillPresentOpenInMenu:(UIDocumentInteractionController *)controller {
    
}






- (IBAction)sms_share:(id)sender {
    
    MFMessageComposeViewController *viewController = [[MFMessageComposeViewController alloc] init];
    viewController.body = @"hung";
  
     
    [self presentModalViewController:viewController animated:YES];
    
    
    
}

- (IBAction)email_share:(id)sender {
    if ([MFMailComposeViewController canSendMail])
    {
        
         UIImage *imageName = postImageView.image;
        MFMailComposeViewController *mailer = [[MFMailComposeViewController alloc] init];
        
        mailer.mailComposeDelegate = self;
        
        [mailer setSubject:@"A Message from My menu"];
        
        NSArray *toRecipients = [NSArray arrayWithObjects:@"fisrtMail@example.com", @"secondMail@example.com", nil];
        [mailer setToRecipients:toRecipients];
        
        //UIImage *myImage = [UIImage imageNamed:@"mobiletuts-logo.png"];
        NSData *imageData = UIImagePNGRepresentation(imageName);
        [mailer addAttachmentData:imageData mimeType:@"image/png" fileName:@"mobiletutsImage"];
        
        NSString *emailBody = postMessageTextView.text;
        [mailer setMessageBody:emailBody isHTML:NO];
        
        // only for iPad
        // mailer.modalPresentationStyle = UIModalPresentationPageSheet;
        
        [self presentModalViewController:mailer animated:YES];
        
       
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Notice Message"
                                                        message:@"Your device doesn't support the composer sheet"
                                                       delegate:nil
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles: nil];
        [alert show];
       
    }

    
    
}

- (void)mailComposeController:(MFMailComposeViewController*)controller didFinishWithResult:(MFMailComposeResult)result error:(NSError*)error
{
	switch (result)
	{
		case MFMailComposeResultCancelled:
			NSLog(@"Mail cancelled: you cancelled the operation and no email message was queued");
			break;
		case MFMailComposeResultSaved:
			NSLog(@"Mail saved: you saved the email message in the Drafts folder");
			break;
		case MFMailComposeResultSent:
			NSLog(@"Mail send: the email message is queued in the outbox. It is ready to send the next time the user connects to email");
			break;
		case MFMailComposeResultFailed:
			NSLog(@"Mail failed: the email message was nog saved or queued, possibly due to an error");
			break;
		default:
			NSLog(@"Mail not sent");
			break;
	}
    
	[self dismissModalViewControllerAnimated:YES];
}*/


@end
