//
//  mm_UpdateUserImageTask.h
//  mymenu
//
//  Created by Dang Duc Nam on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "mm_sycndata.h"

@protocol updateUserImageProtocol

- (void) updateUserImage_success:(NSDictionary *) dict;
- (void) updateUserImage_unsuccess:(NSDictionary *) dict;

@end

@interface mm_UpdateUserImageTask : mm_sycndata

@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <updateUserImageProtocol> delegate;

-(void) updateImage:(UIImage *)userImage;

@end
