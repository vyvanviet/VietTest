//
//  mm_UpdateUserImageTask.m
//  mymenu
//
//  Created by Dang Duc Nam on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_UpdateUserImageTask.h"
#import "mm_sycnData.h"
#import "string.h"

UIImage *image;

@implementation mm_UpdateUserImageTask
@synthesize postdata;
@synthesize delegate;

-(void)updateImage:(UIImage *)userImage{
    image = userImage;
    [self request];
}

-(void)request;
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *token = [defaults stringForKey:kTokenkey];
    
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc] init];
    [request setCachePolicy:NSURLRequestReloadIgnoringLocalCacheData];
    [request setHTTPShouldHandleCookies:NO];
    [request setTimeoutInterval:30];
    [request setHTTPMethod:@"POST"];
    
    // set Content-Type in HTTP header
    NSString *boundary = @"----------V2ymHFg03ehbqgZCaKO6jy";//[NSString stringWithFormat:@"%f", [NSDate timeIntervalSinceReferenceDate]];
    boundary = [boundary stringByReplacingOccurrencesOfString:@"." withString:@""];
    NSString *contentType = [NSString stringWithFormat:@"multipart/form-data; boundary=%@", boundary];
    [request setValue:contentType forHTTPHeaderField: @"Content-Type"];
        
    [request setValue:token  forHTTPHeaderField:@"access_token"];
    // post body
    NSMutableData *body = [NSMutableData data];
    
    // add params (all params are strings)
    //NSString *param = [NSString stringWithFormat:@"%@%@", user.firstName, user.lastName];
    [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[@"Content-Disposition: form-data; name=\"access_token\"\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
    [body appendData:[[NSString stringWithFormat:@"%@\r\n", token] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // add image data
    NSData *imageData = UIImagePNGRepresentation(image);
    if (imageData) {
        [body appendData:[[NSString stringWithFormat:@"--%@\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Disposition: form-data; name=\"avatar\"; filename=\"image.png\"\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:[@"Content-Type: image/png\r\n\r\n" dataUsingEncoding:NSUTF8StringEncoding]];
        [body appendData:imageData];
        [body appendData:[[NSString stringWithFormat:@"\r\n"] dataUsingEncoding:NSUTF8StringEncoding]];
    }
    
    [body appendData:[[NSString stringWithFormat:@"--%@--\r\n", boundary] dataUsingEncoding:NSUTF8StringEncoding]];
    
    // setting the body of the post to the reqeust
    [request setHTTPBody:body];
    
    // set the content-length
    NSString *postLength = [NSString stringWithFormat:@"%d", [body length]];
    [request setValue:postLength forHTTPHeaderField:@"Content-Length"];
    
    // set URL
    [request setURL:[NSURL URLWithString:updateAvatarUrl]];
    
	connectionURL = [[NSURLConnection alloc] initWithRequest:request delegate:self];
	if (connectionURL) {
        datacontent = [NSMutableData data] ;
	}
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [datacontent setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
    [datacontent appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
	datacontent = nil;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *cotentfromserver= [[NSString alloc]initWithData:datacontent encoding:NSUTF8StringEncoding];
    NSLog(@"upload avatar - cotentfromserver = %@",cotentfromserver);
    
    NSData *jsonData = [cotentfromserver dataUsingEncoding:NSUTF8StringEncoding];
    NSError *e;
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:jsonData options:nil error:&e];
    
    [self.delegate updateUserImage_success:dict];
    
//    NSString *status = [dict objectForKey:@"status"];
//    
//    if([status isEqual:@"success"]){
//        [self.delegate updateUserImage_success:dict];
//    }else{
//        [self.delegate updateUserImage_unsuccess:dict];
//    }
}

@end

