//
//  mm_UpdateUserInfotTask.h
//  mymenu
//
//  Created by Dang Duc Nam on 11/1/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_sycndata.h"
#import "mm_AccountEntity.h"
#import <Foundation/Foundation.h>

@protocol updateUserInfoProtocol

- (void) updateUserInfo_success:(mm_AccountEntity *)userUpdate;
- (void) updateUserInfo_unsuccess:(NSDictionary *) dict;

@end

@interface mm_UpdateUserInfoTask : mm_sycndata

@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <updateUserInfoProtocol> delegate;

-(void)updateUserInfo:(mm_AccountEntity *)userUpdate;

@end