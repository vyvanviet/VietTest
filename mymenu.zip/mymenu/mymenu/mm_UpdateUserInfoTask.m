//
//  mm_CreateAccountTask.m
//  mymenu
//
//  Created by Dang Duc Nam on 10/29/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_UpdateUserInfoTask.h"
#import "mm_sycnData.h"
#import "string.h"

mm_AccountEntity *user;

@implementation mm_UpdateUserInfoTask
@synthesize postdata;
@synthesize delegate;

-(void)updateUserInfo:(mm_AccountEntity *)userUpdate{
    NSLog(@"vo ham updateUserInfo");
    user = userUpdate;
    
    postdata = [self toUserCreateJSON:userUpdate];
    NSLog(@"create account postdata = %@",postdata);
    [self request:updateUserUrl];
}

-(void)request:(NSString *)url;
{
    //Declare NSData postData
	NSData *postData = [postdata dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
	
	//Declare NSString postLength and get length postData
	NSString *postLength = [NSString stringWithFormat:@"%d",[postData length]];
	
	//Declare NSMutableURLRequest request_url
    NSString *getVideoURL =url;
    
	NSMutableURLRequest *request_url = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",getVideoURL ]]                                         cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
                                                           timeoutInterval:1];
	//use method GET of request_url and set value of NSMutableURLRequest
	[request_url setHTTPMethod:@"POST"];
	[request_url setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request_url setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Current-Type"];
	[request_url setHTTPBody:postData];
    [request_url setTimeoutInterval:100];
	
	//init NSURLConnection connectionURL
	connectionURL = [[NSURLConnection alloc] initWithRequest:request_url delegate:self];
	if (connectionURL) {
        datacontent = [NSMutableData data] ;
	}
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [datacontent setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
    [datacontent appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    datacontent = nil;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *cotentfromserver= [[NSString alloc]initWithData:datacontent encoding:NSUTF8StringEncoding];
    NSLog(@"cotentfromserver = %@",cotentfromserver);
    
    NSData *jsonData = [cotentfromserver dataUsingEncoding:NSUTF8StringEncoding];
    NSError *e;
    NSDictionary *dict = [NSJSONSerialization JSONObjectWithData:jsonData options:nil error:&e];
    
    NSString *status = [dict objectForKey:@"status"];
    NSLog(@"status: %@", status);
    if([status isEqual:@"success"]){        
        [self.delegate updateUserInfo_success:user];
    }else{
        [self.delegate updateUserInfo_unsuccess:dict];
    }
}

- (NSString *)createJSONFromDictionary:(NSDictionary *)dictionary {
    NSError* error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:kNilOptions error:&error];
    if (!error) {
        NSString* jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return jsonString;
    } else {
        return nil;
    }
}

- (NSString *)toUserCreateJSON: (mm_AccountEntity *)newUser {
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *token = [defaults stringForKey:kTokenkey];
        
    NSMutableDictionary *mutableDictionary = [NSMutableDictionary new];
    [mutableDictionary setObject:token forKey:kJsonToken];
    [mutableDictionary setObject:newUser.email forKey:kJsonEmail];
    [mutableDictionary setObject:newUser.username forKey:kJsonUsername];
    [mutableDictionary setObject:newUser.password forKey:kJsonPassword];
    [mutableDictionary setObject:newUser.firstName forKey:kJsonFirstName];
    [mutableDictionary setObject:newUser.lastName forKey:kJsonLastName];
    [mutableDictionary setObject:newUser.address forKey:kJsonAddress];
    [mutableDictionary setObject:newUser.city forKey:kJsonCity];
    [mutableDictionary setObject:newUser.state forKey:kJsonState];
    [mutableDictionary setObject:newUser.zip forKey:kJsonZip];
    [mutableDictionary setObject:newUser.gender forKey:kJsonGender];
    
    NSDictionary *userInfo = [NSDictionary dictionaryWithDictionary:mutableDictionary];
    return [self createJSONFromDictionary:userInfo]; 
}

@end
