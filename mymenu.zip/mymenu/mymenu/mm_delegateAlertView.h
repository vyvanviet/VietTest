//
//  mm_delegateAlertView.h
//  mymenu
//
//  Created by vo thanh hung on 11/5/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@protocol sharefacebookprotocol   //define delegate protocol
- (void) share_facebook;
- (void) share_facebook_cancel;  //define delegate method to be implemented within another class
@end

@interface mm_delegateAlertView : NSObject<UIAlertViewDelegate>

@property (nonatomic, weak) id <sharefacebookprotocol> delegate;
-(void)share;
@end