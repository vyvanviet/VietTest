//
//  mm_delegateAlertView.m
//  mymenu
//
//  Created by vo thanh hung on 11/5/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_delegateAlertView.h"



@implementation mm_delegateAlertView
@synthesize delegate;
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    NSLog(@"delegate");
    if(buttonIndex == 1){
        
        [delegate share_facebook];
    }
    else
        [delegate share_facebook_cancel];
}


@end

