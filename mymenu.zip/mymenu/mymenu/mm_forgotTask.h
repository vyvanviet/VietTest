//
//  mm_forgotTask.h
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 11/1/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_sycndata.h"
#import <Foundation/Foundation.h>

@protocol forgotsusscessProtocol   //define delegate protocol
- (void) forgot_susscess;  //define delegate method to be implemented within another class
- (void) forgot_unsusscess;

@end //end protocol

@interface mm_forgotTask : mm_sycndata
{
    NSString *postdata;
}
@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <forgotsusscessProtocol> delegate;
-(void)forgot:(NSString *)email;
@end
