//
//  mm_forgotTask.m
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 11/1/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_forgotTask.h"
#import "mm_sycnData.h"
#import "string.h"

@implementation mm_forgotTask
@synthesize postdata;
@synthesize delegate;
- (NSString *)createJSONFromDictionary:(NSDictionary *)dictionary {
    NSError* error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:kNilOptions error:&error];
    if (!error) {
        NSString* jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return jsonString;
    } else {
        return nil;
    }
}
-(void)forgot:(NSString *) email {
    NSMutableDictionary *mutableDictionary = [NSMutableDictionary new];
    [mutableDictionary setObject:email forKey:@"email"];
    NSDictionary *userInfo = [NSDictionary dictionaryWithDictionary:mutableDictionary];
    postdata=[self createJSONFromDictionary:userInfo];
    NSLog(@"forgot postdata = %@",postdata);
    [self request];
}
-(void)request
{
    //Declare NSData postData
	NSData *postData = [postdata dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
	
	//Declare NSString postLength and get length postData
	NSString *postLength = [NSString stringWithFormat:@"%d",[postData length]];
    
	NSMutableURLRequest *request_url = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",forgoturl ]]                                         cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
                                                           timeoutInterval:1];
	//use method GET of request_url and set value of NSMutableURLRequest
	[request_url setHTTPMethod:@"POST"];
	[request_url setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request_url setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Current-Type"];
	[request_url setHTTPBody:postData];
    [request_url setTimeoutInterval:100];
	
	//init NSURLConnection connectionURL
	connectionURL = [[NSURLConnection alloc] initWithRequest:request_url delegate:self];
	if (connectionURL) {
        datacontent = [NSMutableData data] ;
	}
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [datacontent setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
    [datacontent appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    
	
	datacontent = nil;
    [self.delegate forgot_unsusscess];
    
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    
    NSString *cotentfromserver= [[NSString alloc]initWithData:datacontent encoding:NSUTF8StringEncoding];
    NSLog(@"aaaa%@",cotentfromserver);
    if ([cotentfromserver rangeOfString:@"success"].location == NSNotFound)
    {
        [self.delegate forgot_unsusscess];
    }else
    {
        [self.delegate forgot_susscess];
    }
    
}
-(NSMutableArray*)parseData:(NSString *)conntent{
    /*
     NSMutableArray *returnData=[[NSMutableArray alloc]init];
     NSMutableArray *jsonData=[conntent JSONValue];
     for (int i=1;i<jsonData.count; i++) {
     
     NSDictionary *iteam = [jsonData objectAtIndex:i];
     NSString *type=[iteam objectForKey:@"type"];
     NSString *icon=[iteam objectForKey:@"favicon"];
     NSString *title=[iteam objectForKey:@"title"];
     NSString *mId=[iteam objectForKey:@"id"];
     NSString *mCid=[iteam objectForKey:@"cid"];
     NSString *mActor=[iteam objectForKey:@"actor"];
     NSString *mActors=[iteam objectForKey:@"actors"];
     NSString *mAccess=[iteam objectForKey:@"access"];
     NSString *mApp=[iteam objectForKey:@"app"];
     NSString *mEventid=[iteam objectForKey:@"eventid"];
     NSString *mGroupid=[iteam objectForKey:@"groupid"];
     NSString *mGroup_access=[iteam objectForKey:@"group_access"];
     NSString *mEvent_access=[iteam objectForKey:@"event_access"];
     NSString *mLocation=[iteam objectForKey:@"location"];
     NSString *mCommentCount=[iteam objectForKey:@"commentCount"];
     NSString *mCommentAllowed=[iteam objectForKey:@"commentAllowed"];
     NSString *mCommentLast=[iteam objectForKey:@"commentLast"];
     NSString *mLikeCount=[iteam objectForKey:@"likeCount"];
     NSString *mLikeAllowed=[iteam objectForKey:@"likeAllowed"];
     NSString *mIsFriend=[iteam objectForKey:@"isFriend"];
     NSString *mIsMyGroup=[iteam objectForKey:@"isMyGroup"];
     NSString *mUserLiked=[iteam objectForKey:@"userLiked"];
     NSString *mParams=[iteam objectForKey:@"params"];
     NSLog(@"type = %@",type);
     NSLog(@"icon = %@",icon);
     NSLog(@"mParams = %@",mParams);
     NSLog(@"mLikeCount = %@",mLikeCount);
     NSLog(@"commentCount = %@",mCommentCount);
     
     bi_FeedData *data=[[bi_FeedData alloc]init];
     data.imageUrl=icon;
     data.userName=[NSString stringWithFormat:@"testacount%d",i];
     data.avatarUrl=icon;
     data.lastComment=mCommentLast;
     data.likeCount=@"1";
     data.commentCount=@"3";
     data.timeCreate=@"13h";
     [returnData addObject:data];
     }*/
    // return  returnData;
}

@end
