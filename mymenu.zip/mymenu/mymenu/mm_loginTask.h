//
//  mm_loginTask.h
//  mymenu
//
//  Created by Le Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//
#import "mm_sycndata.h"
#import <Foundation/Foundation.h>
#import "JSON.h"
#import "mm_AccountEntity.h"
@protocol loginsusscessProtocol   //define delegate protocol
- (void) login_susscess:(mm_AccountEntity *) account;  //define delegate method to be implemented within another class
- (void) login_unsusscess:(NSString *)error;

@end //end protocol

@interface mm_loginTask : mm_sycndata
{
    NSString *postdata;
}
@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <loginsusscessProtocol> delegate;
-(void)login:(NSString *)email password:(NSString *)pass;
@end
