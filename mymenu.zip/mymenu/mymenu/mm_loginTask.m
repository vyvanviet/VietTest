//
//  mm_loginTask.m
//  mymenu
//
//  Created by Le Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_loginTask.h"
#import "mm_AccountEntity.h"
#import "NSString+EmailValidation.h"
#import "mm_sycnData.h"
#import "string.h"

@implementation mm_loginTask
@synthesize postdata;
@synthesize delegate;
- (NSString *)createJSONFromDictionary:(NSDictionary *)dictionary {
    NSError* error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:kNilOptions error:&error];
    if (!error) {
        NSString* jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return jsonString;
    } else {
        return nil;
    }
}
-(void)login:(NSString *) email password:(NSString *)password {
    NSMutableDictionary *mutableDictionary = [NSMutableDictionary new];
    
    if ([email isValidEmailAddress]) {
        if (email.length > 0) {
            [mutableDictionary setObject:email forKey:@"email"];
            
        }
        
    } else {
        
        if (email.length > 0) {
            [mutableDictionary setObject:email forKey:@"username"];
        }
    }
    
    if (password.length > 0) {
        [mutableDictionary setObject:password forKey:@"password"];
    }
    NSDictionary *userInfo = [NSDictionary dictionaryWithDictionary:mutableDictionary];
    postdata=[self createJSONFromDictionary:userInfo];
    NSLog(@"login postdata = %@",postdata);
    [self request:loginurl];
}
-(void)request:(NSString *)url;
{
    //Declare NSData postData
	NSData *postData = [postdata dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
	
	//Declare NSString postLength and get length postData
	NSString *postLength = [NSString stringWithFormat:@"%d",[postData length]];
	
	//Declare NSMutableURLRequest request_url
    NSString *getVideoURL =url;
    
	NSMutableURLRequest *request_url = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",getVideoURL ]]                                         cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
                                                           timeoutInterval:1];
	//use method GET of request_url and set value of NSMutableURLRequest
	[request_url setHTTPMethod:@"POST"];
	[request_url setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request_url setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Current-Type"];
	[request_url setHTTPBody:postData];
    [request_url setTimeoutInterval:100];
	
	//init NSURLConnection connectionURL
	connectionURL = [[NSURLConnection alloc] initWithRequest:request_url delegate:self];
	if (connectionURL) {
        datacontent = [NSMutableData data] ;
	}
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [datacontent setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
    [datacontent appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    
	
	datacontent = nil;
    [self.delegate login_unsusscess:error];
    
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *cotentfromserver= [[NSString alloc]initWithData:datacontent encoding:NSUTF8StringEncoding];
    NSLog(@"cotentfromserver = %@",cotentfromserver);
    
    NSString *userid=[cotentfromserver
                      stringByReplacingOccurrencesOfString:@"[" withString:@""];
    
    userid=[userid
            stringByReplacingOccurrencesOfString:@"]" withString:@""];
    
    userid=[userid
            stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    
    mm_AccountEntity *returnData = [self parseData:cotentfromserver];
    
    NSLog(@"status = %@",returnData.status);
    
    //NSComparisonResult res1 = [cotentfromserver compare:[NSString stringWithFormat:@"%@",@"ln:0"]];
    if ([returnData.status isEqualToString:@"success"]) {
        
        
        [self.delegate login_susscess:returnData];
        
    }else {
        
        [self.delegate login_unsusscess:returnData.status];
        
        
    }
    
    //[parser release];
    
}
-(mm_AccountEntity*)parseData:(NSString *)conntent{
    mm_AccountEntity *data=[[mm_AccountEntity alloc]init];
    NSDictionary *jsonDict = [conntent JSONValue];
   
   
        
        NSString *status=[jsonDict objectForKey:@"status"];
    NSLog(@"status = %@",status);
    
    if([status isEqualToString:@"failed"])
    {
        NSString *error=[jsonDict objectForKey:@"error"];
        data.status         = error;
        data.acces_token    = @"";
        data.email          = @"";
        data.username       = @"";
        data.firstName      = @"";
        data.lastName       = @"";
        data.address        = @"";
        data.city           = @"";
        data.state          = @"";
        data.zip            = @"";
        data.age            = @"";
        data.gender            = @"";
        data.points            = @"";
        data.avatar            = @"";
        data.favourite            = @"";
        data.DefaultSearchProfile            = @"";
        return data;
    }
    else
    {
        NSString *access_token=[jsonDict objectForKey:@"access_token"];
    NSLog(@"access_token = %@",access_token);
    
        NSDictionary *iteam=[jsonDict objectForKey:@"user"];//get object user
      
        NSString *email=[iteam objectForKey:@"email"];
     NSLog(@"email = %@",email);
        NSString *username=[iteam objectForKey:@"username"];
     NSLog(@"username = %@",username);
        NSString *firstname=[iteam objectForKey:@"first_name"];
     NSLog(@"firstname = %@",firstname);
        NSString *lastname=[iteam objectForKey:@"last_name"];
     NSLog(@"lastname = %@",lastname);
        NSString *address=[iteam objectForKey:@"address"];
     NSLog(@"address = %@",address);
        NSString *city=[iteam objectForKey:@"city"];
     NSLog(@"city = %@",city);
        NSString *state=[iteam objectForKey:@"state"];
     NSLog(@"state = %@",state);
        NSString *zip=[iteam objectForKey:@"zip"];
     NSLog(@"zip = %@",zip);
        NSString *age=[iteam objectForKey:@"age"];
     NSLog(@"age = %@",age);
        NSString *gender=[iteam objectForKey:@"gender"];
     NSLog(@"gender = %@",gender);
        NSString *points=[iteam objectForKey:@"points"];
     NSLog(@"points = %@",points);
        NSString *avatar=[iteam objectForKey:@"avatar"];
     NSLog(@"avatar = %@",avatar);
        NSString *favourite=[iteam objectForKey:@"favourite"];
     NSLog(@"favourite = %@",favourite);
        NSString *DefaultSearchProfile=[iteam objectForKey:@"DefaultSearchProfile"];
     NSLog(@"DefaultSearchProfile = %@",DefaultSearchProfile);
    
       
        
    
        data.status         = status;
        data.acces_token    = access_token;
        data.email          = email;
        data.username       = username;
        data.firstName      = firstname;
        data.lastName       = lastname;
        data.address        = address;
        data.city           = city;
        data.state          = state;
        data.zip            = zip;
        data.age            = age;
        data.gender            = gender;
        data.points            = points;
        data.avatar            = avatar;
        data.favourite            = favourite;
        data.DefaultSearchProfile            = DefaultSearchProfile;
        
    return data;
    }
    
   // return  returnData;
}

@end
