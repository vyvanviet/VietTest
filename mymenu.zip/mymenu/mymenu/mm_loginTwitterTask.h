//
//  mm_loginTwitterTask.h
//  mymenu
//
//  Created by vo thanh hung on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "mm_sycndata.h"
#import "JSON.h"
#import "mm_AccountEntity.h"


@protocol loginTwittersusscessProtocol   //define delegate protocol
- (void) loginTwitter_susscess:(mm_AccountEntity *) account;  //define delegate method to be implemented within another class
- (void) loginTwitter_unsusscess:(NSString *)_provider; 

@end //end protocol
@interface mm_loginTwitterTask :  mm_sycndata
{
    NSString *postdata;
    NSString *mypro;
}
@property(nonatomic,retain) NSString *mypro;

@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <loginTwittersusscessProtocol> delegate;
-(void)loginTwitter:(NSString *)uid provider:(NSString *)pro email:(NSString *)_email;
@end
