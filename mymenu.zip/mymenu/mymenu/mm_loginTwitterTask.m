//
//  mm_loginTwitterTask.m
//  mymenu
//
//  Created by vo thanh hung on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_loginTwitterTask.h"
#import "string.h"
#import "mm_sycnData.h"

@implementation mm_loginTwitterTask

@synthesize postdata;
@synthesize delegate;
@synthesize mypro;

- (NSString *)createJSONFromDictionary:(NSDictionary *)dictionary {
    NSError* error;
    NSData* jsonData = [NSJSONSerialization dataWithJSONObject:dictionary options:kNilOptions error:&error];
    if (!error) {
        NSString* jsonString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
        return jsonString;
    } else {
        return nil;
    }
}


-(void)loginTwitter:(NSString *)uid provider:(NSString *)pro email:(NSString *)_email
{
        NSMutableDictionary *mutableDictionary = [NSMutableDictionary new];
        mypro=pro;
        
        if (uid.length > 0) {
            [mutableDictionary setObject:uid forKey:@"uid"];
        }
    
       if (pro.length > 0) {
           [mutableDictionary setObject:pro forKey:@"provider"];
       }
    
        if (_email.length > 0)
        
        {
            [mutableDictionary setObject:_email forKey:@"email"];
        }
    else
        [mutableDictionary setObject:@"" forKey:@"email"];

    
    
    
        NSDictionary *userInfo = [NSDictionary dictionaryWithDictionary:mutableDictionary];
       postdata=[self createJSONFromDictionary:userInfo];
        NSLog(@"login postdata login = %@",postdata);
        [self request:logintwitterurl];
}
-(void)request:(NSString *)url;
{
    //Declare NSData postData
	NSData *postData = [postdata dataUsingEncoding:NSUTF8StringEncoding allowLossyConversion:NO];
	
	//Declare NSString postLength and get length postData
	NSString *postLength = [NSString stringWithFormat:@"%d",[postData length]];
	
	//Declare NSMutableURLRequest request_url
    NSString *getVideoURL =url;
    
	NSMutableURLRequest *request_url = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",getVideoURL ]]                                         cachePolicy:NSURLRequestReloadIgnoringLocalAndRemoteCacheData
                                                           timeoutInterval:1];
	//use method GET of request_url and set value of NSMutableURLRequest
	[request_url setHTTPMethod:@"POST"];
	[request_url setValue:postLength forHTTPHeaderField:@"Content-Length"];
	[request_url setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Current-Type"];
	[request_url setHTTPBody:postData];
    [request_url setTimeoutInterval:100];
	
	//init NSURLConnection connectionURL
	connectionURL = [[NSURLConnection alloc] initWithRequest:request_url delegate:self];
	if (connectionURL) {
        datacontent = [NSMutableData data] ;
	}
}
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response {
    [datacontent setLength:0];
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data {
	
    [datacontent appendData:data];
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error {
    
	
	datacontent = nil;
    //[self.delegate loginTwitter_unsusscess];
    
    
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSString *cotentfromserver= [[NSString alloc]initWithData:datacontent encoding:NSUTF8StringEncoding];
    NSLog(@"cotentfromserver = %@",cotentfromserver);
    
    NSString *userid=[cotentfromserver
                      stringByReplacingOccurrencesOfString:@"[" withString:@""];
    
    userid=[userid
            stringByReplacingOccurrencesOfString:@"]" withString:@""];
    
    userid=[userid
            stringByReplacingOccurrencesOfString:@"\"" withString:@""];
    
    mm_AccountEntity *returnData = [self parseData:cotentfromserver];
    
    NSLog(@"status11 = %@",returnData);
    
    //NSComparisonResult res1 = [cotentfromserver compare:[NSString stringWithFormat:@"%@",@"ln:0"]];
    if ([returnData.status isEqualToString:@"failed"]) {
        
        [self.delegate loginTwitter_unsusscess:mypro];
        
        
    }else {
        
         NSLog(@"status token = %@",returnData);
        [self.delegate loginTwitter_susscess:returnData ];
        NSLog(@"delegate");
        
    }
    
    //[parser release];
    
}
-(mm_AccountEntity*)parseData:(NSString *)conntent{
    mm_AccountEntity *data=[[mm_AccountEntity alloc]init];
    NSDictionary *jsonDict = [conntent JSONValue];
    
    
    
    NSString *status=[jsonDict objectForKey:@"status"];
    NSLog(@"status = %@",status);
    
    if([status isEqualToString:@"failed"])
    {
        
        data.status         = status;
        data.acces_token    = @"";
        data.email          = @"";
        data.username       = @"";
        data.firstName      = @"";
        data.lastName       = @"";
        data.address        = @"";
        data.city           = @"";
        data.state          = @"";
        data.zip            = @"";
        data.age            = @"";
        data.gender            = @"";
        data.points            = @"";
        data.avatar            = @"";
        data.favourite            = @"";
        data.DefaultSearchProfile            = @"";
        return data;
    }
    else
    {
        NSString *access_token=[jsonDict objectForKey:@"access_token"];
        NSLog(@"access_token = %@",access_token);
        
        NSDictionary *iteam=[jsonDict objectForKey:@"user"];//get object user
        
        NSString *email=[iteam objectForKey:@"email"];
        NSLog(@"email = %@",email);
        NSString *username=[iteam objectForKey:@"username"];
        NSLog(@"username = %@",username);
        NSString *firstname=[iteam objectForKey:@"first_name"];
        NSLog(@"firstname = %@",firstname);
        NSString *lastname=[iteam objectForKey:@"last_name"];
        NSLog(@"lastname = %@",lastname);
        NSString *address=[iteam objectForKey:@"address"];
        NSLog(@"address = %@",address);
        NSString *city=[iteam objectForKey:@"city"];
        NSLog(@"city = %@",city);
        NSString *state=[iteam objectForKey:@"state"];
        NSLog(@"state = %@",state);
        NSString *zip=[iteam objectForKey:@"zip"];
        NSLog(@"zip = %@",zip);
        NSString *age=[iteam objectForKey:@"age"];
        NSLog(@"age = %@",age);
        NSString *gender=[iteam objectForKey:@"gender"];
        NSLog(@"gender = %@",gender);
        NSString *points=[iteam objectForKey:@"points"];
        NSLog(@"points = %@",points);
        NSString *avatar=[iteam objectForKey:@"avatar"];
        NSLog(@"avatar = %@",avatar);
        NSString *favourite=[iteam objectForKey:@"favourite"];
        NSLog(@"favourite = %@",favourite);
        NSString *DefaultSearchProfile=[iteam objectForKey:@"DefaultSearchProfile"];
        NSLog(@"DefaultSearchProfile = %@",DefaultSearchProfile);
        
        
        
        
        data.status         = status;
        data.acces_token    = access_token;
        data.email          = email;
        data.username       = username;
        data.firstName      = firstname;
        data.lastName       = lastname;
        data.address        = address;
        data.city           = city;
        data.state          = state;
        data.zip            = zip;
        data.age            = age;
        data.gender            = gender;
        data.points            = points;
        data.avatar            = avatar;
        data.favourite            = favourite;
        data.DefaultSearchProfile            = DefaultSearchProfile;
        
        return data;
    }
    
    // return  returnData;
}

@end

