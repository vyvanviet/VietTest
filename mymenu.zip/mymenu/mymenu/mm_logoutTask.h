//
//  mm_logoutTask.h
//  mymenu
//
//  Created by Pham Thi Nhu Ngoc on 10/31/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mm_sycndata.h"
#import <Foundation/Foundation.h>

@protocol logoutsusscessProtocol   //define delegate protocol
- (void) logout_susscess;  //define delegate method to be implemented within another class
- (void) logout_unsusscess;

@end //end protocol

@interface mm_logoutTask : mm_sycndata
{
    NSString *postdata;
}
@property(nonatomic,retain)NSString *postdata;
@property (nonatomic, weak) id <logoutsusscessProtocol> delegate;
-(void)logout:(NSString *)accessToken;
@end
