//
//  mm_sycndata.h
//  mymenu
//
//  Created by Le Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface mm_sycndata : NSObject
{
    NSURLConnection			*connectionURL;
    NSMutableData			*datacontent;
    NSThread				*timerThread;
    NSRunLoop				*runLoop;
    
}
@property(nonatomic,retain) NSURLConnection *connectionURL;
@property(nonatomic,retain) NSMutableData	*datacontent;
@property(nonatomic,retain) NSThread	*timerThread;
@property(nonatomic,retain) NSRunLoop	*runLoop;
@end
