//
//  string.h
//  mymenu
//
//  Created by Le Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#ifndef mymenu_string_h
#define mymenu_string_h

#define domainmagrabbit @"http://dev.magrabbit.com:9000"
#define loginurl @"http://54.245.230.7:9000/users/login.json"
#define registersocialurl @"http://dev.magrabbit.com:9000/users/register_social.json"
#define googleplusapikey @"36734922694-gb6q0n9tfimpi8g762orpf8j8hn3rh2f.apps.googleusercontent.com"
#define searchnormalurl @"http://54.245.230.7:9000/locations/normal.json?"
#define searchrestaurantlurl @"http://dev.magrabbit.com:9000/locations/"
#define urlmagrabbit @"http://54.245.230.7:9000"
#define logintwitterurl @"http://dev.magrabbit.com:9000/users/check_token.json"
#define registerUrl @"http://54.245.230.7:9000/users/register.json"
#define updateUserUrl @"http://dev.magrabbit.com:9000/users/settings.json"
#define updateAvatarUrl @"http://dev.magrabbit.com:9000/users/avatar.json"
#define logouturl @"http://dev.magrabbit.com:9000/users/logout.json"
#define logigchecktoken @"http://dev.magrabbit.com:9000/users/check_token.json"
#define logigregitertoken @"http://dev.magrabbit.com:9000/users/register_social.json"
#define kUserLoginMode @"userloginmode"
#define loixayra @"Error"
#define messageError @"Login Failed"
#define btnOK @"OK"
#define forgoturl @"http://dev.magrabbit.com:9000/users/forgot.json"
#define locationRatingUrlStart @"http://dev.magrabbit.com:9000/locations/"
#define locationRatingUrlEnd @"/comment.json"

#define loadLocationFeedbackStart @"http://dev.magrabbit.com:9000/locations/"
#define loadLocationFeedbackEnd @"/comments.json?"
#define registerUrlSocial @"http://54.245.230.7:9000/users/register_social.json"

//key login
#define kBackTo @"back"
#define kTokenkey @"userToken"
#define kUserName @"userName"
#define kPassword @"password"
#define kEmail @"Email"
#define kCity @"city"
#define kFirstName @"FirstName"
#define kLastName @"LastName"
#define kaddress @"address"
#define kstate @"state"
#define kzip @"zip"
#define kage @"age"
#define kgender @"gender"
#define kpoints @"points"
#define kavatar @"avatar"
#define kfavourite @"favourite"
#define kDefaultSearchProfile @"DefaultSearchProfile"

#define kCurrentUser @"CurrentUser"
#define kCurrentUserImage @"CurrentUserImage"
#define kIsUpdateUser @"IsUpdateUser"
#define kJsonToken @"access_token"
#define kJsonFirstName @"first_name"
#define kJsonLastName @"last_name"
#define kJsonEmail @"email"
#define kJsonUsername @"username"
#define kJsonCity @"city"
#define kJsonState @"state"
#define kJsonZip @"zip"
#define kJsonGender @"gender"
#define kJsonPassword @"password"
#define kJsonAge @"age"
#define kJsonAddress @"address"
#define kJsonRating @"rating"
#define kJsonComment @"comment"
#define kJsonUid @"uid"
#define kJsonProvider @"provider"
#endif
