//
//  mymenuTests.h
//  mymenuTests
//
//  Created by Le Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface mymenuTests : SenTestCase

@end
