//
//  mymenuTests.m
//  mymenuTests
//
//  Created by Le Nam on 10/28/13.
//  Copyright (c) 2013 marabit. All rights reserved.
//

#import "mymenuTests.h"

@implementation mymenuTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in mymenuTests");
}

@end
